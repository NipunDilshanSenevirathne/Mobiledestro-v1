# PoC malicious-app template (authorized testing only)

Use when `adb` can't carry the proof: **custom-scheme interception** (OAuth code theft),
**startActivityForResult data capture** (setResult leaks), **intent redirection** (nested
intents), or **task hijacking** demos.

## What it does
- Registers the victim's custom scheme (`VICTIM_SCHEME`) → intercepts scheme links; dumps the
  full URI (that's the OAuth-code / token-interception proof).
- Launches the victim's exported activity for result → dumps whatever `setResult` returns
  (that's the data-leak proof).
- Sends a nested intent through the victim's exported forwarder (that's the redirection proof).
- Everything it captures is written to logcat with tag `HUNTPOC` and shown on screen.

## Build
Requires an Android build setup (Android Studio, or `gradle` + `com.android.application`
plugin). No wrapper is shipped here — generate one with `gradle wrapper` on the operator
machine, or open the folder in Android Studio and press Run.

1. Edit `app/src/main/AndroidManifest.xml`: set `VICTIM_SCHEME`, and if intercepting an
   https App Link, the host too.
2. Edit `app/src/main/java/com/hunt/poc/MainActivity.java`: set `VICTIM_PKG` and the target
   component/extra names for your finding.
3. Build: `gradle assembleDebug` → install on YOUR emulator next to the victim app.
4. Trigger the victim flow (e.g. start its OAuth login with YOUR test account) → the
   system hands the scheme link to this app → `adb logcat -s HUNTPOC` shows the capture.

## Rules
- Only intercept/exercise flows for YOUR OWN test accounts on YOUR OWN device.
- Delete the PoC app after the evidence is captured; never distribute it.
