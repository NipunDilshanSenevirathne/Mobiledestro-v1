# Rules of Engagement (ROE) — edit per engagement. Paste the program's policy here.

## Standing rules (never overridden)
- Test ONLY app ids in `authorized_apps.txt` and backend domains in `authorized_api_domains.txt`.
- Static reverse-engineering of an authorized binary: allowed.
- Dynamic testing: ONLY on your own device/emulator, with YOUR OWN test accounts.
- NEVER access, read, or exfiltrate real users' data. Proof uses your own seeded accounts only.
- OOB (out-of-band) callbacks only to infrastructure YOU control (self-hosted interactsh, your
  own HTTP server). Redact any secrets/tokens captured in evidence.
- Throttle all automated API testing (default ≤ 5 req/s). Respect program rate limits.
- No destructive testing: no deletes/updates on shared data, no account locking, no SMS/email
  bombing, no DoS outside what the program explicitly allows (most exclude DoS — check).
- No pivoting to third-party services/infrastructure (analytics, ad networks, CDNs) even if the
  app talks to them, unless the program explicitly includes them.
- If a target turns out to be unauthorized: stop, hand it back, note it in the run summary.

## Program-specific
- Program / platform + URL:
- In-scope assets (paste from the policy):
- Out-of-scope assets:
- Known issues / duplicates list:
- Severity notes (e.g. DoS excluded, self-XSS informational, rooted-device-only issues):
- Disclosure terms / safe-harbor text:
