# Engine: Storage, Secrets & Crypto (MASVS-STORAGE / MASVS-CRYPTO)

Often a *primitive* that feeds a chain (leaked token → API; hardcoded key → backend) rather
than a standalone critical. Hunt data-at-rest + secrets, then chain to impact.

## Where sensitive data leaks at rest
- `SharedPreferences` (`/data/data/<pkg>/shared_prefs/*.xml`) — tokens, PII, flags.
  `EncryptedSharedPreferences`/Tink is the fix; plaintext XML is the norm.
- SQLite DBs (`/databases/`), Room, Realm (unencrypted by default), DataStore files.
- Internal/external files, caches, **WebView data** (`app_webview/`: LocalStorage, cookies —
  session tokens live here), image caches with sensitive content.
- **External storage** (`getExternalFilesDir`, legacy world-readable paths) — other apps read it.
- **Logs** (`Log.d/v/i`) leaking tokens/PII: ProGuard `assumenosideeffects` may strip in
  release — verify in smali; catch live with `adb logcat` / `frida_crypto_monitor.js`.
- **Backups**: `allowBackup=true` → `adb backup` extraction (pre-12 semantics); Android 12+:
  `dataExtractionRules`/`fullBackupContent` — check what's actually included/excluded;
  Auto-Backup-to-cloud contents.
- **Keystore misuse**: keys outside Android Keystore; Keystore keys without
  `setUserAuthenticationRequired`; "encryption" with a hardcoded key (obfuscation, not
  protection); no key attestation where it matters.
- **UI leaks**: missing `FLAG_SECURE` on sensitive screens (Recents thumbnails/screenshots),
  notification content on lock screen, autofill frame leaks, keyboard caching of sensitive
  fields, clipboard persistence.
- **WebView debugging**: `setWebContentsDebuggingEnabled(true)` in a release build →
  `chrome://inspect` gives full JS execution in the app's WebView → bridge access (chain!).

## Hardcoded secrets (chain to backend)
- Sources: jadx strings, `BuildConfig`, resources, assets, native libs (`secrets_hunter.py`
  covers regex + entropy; `apkleaks`, `trufflehog filesystem` add breadth).
- Classes: cloud keys (AWS/GCP/Azure), Firebase config, Stripe/Payment live keys, OAuth client
  secrets, signing/HMAC secrets, internal endpoints + creds, PEM blocks, JWT-looking blobs.
- **Validate each one**: does it work against its backend/cloud (benign, authorized, in-scope
  probe)? Live → real finding + chain (open Firebase, bucket list, SMS/email send as them).
  Dead/test → note only (high-dup, low value).

## Crypto weaknesses
- Hardcoded keys/IVs, ECB, CBC with static/predictable IV, `SHA1`/`MD5` where it matters,
  weak KDF (low PBKDF2 iterations), custom crypto/XOR, `SecureRandom` seeded predictably,
  trust-all `TrustManager`/`HostnameVerifier` (also NETWORK), broken hostname verification.
- These often *enable* the storage/network findings — cite them as root cause, not the lead.

## Runtime confirmation
- Use the app with **your own account**, then pull its data: `run-as <pkg>` (debuggable),
  `adb backup`, or root pull → show the token/PII at the exact path.
- `frida_crypto_monitor.js` hooks Cipher/Keystore/Log/SQLite/Prefs — catches secrets moving
  through memory and into logs at runtime.
- objection: `android keystore list`, `memory dump all`, heap search for token patterns.

## Proof bar & reporting
Exact file/path + cleartext value (your own account, redacted), or live-secret proof (benign
authorized call), and the **chain** it enables (token → API/ATO, key → backend). Map
**MASVS-STORAGE**/**MASVS-CRYPTO**. Standalone storage notes are often dup/low — lead with the
chain (leaked token → account access).
