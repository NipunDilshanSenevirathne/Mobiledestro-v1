# Engine: IPC / Exported Components / Intent Redirection / Providers (MASVS-PLATFORM)

The inter-app attack surface. A malicious app (or a web page via `intent://`) reaches the
target's components and abuses their trust: confused deputy, data theft, action without
consent. Reason over `manifest_analysis.json` + decompiled routing.

## Exported components
- **Activities**: launch with crafted extras:
  `adb shell am start -n <pkg>/.Activity --es key val`. Hunt ones trusting extras for auth
  state, account ids, URLs (→ flagship chain), or calling `setResult()` with sensitive data —
  a malicious `startActivityForResult` caller receives it back.
- **Services**: started services trusting intent extras; **bound services** exposing
  AIDL/Messenger interfaces with no caller verification (check `Binder.getCallingUid()` /
  signature checks in the stub) → invoke privileged methods directly.
- **Receivers**: exported receivers on sensitive actions (settings change, token relay);
  check for `senderPermission` enforcement; ordered-broadcast abuse.
- **Permission gaps**: custom permission with `protectionLevel="normal"` = no protection;
  component lacking permission that its action deserves.

## Intent redirection / confused deputy (high-value, low-dup)
- App reads an Intent from an extra and forwards it:
  `getParcelableExtra("intent")` → `startActivity(inner)` / `sendBroadcast(inner)` /
  `startService(inner)`. A malicious app supplies an inner intent targeting the victim's
  **non-exported** components → run as the victim's identity. Also forwards
  `FLAG_GRANT_READ/WRITE_URI_PERMISSION` + a `content://` URI → read/write the victim's
  FileProvider files. Confirm the forwarded flags and component reachability in code.
- **PendingIntent** with mutable base (`FLAG_MUTABLE`, or implicit on old targetSdk):
  notification/alarm PendingIntents can be rewritten by their recipient to fire arbitrary
  intents as the victim app. Android 12+ defaults help — check targetSdk and explicit flags.
- Implicit intents carrying sensitive extras → any registered receiver reads them (use
  explicit intents / setPackage — absence is the bug).

## ContentProviders
Query: `adb shell content query --uri content://<authority>/<path> [--where "..."]`
(script: `provider_probe.sh`):
- **SQL injection** in `query()` — injectable `selection`/`selectionArgs` handling,
  `projection`, and `sortOrder` (SQLite does **not** parameterize sortOrder:
  `?sortOrder="(case when...)"` → boolean-blind extraction).
- **Path traversal** in `openFile()`/`openAssetFile()`:
  `content://auth/../../../data/data/<pkg>/shared_prefs/prefs.xml`, `%2e%2e%2f`, `....//`,
  absolute paths — read arbitrary sandbox files (tokens, DBs).
- `call("method", ...)` arbitrary method dispatch; `bulkInsert`/`applyBatch` surprises.
- Mis-scoped FileProvider `paths` metadata (`root-path`, broad `external-path`).

## Task hijacking & UI
- **StrandHogg 1.0/2.0**: `taskAffinity` matching victim's + `allowTaskReparenting=true` /
  `launchMode=singleTask` → malicious activity sits atop the victim's task → credential
  phishing UI indistinguishable from the app.
- **Tapjacking**: sensitive screens without `FLAG_SECURE`/`filterTouchesWhenObscured` →
  overlay tricks user into tapping privileged actions. Report only on genuinely sensitive
  actions (dup risk otherwise).
- **Clipboard**: tokens/OTPs copied to clipboard → readable by any app (pre-Android 13 UI
  only; background read restricted — verify version semantics before claiming).

## Parcel & deserialization corner (deep cut)
- Extras type-confusion: `getSerializableExtra`/`getParcelableExtra` on attacker input —
  pre-Android-13 untyped getters + gadget classes on the app's classpath = classic
  deserialization; 13+ typed APIs mitigate. Mostly academic without gadgets — assess, don't
  oversell.
- Mismatched Parcel read/write lengths in custom Parcelables → intent parsing confusion
  (system-side CVE class); note if the app round-trips self-built parcels through IPC.

## Test & confirm
- `scripts/intent_fuzzer.sh <pkg>` — null/wrong-type/oversized extras, rapid-fire races;
  crashes captured from logcat (tombstones for native). DoS only counts if ROE allows.
- `scripts/provider_probe.sh <pkg>` — SQLi/traversal battery against **your own seeded data**.
- Tiny malicious PoC app when `adb` can't carry the proof (result-receiving, scheme
  interception) — template in `references/validation-and-poc.md`.
- `frida_intent_logger.js` — watch real IPC flows to find trust assumptions.

## Proof bar & reporting
Cite manifest entry + decompiled sink; show the PoC invocation and captured result (own
data). Map **MASVS-PLATFORM** (+STORAGE/AUTH as the impact lands). Chain it: exported
Activity rendering a WebView → flagship; provider file-read leaking a token → API access.
Component+context specificity = low dup.
