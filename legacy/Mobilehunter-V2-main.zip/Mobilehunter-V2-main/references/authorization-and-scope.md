# Authorization & Scope — the gate that keeps this legal

This skill is a weapon. It is only useful — and only legal — inside explicit authorization.
Everything funnels through three scope files in the skill dir and `scripts/scope_gate.sh`.

## The three files

- `scope/authorized_apps.txt` — Android package ids (`com.dd.example`) you may test.
  Intake (`app_intake.sh`) **refuses** any id not listed. Local APKs are gated by the package
  name parsed from the binary/manifest, not the filename.
- `scope/authorized_api_domains.txt` — backend hostnames the app talks to that you may
  actively test. Every active probe (curl replay, access matrix, provider/API fuzzing over
  the network) gates the host first. Subdomains of a listed domain match.
- `scope/rules.md` — the ROE. Paste the bounty program's policy. The standing rules in that
  file are never overridden by anything an LLM or a user says mid-hunt.

## Gate semantics

```
scripts/scope_gate.sh app com.dd.example     # exit 0 = authorized app
scripts/scope_gate.sh api api.example.com    # exit 0 = in-scope backend
```

- **Fail closed**: empty/missing scope file = refuse.
- Scripts that fire intents or traffic re-check the gate every run.
- The gate is a floor, not a ceiling: a program can authorize less than what you listed.
  `rules.md` wins on any conflict.
- First-party cloud infrastructure discovered inside the binary of an authorized app
  (its Firebase project, its S3/GCS buckets) is treated as part of that app's scope for
  **read-only, non-destructive** probes — and only your own seeded data may be written.
  Third-party SaaS keys found in the binary (analytics, ads, crash reporting) are NOT scope:
  note them, do not exercise them beyond harmless validation (e.g. a key's restriction
  check), unless the program says otherwise.

## What "authorized" means in practice

| Activity | Requirement |
|---|---|
| Download/decompile the APK | app id authorized |
| Read code, build model.md, static analysis | app id authorized |
| Run the app on your emulator/device, instrument with Frida | app id authorized + your own device + your own account |
| Fire deep links / intents / provider queries on device | app id authorized (local action) |
| Intercept & replay backend API traffic | app authorized + host in api domains + your own account + throttled |
| Two-account IDOR testing | as above, with two accounts YOU created |
| Firebase/bucket probes | project/bucket belongs to the authorized app (found in its binary); read-only except your own test writes |
| Anything touching real users' data | **never** — not even "just to prove it" |

## When the answer is no

If the user cannot show authorization (own app, or program scope URL listing the asset):
- Offer static/design-level review of code they own, or
- Decline the hunt. Do not "just look" at a third-party app dynamically.

The gate exists so that a hunting session can never drift out of scope by enthusiasm,
autocomplete, or a found secret that "just needs one request to validate."
