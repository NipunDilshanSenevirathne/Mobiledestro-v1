# Adversarial Triage — prosecutor / defender / judge

Before anything becomes a report, it survives a structured fight. Run it as three Kimi
subagents (or three deliberate passes) per candidate finding. It kills inflation, catches
reachability gaps, and keeps dup-rate down — the difference between a hunter and a scanner.

## Roles

**Prosecutor** — argues the strongest case:
- Writes the one-line business impact and the full kill chain (entry → primitive → impact).
- Lists the preconditions (Android version, user interaction, config) and argues each is
  realistic.
- Demands the proof: what exact PoC step demonstrates impact, on whose account, captured where.
- Picks the highest *defensible* severity with CVSS vector + justification.

**Defender** — argues for the vendor:
- Attacks reachability: is the component really exported on the shipped targetSdk? Is the
  allowlist really bypassable (test the bypass corpus, don't vibe it)? Does a permission
  actually protect it?
- Attacks impact: is the "token" actually a session token? Does the "PII" include anything
  sensitive? Is the data already public?
- Attacks novelty: is this a known/duplicate class for this program (check their known-issues
  list in rules.md)? Is it root-only / debuggable-only / self-DoS (usually excluded)?
- Attacks the PoC: does it require unrealistic state (user must be logged in AND tap AND
  install a malicious app AND…)?

**Judge** — decides:
- Verdict: **report now** / **deepen** (specific missing hop named) / **note-only** (hardening
  section) / **drop** (with reason recorded in the ledger).
- Final severity + confidence (CVSS vector, environmental notes), the novelty paragraph, and
  the exact remaining proof step if "deepen".
- Records the decision rationale in `ledger.md` — auditable honesty.

## Calibration rules
- Severity follows **demonstrated** impact, never hypothetical. "Could lead to RCE" = not RCE.
- User-interaction cost matters: zero-click > one-click > install-malicious-app >
  physical/root (most programs cap or exclude the last two).
- A control that denies (403 for the cross-account call) is part of the report — it proves
  the access you got was anomalous.
- If prosecutor and defender tie, the finding is **unconfirmed** — go get the missing proof;
  don't report maybes.
- Timebox: don't let a medium lead eat the time a critical chain needs. Park it in the
  ledger; the coverage-gap pass will revisit.

## Output
The judge's verdict + the prosecutor's kill chain + the defender's surviving caveats become
the report skeleton (see `validation-and-poc.md`). Nothing reaches the user that hasn't been
through the fight.
