# Fuzzing & Probing — systematic battering of entries (background-task ready)

Goal: turn the static model into thousands of cheap dynamic trials, then chase the
interesting crashes/hits. All of it runs against **your own device + your own account**.
Run the sweeps as Kimi background tasks; analyze while they run.

## A. Deep-link URI matrix (`deeplink_matrix.py` → `deeplink_fuzz.sh`)
For every intent filter (scheme/host/path from `manifest_analysis.json`), generate:
- **Path traversal**: `..%2f`, `%2e%2e%2f`, `....//`, `..;/`, absolute `/data/data/<pkg>/...`
  in path params consumed by routing.
- **Scheme swaps** on params that reach a WebView/loader: `javascript:alert(1)`,
  `file:///data/data/<pkg>/shared_prefs/x.xml`, `content://<auth>/...`, `data:text/html,...`,
  `intent://...#Intent;component=<pkg>/.internal;end`.
- **Host confusions** for App Links: `example.com.attacker.tld`, `example.com@attacker.tld`,
  `example.com%2f@attacker.tld`, trailing dot, case, unicode.
- **Parameter games**: pollution (`url=a&url=b`), missing params, empty values, oversized
  values (10k), format-string markers (`%s%s%n%x`) where strings flow to `String.format` or
  native printf-family, CRLF in redirect-ish params, unicode/encoded traversal in query
  values.
- **Reachability delivery**: fire as external VIEW intents (`deeplink_probe.sh`), and for
  BROWSABLE filters prove browser delivery with a hosted HTML page.

Triage hits: OOB callback (WebView fetched your URL), bridge call logged
(`frida_bridge_trace.js`), crash (below), unexpected activity launched (logcat ActivityManager
lines: `START ... cmp=<pkg>/...`).

## B. Exported-component extras fuzzing (`intent_fuzzer.sh`)
For each exported activity/service/receiver:
1. No extras; empty extras bundle.
2. Wrong types: string where int/parcelable expected, int where string, negative/zero ids.
3. Oversized strings (1MB — TransactionTooLargeException DoS; report only if ROE allows DoS).
4. Known-key fuzzing: extras keys harvested from jadx (`getStringExtra("X")` calls) with
   attacker values: URLs, `content://` URIs + grant flags (forwarding primitives), file
   paths, serialized blobs.
5. Rapid-fire ×50 same intent (races in singleton init / double-spend handlers).

Capture: `adb logcat -b crash` + tombstones; dedupe by `hash(stack)`. Each unique crash =
one lead; reachability beats count.

## C. ContentProvider battery (`provider_probe.sh`)
Per authority (from `manifest_analysis.json`):
- Path discovery: authority root, common paths (`/`, `/data`, `/files`, table names from
  jadx strings), then traversal sequences against `openFile`.
- SQLi: `--where` payloads — `' OR '1'='1`, `1=1--`, union probes
  (`' UNION SELECT sqlite_version()--`), boolean-blind via `sortOrder`
  (`(CASE WHEN (SELECT substr(value,1,1)='a' FROM secrets) THEN 1 ELSE 0 END)` style —
  SQLite won't parameterize sortOrder), projection smuggling.
- `call()`: `content call --uri content://<auth> --method <m> --arg <a>` for methods seen
  in code.
- grantUri flows: hand a `content://` URI + `FLAG_GRANT_READ_URI_PERMISSION` to a forwarding
  component (chain with engine-ipc).

## D. WebView URL-allowlist corpus
Fire the bypass list from `engine-deeplink-webview.md` at every WebView-loading entry —
each bypass that renders = a finding variant.

## E. Native/file-format inputs
For parsers reached via files/IPC: mutate your own seed files (bit flips, length-field
inflation, truncation) and deliver through the real entry (provider open, share sheet,
import feature). `SIGSEGV`/`SIGABRT` in `logcat` + tombstone = save and hand to
engine-native-code triage.

## F. Rules of engagement for fuzzing
- Throttle: small sleeps between intents/requests; fuzzing is not a stress test.
- DoS findings only where ROE allows; otherwise crash = private note for hardening section.
- Every trial logged to `loot/<appid>/fuzz/<engine>.log` — reproducibility is part of the
  proof.
