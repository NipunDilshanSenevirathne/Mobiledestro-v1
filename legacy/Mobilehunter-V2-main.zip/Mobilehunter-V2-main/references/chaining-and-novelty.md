# Chain Synthesis + Novelty/Dedup Scoring

The layer that turns primitives into non-dup critical/high. A scanner notes "WebView JS
enabled"; this skill reports the **chain** to ATO with a device PoC.

## A. Canonical chains (build your own per target)
- **Deep link (unvalidated `url=`) → WebView → JS bridge `.getToken()` → exfil → ATO**
  (one click from a web page). *The flagship.*
- **Custom-scheme OAuth `redirect_uri` → malicious app intercepts code → ATO.**
- **Exported Activity (renders WebView) → flagship chain** even when the link is "internal".
- **Intent redirection → internal token-bearing component → leak → API access.**
- **ContentProvider path-traversal/SQLi → token DB → backend API → IDOR → cross-tenant.**
- **Pinning bypass → API map → IDOR/BOLA/mass-assignment/business-logic** (the server money).
- **Hardcoded key → Firebase/S3/admin API → privilege escalation / PII.**
- **Insecure storage (token in SharedPreferences) + backup/`run-as` → token theft → ATO.**
- **Biometric gate client-only + exported component → protected screen without auth.**
- **`setWebContentsDebuggingEnabled(true)` → chrome://inspect → JS exec → bridge → ATO.**
- **App Link host subdomain takeover → verified link hijack → OAuth/phishing flow.**
- **Deep link → WebView → bridge → native parser → memory corruption** (top tier).
- **Clipboard/notification token leak → malicious app → ATO.**
- **Firebase open rules → user data dump** (no app interaction needed at all).

For each realized chain write the step graph (entry → primitive → state unlocked → next),
the single end-impact, and prove each hop on your own device/accounts.

## B. Novelty / duplicate-likelihood scoring (before reporting)
Dup-likelihood **UP** (don't lead with these): `allowBackup=true` standalone, missing pinning
as a note, a hardcoded *test* key, debuggable beta build, tapjacking on a non-sensitive
screen, generic MobSF lines, exported component with no reachable sink, "rooted device can
read app files" (of course it can).

Dup-likelihood **DOWN** (report first): a **chain** (≥2 hops), a **reachable** sink proven on
device, a **server-side** authz/logic bug reached through the app, **custom-scheme/App-Link**
ATO, provider data-theft of a real file, a **live** secret with real backend impact,
framework-layer bridges (Flutter/RN) most tooling can't see, reachable native unsafe sinks.

**Rule:** if high-dup, deepen into a chain or note-and-move-on. Submit low-dup fast — chains
decay in novelty as the app updates.

## C. Variant hunting
After one deep-link/WebView/IDOR finding, sweep the *same class in every other context* —
each scheme/host, each exported component, each bridge method, each object type, each API
endpoint. Distinct context + distinct fix = separate, often non-dup finding. Keep them in
separate ledger rows from the start so the sweep is mechanical.

## D. Coverage-gap check
Before reporting: walk the engine list — which engines produced zero rows in the ledger, and
is that because the surface is absent (say so, it's a negative result worth recording) or
because you didn't look (look now)? Report negatives explicitly in the run summary; they
prove thoroughness and protect against triage "did you check X?".
