# Engine: Auth / OAuth / Biometric / Local-Auth + Runtime (MASVS-AUTH)

Mobile auth has unique edges (custom-scheme OAuth, deep-link token leak, client-side
biometric gating). Frida/objection confirms every engine's runtime claims.

## OAuth / SSO on Android (high-value, chainable)
- **Custom-scheme `redirect_uri`** (`myapp://callback`): another app registering the same
  scheme **intercepts the authorization code/token** → ATO. App Links + assetlinks is the
  fix; its absence on an auth callback is the bug.
- **PKCE missing/weak** on a public mobile client → intercepted code is redeemable.
  Check the token exchange: no `code_verifier` = report.
- **`state`/nonce missing** → login CSRF / forced account linking.
- **Account linking** via unverified email → attacker pre-creates/links → pre-account takeover.
- **WebView-based OAuth** → credentials/token visible to app JS; `shouldInterceptRequest`
  skimming; user-agent confusion.
- **Deep-link token emission**: app accepts/emits tokens in links (`myapp://login?token=`) →
  leak via referrer/logs/interception (ties to engines deeplink + ipc).
- **AppAuth/Auth0 SDK misuse**: no EndSession, tokens in browser custom tabs vs WebView,
  redirect_uri validation gaps at the AS (subdomain/open redirect on an allowed redirect).

## Token & session handling
- Long-lived/refresh tokens not rotated or device-bound; token survives logout/password
  change (test against the API directly — Phase 5).
- JWT client-side trust (role claim read by the app without server re-check), `alg:none`,
  RS256→HS256 confusion using the public key as HMAC secret, `kid` path/SQLi.
- **2FA/OTP**: no rate limit / **race the attempt counter** (single-packet parallel), OTP in
  logs/notifications, 2FA enforced on one API path but not another, client-trusted
  `"verified":false` → flip → proceed.

## Biometric / local-auth bypass (client-side trust)
- Auth decision made **client-side**: `onAuthenticationSucceeded` flips a boolean/navigates,
  no Keystore-bound `CryptoObject` → hook the callback (or call the post-auth path via an
  exported component/deep link) → gate is cosmetic.
- `BiometricPrompt` without `CryptoObject` = UI gate. The fix: Keystore key with
  `setUserAuthenticationRequired(true)` released only on auth.
- `setAllowedAuthenticators(BIOMETRIC_WEAK | DEVICE_CREDENTIAL)` accepting class-2 biometrics
  or PIN fallback where policy demands class-3.
- **Proof**: Frida-hook success callback on your own device → reach protected screen/data
  without valid auth. Note Play Integrity / hardware attestation honestly: not fully
  spoofable — don't claim what you can't show.

## Frida / objection runtime (confirms every engine)
- Pinning: `frida_unpin.js` / objection `android sslpinning disable`.
- Root/emulator/debugger detection: `frida_rootbypass.js` — reach the surface (RESILIENCE,
  not the finding itself; many programs exclude root-only issues — check ROE).
- Tracing: `frida_bridge_trace.js` (WebView/bridge), `frida_intent_logger.js` (IPC),
  `frida_crypto_monitor.js` (crypto/logs/storage). `frida-trace -U -f <pkg> -i 'loadUrl'` ad hoc.
- objection quickref: `android sslpinning disable`, `android root disable`,
  `android hooking watch class_method <m> --dump-args --dump-return`,
  `android keystore list`, `memory dump all`, `android clipboard monitor`.

## Test & confirm
Two of **your own** accounts/devices; prove ATO by becoming your second account via the flaw
(scheme-interception PoC app, deep-link token capture at your OOB, OTP race). Biometric:
reach gated data without valid auth on your own device. Show crafted request + result.

## Proof bar & reporting
Map **MASVS-AUTH** (+PLATFORM for scheme issues; RESILIENCE noted as the bypassed gate, not
the bug). ATO chains (custom-scheme code theft, deep-link token leak, OTP race) are
high-severity, low-dup — describe the full path, prove end-to-end on your own accounts.
