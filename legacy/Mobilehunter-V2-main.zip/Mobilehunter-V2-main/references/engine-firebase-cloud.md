# Engine: Firebase & Cloud Misconfiguration

Mobile apps carry their cloud config in the binary. Misconfigured first-party cloud = direct
data access without touching the app at all. Scope: the project/bucket must belong to the
authorized app (found in its binary). Probes are **read-only** except your own seeded writes.
`scripts/firebase_audit.py` automates the Firebase battery.

## Where the config lives
`res/values/strings.xml` (from `google-services.json`): `google_app_id`
(`1:XXXX:android:YYYY` → project number), `firebase_database_url`
(`https://<project>.firebaseio.com` or `...firebasedatabase.app`), `project_id`,
`google_storage_bucket` (`<project>.appspot.com`), `google_api_key` (`AIza...`).
Also hunt: Firestore (`firestore.googleapis.com`), FCM legacy server keys, Dynamic Links
domains (`*.page.link`), Remote Config, App Check presence.

## The battery (each = probe, then judge)
1. **Realtime Database open rules**: `GET https://<db>/.json` → 200 with data = open read
   (critical if user data). `/.json?shallow=true` for structure. Open **write**: PUT only a
   doc YOU create under a test path (e.g. `/bugbounty-test-<rand>.json`) — prove, then delete
   it. Never touch real nodes.
2. **Firestore rules**: `GET https://firestore.googleapis.com/v1/projects/<p>/databases/(default)/documents/<guess>` —
   200 = open collection. Common collection names from the binary's strings (`users`,
   `orders`, `tokens`). Auth'd-with-API-key enumeration via Identity Toolkit is an active
   step — only if ROE allows account creation; note otherwise.
3. **Storage bucket**: `GET https://firebasestorage.googleapis.com/v0/b/<bucket>/o?maxResults=1`
   → listing = open read. Upload your own harmless test file only if writes must be proven;
   delete after. GCS-native: `https://storage.googleapis.com/storage/v1/b/<bucket>/o`.
4. **Google API key restrictions**: an unrestricted `AIza` key usable for paid APIs (Maps,
   etc.) = quota/financial abuse (usually low; program-dependent). The same key against
   Identity Toolkit `signUp`/`signInWithPassword` = email enumeration surface — report the
   enumeration, don't mass-probe.
5. **FCM legacy server key** in the binary (`AAAA...`) → send push to every user = phishing
   amplification (high). Validate by sending ONLY to your own device's token.
6. **Dynamic Links / `.page.link`** domain misconfig → link spoofing under the app's brand.

## Beyond Firebase (same discipline)
- **S3**: `https://<bucket>.s3.amazonaws.com/?list-type=2&max-keys=1` → listing = open read.
  PUT a test object only to prove write; delete it.
- **GCS/Azure blobs**: same list probe patterns.
- **Exposed service-account JSON** (`"type": "service_account"`, `private_key`) in assets =
  full cloud compromise tier — validate read-only (token exchange, then a list call), redact
  heavily, report fast.
- **Third-party SaaS keys** (Algolia admin, SendGrid, Twilio, Stripe `sk_live`): validate
  benignly (a single harmless read/your-own-account call), classify, and respect scope —
  third-party platforms are usually OUT of program scope: report to the app owner as
  credential exposure (the secret is in the shipped binary = the finding), don't exercise
  the third party beyond minimal validation.

## Proof bar
HTTP request + response (redacted) showing open access to *structure/your own seeded data*,
the binary location of the config (file:string), and the chain (open DB → user PII fields
present). Map **MASVS-NETWORK**/**STORAGE** + CWE-200. These are classic high-value,
medium-dup findings — the differentiator is proving *impact* (what data class is exposed),
not just "rules are open".
