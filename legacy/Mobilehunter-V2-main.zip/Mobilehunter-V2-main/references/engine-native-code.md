# Engine: Native Code — .so / JNI / memory-corruption surface

The tier most mobile hunters skip — and where the deepest bugs (and highest bounties) live.
You don't need to find a full exploit: finding a **reachable** native entry fed by untrusted
data + a memory-unsafe operation is a reportable, high-novelty lead.

## Inventory
- `lib/<abi>/*.so` (all abis — arm64-v8a is the prize; check x86 builds for debug leftovers).
- From jadx: `System.loadLibrary("...")`, `native` method declarations, classes with JNI.
- Hardening check: `rabin2 -I lib.so` / `r2 -I` — PIE, NX, stack canaries, RELRO, FORTIFY.
  Missing hardening on a parsing lib strengthens impact claims.

## Hardcoded secrets & logic in native (most common win)
- Devs hide API keys/passwords/HMAC secrets in `.so` thinking it's safe. It isn't:
  `strings -a lib.so | grep -iE 'key|secret|token|pass|api'`, plus `secrets_hunter.py` scans
  libs with the same regex+entropy engine.
- Look for obfuscated builders (XOR loops against `.rodata`) — decompile with
  `r2 -A`/`pdg` (or Ghidra if installed) around `Java_<pkg>_*` exports.
- License/DRM/feature-flag checks in native = client-side trust (same bypass logic as Java).

## JNI attack surface
- **Static registration**: exports named `Java_com_pkg_Class_method` — map each to its Java
  caller and trace what untrusted data reaches it (deep link params, intent extras, IPC,
  files, network responses).
- **Dynamic registration**: `JNI_OnLoad` → `RegisterNatives` table — find it in r2/Ghidra
  (`jni`/`RegisterNatives` xrefs); the method table maps names → native addresses.
- **Type confusion**: JNI method signature vs actual jobject usage; direct buffers
  (`GetDirectBufferAddress` trusting Java-side capacity); `GetStringUTFChars` length trust.
- Exceptions: native code not checking `ExceptionCheck` after JNI calls → UB paths.

## Memory-corruption hunting (reachability-first)
Prioritize parsers of attacker-controlled bytes: media/docs/files opened from IPC, downloads,
push payloads, deep-link params, clipboard. In decompiled pseudocode (`pdg`/Ghidra) flag:
- `strcpy/strcat/sprintf/gets/memcpy` with lengths from input or unchecked sources;
- integer overflow before `malloc`/`calloc` (length arithmetic on 32-bit ints);
- length-prefixed formats trusting the prefix (OOB read → info leak; OOB write → corruption);
- use-after-free patterns: global/static pointers, double `Release*` calls, callbacks storing
  Java references wrongly (local ref cached as global);
- format strings: `printf(var)` / `snprintf(dst,n,var)` with input-derived format.
- Zip path traversal in native or Java unzipping (`ZipEntry` name with `../` written
  unsanitized) → arbitrary file write → RCE potential (overwrite dex/so loaded later).
- `dlopen`/`System.load` of paths built from writable storage → library injection.

## Triage honestly
- A reachable unsafe sink + untrusted input = strong lead; a crash PoC (fuzzer or hand-built
  input via the entry point) = confirmed finding. Watch `logcat` for `SIGSEGV/SIGABRT` +
  tombstones during fuzzing (`intent_fuzzer.sh`, file-format inputs via the provider engine).
- Most programs treat "crash only" lower than demonstrable control; state exactly what you
  proved (crash, controlled registers, info leak) — no inflation.

## Chain it
Native secret → backend API (engine-network). Zip traversal → overwrite → RCE chain.
Bridge method calling into native (flagship chain variant: deep link → WebView → JS bridge →
native parse → memory corruption = the top-tier chain).
