# AI Orchestration — running the hunt natively in Kimi Code CLI

This skill's edge over v1 is orchestration: parallel engine subagents (AgentSwarm), background
tasks for slow dynamic work, and a ledger that keeps reasoning honest.

## The ledger (single source of truth)

`loot/<appid>/ledger.md` — one row per hypothesis:

```
| id | engine | hypothesis (entry → sink → impact) | evidence (class:line) | dynamic test | status | novelty |
```

Statuses: `hypothesis → testing → confirmed | refuted | blocked`. Every subagent reads the
ledger first (no duplicate work) and appends rows (never rewrites others'). The parent agent
owns merging and chain synthesis.

## AgentSwarm — parallel engine sweep (Phase 3)

Launch one explore/coder subagent per engine whose preconditions the model satisfies.
Prompt template per engine subagent:

```
You are the <ENGINE> hunter for an authorized Android security assessment.
Target workspace: loot/<appid>/ (unpacked/ = apktool, jadx/ = decompiled Java).
Read first: loot/<appid>/model.md, loot/<appid>/ledger.md, and your engine guide at
~/.kimi-code/skills/androidhunter-ultimate/references/<engine-file>.md.
Also use: manifest_analysis.json, deeplinks.txt, webview.txt, api_surface.txt, secrets.txt.
Hunt ONLY for your engine's classes. For each hypothesis: cite class/method/line from jadx,
state the exact dynamic test that would confirm it, and append a row to ledger.md.
Rank by impact × reachability × novelty. Do NOT fire network traffic or intents — static only.
Return: top hypotheses with citations, ranked, plus what you ruled out and why.
```

Rules:
- Pass exact paths — subagents start with zero context.
- Engine subagents are **static-only** (explore type fits). Dynamic confirmation is the
  parent's job (Phase 4) so device state and the scope gate stay centralized.
- Cap fan-out at what the target justifies (a thin app may only warrant 3 engines).
- Prefer `AgentSwarm` with one item per engine file; resume agents for follow-up questions
  instead of respawning.

## Background tasks — slow dynamic work (Phase 4)

Device work blocks: fuzzing sweeps, logcat captures, long Frida traces. Run them as Kimi
background tasks and keep reasoning meanwhile:

- `scripts/deeplink_fuzz.sh` (generated) — sweep the URI matrix → background.
- `scripts/intent_fuzzer.sh` — component fuzzing + crash capture → background.
- `adb logcat -c && adb logcat > loot/<appid>/logcat/live.txt` — long capture → background.
- Frida tracing sessions → background with output to `loot/<appid>/frida/`.

When a background task completes, its result arrives automatically — fold crashes/OOB hits
back into the ledger and chase the leads.

## TodoList — keep the pipeline visible

Track phases as todos (intake → recon → engines → dynamic → bridge → chains → triage →
report). Exactly one in_progress. It keeps long hunts resumable across context compaction.

## Context discipline

- The parent holds: model.md essence, ledger, chain graph, triage. Subagents hold file dumps.
- Never paste whole decompiled files into your own context — point subagents at paths and ask
  for citations.
- After compaction: re-read `model.md` + `ledger.md` — they are the resumable state.

## Degradation contract

No device attached → static-only hunt; every finding labeled `unconfirmed — needs device PoC`.
No tool execution at all → analysis-only; label everything `Hypothesis`. Never dress
unverified analysis up as confirmed.
