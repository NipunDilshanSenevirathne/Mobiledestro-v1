# Static Deep-Dive — reading an APK like an auditor, not a scanner

`scripts/static_recon.sh` extracts the surface mechanically. This guide is how **you** read
what it found and build the model the engines attack. The model is the skill.

## 1. Manifest — the real routing table

`manifest_analyze.py` resolves the tricky parts; verify by reading when it matters:

- **Implicit export rules**: any component with an `<intent-filter>` and no explicit
  `android:exported` is exported when `targetSdkVersion < 31`; on 31+ it must be explicit
  (install fails otherwise). `LAUNCHER`-category activities are always exported.
- **Deep links**: `<data>` combinations matter: scheme+host+path(prefix/pattern). Traps:
  - `android:scheme="https"` with **no host** → matches every https URL → link hijacking surface.
  - wildcard host `*.example.com` with no path constraint → any subdomain (incl. a taken-over
    one) routes in.
  - `pathPattern` uses Android's limited glob (`.*` works, regex doesn't) — `.` matches any
    char: `pathPattern="/..*"` quirks, over-broad patterns.
  - `autoVerify="true"` (App Links): verification fetches
    `https://<host>/.well-known/assetlinks.json`. **Every** host in the filter must verify;
    one failing subdomain degrades the filter to "ask user" (disambiguation dialog = hijack
    window) or silently routes unverified links on some paths. A **subdomain takeover** of a
    listed host → attacker serves their own assetlinks → **verified App Link hijack**.
- **Deep links registered in code**: androidx Navigation (`navDeepLink`), Firebase Dynamic
  Links, Branch/AppsFlyer/Adjust SDKs, `AppLinks` — grep jadx for `navDeepLink`, `uriPattern`,
  `branch.io`, `applinks`, `onNewIntent`. The manifest is not the whole table.
- **Providers**: exported? `grantUriPermissions`? `path-permission` narrowing? A provider with
  `exported="false"` + `grantUriPermissions="true"` is still reachable via an intent carrying
  `FLAG_GRANT_READ_URI_PERMISSION` — chained through any exported component that forwards
  intents (see intent redirection).
- **Custom permissions**: `protectionLevel="normal"` = any app can hold it = **no protection**.
  Only `signature` protects. Also permission *defined* by the app vs *used*.
- **`sharedUserId`** — shares process/UID/data with any app signed with the same cert.
- **`taskAffinity` + `allowTaskReparenting` + `launchMode`** — StrandHogg task-hijack math.
- **`<queries>`** — reveals what the app probes for (enumeration surface), not a vuln.
- **`networkSecurityConfig`** — parse `res/xml/*network*security*.xml`:
  `<base-config cleartextTrafficPermitted>`, per-`<domain-config>` cleartext exceptions,
  `<pin-set>` with **expiration** (expired pins = silently unprotected), `<debug-overrides>`
  left in, `trust-anchors` adding `<certificates src="user"/>` (accepts user-installed CAs →
  trivial MITM on non-rooted devices).
- **Flags**: `debuggable`, `allowBackup` (+ `dataExtractionRules`/`fullBackupContent` on 12+),
  `usesCleartextTraffic`, `extractNativeLibs`, `usesNonSdkApi`.

## 2. Code — where you earn the chains

Read jadx with these threads, in order:

1. **Entry flow**: from each exported component / deep link handler, follow `getIntent()`,
   `getData()`, `getQueryParameter()`, `get*Extra()` into the app. What class/method consumes
   attacker input? Where does it land (WebView load, startActivity, file op, SQL, crypto,
   reflection)? That landing is your sink. This is reachability reasoning — no tool does it.
2. **WebViews**: every `WebView` instantiation → settings (`setJavaScriptEnabled`,
   `setAllowFileAccess`, `setAllowUniversalAccessFromFileURLs`, mixed content) →
   `addJavascriptInterface(obj, "name")` → **read that object's `@JavascriptInterface`
   methods** — what do they expose (tokens, files, intents, native calls)? →
   `WebViewClient.shouldOverrideUrlLoading` allowlist logic (see engine-deeplink-webview for
   the bypass corpus) → `onReceivedSslError` calling `handler.proceed()` (standalone finding:
   MITM-able WebView).
3. **API layer**: Retrofit interfaces (`@GET/@POST/@PUT/@DELETE` — full endpoint inventory),
   OkHttp interceptors (auth header assembly, request **signing**/HMAC — replicate it to call
   the API directly), base-url selection (debug URLs left in flavors?), certificate pinning
   config, authenticator/refresh logic.
4. **Auth/session**: token storage, refresh flow, logout (server invalidation?), JWT handling
   (client-side trust of claims), OAuth (custom scheme redirect? PKCE? state?),
   BiometricPrompt usage (CryptoObject bound or bare UI gate?).
5. **Storage/crypto**: SharedPreferences/DataStore/SQLite/Realm writes of tokens/PII;
   Keystore usage (auth-bound keys?); hardcoded keys/IVs; ECB/static-IV/weak-KDF/custom crypto;
   `Log.*` calls carrying sensitive data (release ProGuard may strip — verify in smali, not
   hope).
6. **SDK inventory** (`sdks.txt`): analytics/ads/crash SDKs with their own WebViews/bridges
   (often weaker than first-party code), outdated versions with known CVEs, their endpoint
   domains (out of scope unless listed — note only).
7. **Native**: `System.loadLibrary`, `native` method declarations, `JNI_OnLoad` presence in
   libs → hand to engine-native-code.

## 3. Secrets & endpoints

`secrets_hunter.py` gives candidates with file:line. **Every candidate is unvalidated until
proven live**: does the key work against its backend (benign, authorized probe)? Live key →
real finding + chain. Dead/test key → note only (high-dup). Endpoints feed `api_surface.txt` →
the network engine and Phase 5 access matrix. Cross-check domains against
`scope/authorized_api_domains.txt` before anything active.

## 4. Output: model.md

Fill the seeded template until you can answer, with citations: *what can reach this app from
outside, what does each entry trust, where does untrusted input land, what does the bridge
expose, how does the client authenticate to the backend, and which of those can be bypassed?*
If you can't answer one, that gap is your next reading task — not a reason to start firing.
