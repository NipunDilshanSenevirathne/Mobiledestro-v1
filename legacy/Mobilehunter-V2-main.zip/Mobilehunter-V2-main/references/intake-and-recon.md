# Intake & Acquisition — store URL / APK / XAPK → unpacked, fingerprinted target

`scripts/app_intake.sh` automates this. Read this when it hits an edge case.

## A. Parse the input

- Play Store: `https://play.google.com/store/apps/details?id=com.x` → package `com.x`.
- Local file: `.apk` (single), `.xapk/.apks/.apkm` (split bundle archives).
- After unpack, **re-derive the real package id from the manifest** (`aapt2 dump badging` or
  the decoded `AndroidManifest.xml`) — never trust a filename, and gate on the real id.

## B. Acquire the binary (authorized ids only)

- `apkeep -a com.x .` — pulls from Google Play (anonymous) or mirrors. Splits arrive as
  `.xapk`. Free apps only; region/device restrictions can block some.
- Mirrors (APKPure/APKMirror) — manual download; **verify the signing cert matches the
  official app** (see E) before trusting the binary: a tampered re-pack poisons every
  conclusion you draw from it.
- Supplied `.apk/.xapk` — copy it in.

## C. Splits (XAPK/APKS/APKM)

Modern apps ship split APKs: `base.apk` + `config.<abi>.apk`, `config.<dpi>.apk`,
`config.<lang>.apk`, feature splits (`dynamic_feature`). Archive = zip of APKs (+ manifest
json for APKM).

1. Unzip the archive → `splits/`.
2. Analyze **every** split: native libs live in the abi split, resources in dpi splits, extra
   code can live in feature splits. `apktool d` each; `jadx` the base + feature splits.
3. For device install later: `adb install-multiple splits/*.apk`.
4. For AAB (rare outside Play delivery): needs `bundletool` to build APKs
   (`bundletool build-apks --bundle=app.aab --mode=universal`); note in limits if unavailable.

## D. Unpack

- `apktool d -f app.apk -o unpacked/` → decoded manifest, resources, smali.
- `jadx -d jadx/ app.apk` → readable Java (your primary reading source). jadx falls behind on
  some obfuscation; keep `unpacked/smali*` as ground truth for exact semantics
  (`apktool` smali is never wrong about behavior, only ugly).
- `unzip` → raw `assets/`, `lib/<abi>/*.so`, `res/raw`, `META-INF`.
- **Packer/protector detection**: run `apkid app.apk`. If packed (DexProtector, Bangcle,
  qihoo, DexGuard "packer mode"), jadx shows only stub loaders. Options: dump at runtime
  (FRIDA-DEXDump / `frida-dexdump` on your own device) then analyze the dumped dex — note the
  extra step in the run summary.

## E. Fingerprint & integrity

- `apksigner verify --print-certs app.apk` → signing cert SHA-256.
  - **Debug cert** (`CN=Android Debug`) in a store build → finding candidate (signed with a
    publicly-known key: anyone can sign "updates"/same-`sharedUserId` apps).
  - v1-scheme-only signing on a modern-target app → Janus-class concerns on old platforms;
    note, rarely reportable alone.
  - Same cert across a vendor's apps + `sharedUserId` → cross-app privilege sharing surface.
- `aapt2 dump badging` → versionCode/name, min/target SDK, uses-features, launchable activity.
- Record everything in `loot/<appid>/intake.md`.

## F. Seed the workspace

`app_intake.sh` creates:

```
loot/<appid>/
  app.apk | splits/            the binary (ground truth — keep)
  unpacked/                    apktool decode (manifest/resources/smali)
  jadx/                        decompiled Java
  model.md                     (you fill in Phase 2)
  intake.md                    versions, certs, hashes, packer notes
  ledger.md                    hunt ledger (hypothesis → test → status → novelty)
```

Hashes: `sha256sum` the APK into `intake.md` — ties every finding to an exact build.
