# Engine: Network → Backend API (pinning bypass → IDOR/BOLA/logic)

**The biggest mobile money bug is usually server-side.** The app is a thin client; once you
see the traffic and map the API, hunt IDOR/BOLA, mass assignment, business logic, broken auth
on the backend — which affects every client. This engine bridges mobile → API hunting.

## Step 1 — visibility (defeat the client's protections; RESILIENCE is the gate, not the bug)
- Route the device through Burp/mitmproxy (`setup_device.sh`): Wi-Fi proxy or
  `adb shell settings put global http_proxy <host>:<port>`; proxy-unaware apps need
  iptables redirect (rooted emulator) or a VPN-based capture (PCAPdroid-style).
- CA install: user store (needs app to trust user certs — check networkSecurityConfig) or
  system store on emulator/rooted (`/system/etc/security/cacerts/<hash>.0`).
- **Pinning bypass** — `frida -U -f <pkg> -l scripts/frida_unpin.js --no-pause`
  (or `objection -g <pkg> explore` → `android sslpinning disable`):
  - OkHttp `CertificatePinner`, custom `X509TrustManager`s (script enumerates all loaded
    implementations), Conscrypt `TrustManagerImpl.verifyChain`, `HostnameVerifier`,
    WebView `onReceivedSslError`, TrustKit/Appmattus.
  - **Flutter**: pinning lives in BoringSSL inside `libflutter.so` — needs pattern-hooked
    `ssl_crypto_x509_session_verify_cert_chain` (reFlutter) — see engine-cross-platform.
- Goal: full API visibility with YOUR OWN test accounts. Pinning absence is a note, not a
  finding; what it gates is the finding.

Also grep for `onReceivedSslError → handler.proceed()` and trust-all
`TrustManager`/`HostnameVerifier` in first-party code — those ARE findings (MITM-able).

## Step 2 — map the API (static × live)
- From jadx: Retrofit interfaces (`@GET/@POST/...` = full endpoint inventory), OkHttp
  interceptors (auth header assembly, **request signing/HMAC** — replicate the signer in a
  script to call endpoints directly), authenticator/refresh flow, base-url switching.
- From traffic: actual paths, object references (`/orders/{id}`, `/users/{uuid}`), GraphQL,
  parameters the UI never shows (mass-assignment candidates).
- Output: `loot/<appid>/api_map.md` (endpoint, method, auth, object ids, notes).

## Step 3 — server-side classes (the money)
Scope-gate every host (`scripts/scope_gate.sh api <host>`), then with **two of your own
accounts**:
- **IDOR/BOLA/cross-tenant**: `scripts/access_matrix.py --requests reqs.txt --session-a A
  --session-b B` — replays object-scoped calls under session B, flags 200s that look like
  session A's data. The mobile UI often hides authz gaps the raw API exposes.
- **Mass assignment / excessive data exposure**: add `role`, `isAdmin`, `ownerId`,
  `tenantId`, `price`, `status` (names from the binary); diff raw JSON vs what the app renders.
- **Business logic / race**: IAP receipt validation (server verify with Google? replayable
  receipts? restore-purchase abuse), wallet/topup/rewards/referral flows — replay, tamper,
  single-packet race (Burp Turbo Intruder / parallel curl).
- **Broken auth/token**: refresh rotation, token not invalidated on logout/password change,
  device binding, OTP endpoints (rate limit, race the attempt counter), JWT (`alg:none`,
  RS256→HS256 with the public key as HMAC secret, `kid` injection).
- **GraphQL**: introspection, field suggestions, batching abuse, authorization per-resolver.

## Step 4 — mobile-specific network notes
- Cleartext endpoints (`usesCleartextTraffic`, per-domain NSC exceptions) → hostile-network MITM.
- Pinning absent on some hosts only; tokens leaking to third-party analytics in headers/body.
- API keys from the binary used directly against the backend (engine-storage hands these over).

## Proof bar & reporting
- Prove server-side findings with **your own two accounts + seeded objects**: exact request
  (token redacted), cross-account access, and the control that correctly denies.
- Note the pinning bypass was only to observe your own authorized traffic — the finding is the
  server flaw, reachable by any client.
- Map **MASVS-NETWORK** (transit) + the backend authz class. Highest-severity, lowest-dup
  results in mobile hunting, because few hunters push past the client into the API.
