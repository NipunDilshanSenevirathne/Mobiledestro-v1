# Research Grounding — frameworks, economics, technique sources

Ground every hunt in OWASP MAS and current public research. Keep technique notes current;
the chainable classes below are where non-dup critical/high live.

## The framework: OWASP MASVS / MASTG / MASWE
Test against the MASVS control groups; map every finding to a MASWE weakness id:
- **MASVS-STORAGE** — data at rest (Prefs/SQLite/Keystore/caches/logs/backups).
- **MASVS-CRYPTO** — key management, weak/hardcoded crypto.
- **MASVS-AUTH** — auth/authorization, tokens, biometric/local-auth.
- **MASVS-NETWORK** — TLS, pinning, data in transit.
- **MASVS-PLATFORM** — IPC, deep links/App Links, WebView/JS bridge, exported components,
  clipboard. **(richest chain surface)**
- **MASVS-CODE** — input handling, injection, third-party SDKs, deserialization.
- **MASVS-RESILIENCE** — anti-tamper/root/pinning (bypass to *reach* the surface — usually
  not a finding itself; many programs exclude it).
MASTG (mas.owasp.org/MASTG) gives concrete per-requirement test procedures — cite test ids
in reports.

## What duplicates vs what doesn't
- **Saturated/dup:** `allowBackup=true` standalone, missing pinning as a note, hardcoded
  *test* keys, debuggable beta, tapjacking on non-sensitive screens, generic MobSF output,
  "rooted device reads app data".
- **Low-dup, high-pay (chainable, reasoning-required):**
  - Deep link / App Link mis-validation → WebView → JS bridge → token theft / file read → ATO.
  - Exported component / intent redirection / confused deputy; ContentProvider SQLi /
    path-traversal → file theft.
  - Pinning bypass → backend API → IDOR/BOLA/mass-assignment/business-logic (the real money;
    the app is just a client).
  - OAuth custom-scheme redirect / deep-link token leak / missing PKCE → code/token theft → ATO.
  - Hardcoded secrets/keys → live backend/cloud access (Firebase/S3/service accounts).
  - Framework-layer bridges (Flutter MethodChannels, RN @ReactMethod, Capacitor plugins)
    and Flutter BoringSSL pinning — most tooling can't see them.
  - Native (.so/JNI) reachable memory-unsafe sinks; zip path traversal; dynamic library
    loading from writable paths.

## Key technique notes (stable, technique-level)
- **Deep links → WebView**: unvalidated deep-link param loaded into a WebView → attacker
  page runs `javascript:`/`file://`/`content://`, reaches the bridge → ATO/file theft.
  Fix = strict navigation allowlist in `WebViewClient` + scheme/host validation; absence =
  the bug. (Grab H1 #401793; Oversecured research.)
- **addJavascriptInterface**: exposes native methods to JS; dangerous when token/auth/file
  methods are reachable from attacker-controlled WebView content (pre-Android-4.2 = full RCE
  via reflection; modern = the exposed methods are the surface).
- **Exported components / protected-component access**: intent redirection reaches
  non-exported internals via a forwarding exported component (Oversecured pattern).
- **App Links**: every host in an `autoVerify` filter must serve valid assetlinks.json;
  subdomain takeover → verified link hijack.
- **Pinning bypass**: objection/Frida generic TrustManager hooks; Flutter needs BoringSSL
  pattern hooks (reFlutter) — Java-layer hooks don't touch it.
- **Bounty economics**: platform vendors pay the most for *chains* (full exploit chains and
  cross-app ATOs), which is exactly this skill's orientation — chaining is the value path.

## Tooling map (this machine's stack; preflight verifies)
- Acquire: `apkeep`, supplied APK/XAPK; splits via unzip + `adb install-multiple`.
- Static: `apktool`, `jadx`, `aapt2`, `apksigner`, `apkid`, `strings`, `r2`/`rabin2`.
- Secrets: `secrets_hunter.py` (regex+entropy), `apkleaks`, `trufflehog`, `semgrep`.
- Dynamic: `frida`/`frida-server`, `objection`, `adb`, Burp Suite, `mitmproxy`.
- Backend bridge: `access_matrix.py` on captured API requests with your own two sessions.

## Sources (read fresh versions; technique docs age well, stats don't)
- OWASP MAS (MASVS/MASTG/MASWE): https://mas.owasp.org/ · https://mas.owasp.org/MASTG/
- Oversecured — access to protected Android components:
  https://oversecured.com/blog/android-access-to-app-protected-components
- Grab insecure deeplink (H1 #401793): https://hackerone.com/reports/401793
- 0xn3va Android cheat sheets (deeplink/intent classes):
  https://0xn3va.gitbook.io/cheat-sheets/android-application/intent-vulnerabilities/deep-linking-vulnerabilities
- WebView JS-interface exploitation:
  https://hulkvision.github.io/blog/javascript-interface/exploiting-javascript-interface/
- Frida: https://frida.re/docs/home/ · objection: https://github.com/sensepost/objection
- reFlutter (Flutter pinning/traffic): https://github.com/Impact-I/reFlutter
- Android App Links verification: https://developer.android.com/training/app-links/verify-android-applinks
- Bugcrowd LevelUp Android bug-bounty skills:
  https://www.bugcrowd.com/resources/levelup/advanced-android-bug-bounty-skills/
