# Engine: Cross-Platform Frameworks — Flutter / React Native / Unity / Capacitor

Framework apps shift the surface: business logic lives in a snapshot/bundle, and the "bridge"
between framework and native is the new JS-bridge. Identify first (`native.txt`/`sdks.txt`):
`libflutter.so`+`libapp.so` = Flutter; `index.android.bundle`+`libhermes.so` = RN;
`libil2cpp.so` = Unity il2cpp; Capacitor/Cordova = `capacitor.config`/`cordova.js`.

## Flutter
- Logic is Dart AOT in `libapp.so` (per-abi). Strings/endpoints/secrets:
  `strings -a lib/arm64-v8a/libapp.so | grep -E 'https?://|api|key|token'`.
- **Pinning bypass**: Flutter uses its own BoringSSL in `libflutter.so` — Java-layer unpinning
  does nothing. Options: **reFlutter** (patched libflutter + traffic monitoring) or Frida
  pattern-hook on `ssl_crypto_x509_session_verify_cert_chain` (scan the lib for the known
  byte pattern, hook, force return 1). State which you used; if neither lands, say so.
- **MethodChannel/EventChannel** = the bridge: Dart side calls channels by name
  (`MethodChannel('app/auth')`), native side handles them in `onMethodCall` — grep jadx for
  `setMethodCallHandler`, `MethodChannel(`. Every handler is a JS-bridge-equivalent: what
  does it expose (tokens, files, intents)?
- Deep links: same manifest analysis; plugins `uni_links`/`app_links` route into Dart —
  trace the Dart handler via strings around the channel/route names.
- `flutter_secure_storage` → EncryptedSharedPreferences/Keystore (fine) vs
  `shared_preferences` for tokens (plaintext XML — finding).

## React Native
- `assets/index.android.bundle`: plain JS (readable — hunt it like source) or Hermes
  bytecode (strings still leak; `hermes-dec`/hbcdump if available decompiles roughly).
  Source maps (`index.android.bundle.map`) left in release = original TS source — huge.
- **Native modules**: `@ReactMethod` in jadx = bridge-exposed methods (same audit as
  `@JavascriptInterface`). `NativeModules.X.method` callable from any JS the app runs —
  combined with a JS-injection vector = RCE-grade chain.
- `AsyncStorage` = unencrypted SQLite (`RKStorage`) — tokens at rest in cleartext.
- **OTA update integrity** (CodePush/custom): if update bundles aren't signature-verified
  against an embedded public key, a compromised update channel = arbitrary JS execution.
  Assess; server compromise is out of scope — note the client-side verification gap.
- WebViews inside RN (`react-native-webview`) — same WebView engine rules, often weaker
  defaults (`originWhitelist={['*']}`, `javaScriptEnabled` + bridge props).

## Unity
- **il2cpp**: `libil2cpp.so` + `assets/bin/Data/Managed/Metadata/global-metadata.dat` →
  Il2CppDumper → dummy DLLs → dnSpy/ILSpy reading: endpoints, secrets, cert-handler overrides.
- **Mono** (older): `assets/bin/Data/Managed/*.dll` → dnSpy directly.
- `UnityWebRequest` with a `CertificateHandler` accepting all certs (validate always-true) =
  MITM. Hardcoded keys in metadata strings via Il2CppDumper string dump.

## Capacitor / Cordova
- `capacitor.config.json`/`config.xml`: a `server.url` pointing at a remote origin means the
  whole app is that site inside a native shell — remote content + native bridge plugins =
  the flagship chain with zero local code needed; `http://` there is critical.
- Plugin bridges (`cordova.exec`, Capacitor `Plugins.X`) expose native features to whatever
  JS runs in the WebView — audit `allowNavigation`/allowlist config; any reachable
  attacker-JS (deep link → WebView) reaches the plugins.

## Reporting notes
Same proof bar as first-party code: reachable entry → bridge/native exposure → impact, proven
on device with your own account. Framework findings are low-dup because most hunters' tooling
(MobSF & co) barely parses them — call that out in the novelty note.
