# Dynamic Instrumentation — device setup, Frida mastery, traffic capture

Everything here runs on **your own device/emulator with your own test accounts**.
`scripts/setup_device.sh` automates the boring parts; this is the operator's guide.

## 1. Environment choices
- **Rooted emulator** (AVD without Play Store image → `adb root` works; or rootAVD/Magisk on
  an image) — easiest full-power setup: system CA, frida-server, writable /system.
- **Physical rooted device** (Magisk) — for apps with emulator detection you can't bypass.
- **Non-root fallback**: repackage the APK with Frida Gadget (`objection patchapk`) and your
  own debug key — note the signature change (some apps check it; Play Integrity will differ).

## 2. setup_device.sh does
- Detect device + ABI (`ro.product.cpu.abi`), check root (`adb root` / `su -c id`).
- Download the frida-server matching the **host's** `frida --version`, push to
  `/data/local/tmp`, chmod, launch (background, optionally on a non-default port and renamed
  process to dodge trivial frida detection: `-l 0.0.0.0:27042` etc.).
- Install your Burp/mitmproxy CA: DER → PEM → `<subject_hash_old>.0` → system store
  (emulator `adb remount` / `mount -o rw,remount /system`) or user store fallback (works only
  if the app's networkSecurityConfig trusts user certs — check `flags.txt`).
- Set the proxy: `adb shell settings put global http_proxy <host-ip>:8080` (revert with
  `:0`). Proxy-unaware apps → iptables DNAT on rooted devices or VPN-based capture.

## 3. Frida craft
- **Spawn vs attach**: `frida -U -f <pkg> -l script.js --no-pause` (spawn = hooks before app
  logic; needed for early pinning/detection) vs `frida -U -n <name> -l script.js` (attach).
- **Enumerate then hook** (the scripts do this): `Java.enumerateLoadedClasses` +
  `Java.choose`; enumerate all classes implementing `X509TrustManager` and hook generically —
  that's how `frida_unpin.js` beats per-app custom pinning.
- **Trace**: `frida-trace -U -f <pkg> -i 'loadUrl' -i 'shouldOverrideUrlLoading' -j '*!*Extra*'`.
- **Native**: `Interceptor.attach(Module.findExportByName('libx.so','Java_...'))`,
  `Memory.scan` for token patterns, `Stalker` for coverage during fuzzing.
- **Anti-anti-frida**: renamed server binary, custom port, `hluda`/patch-and-repackage
  approaches; hook the app's own frida checks (maps scan, port connect, `gum-js-loop` thread
  name, `/proc/net/tcp` 27047). Keep honest limits: strong Play Integrity/hardware
  attestation isn't reliably spoofable — report what you proved.
- **objection quickref**: `objection -g <pkg> explore` → `android sslpinning disable`,
  `android root disable`, `android hooking watch class <cls> --dump-args --dump-backtrace
  --dump-return`, `android hooking search classes webview`, `android keystore list`,
  `memory dump all /tmp/app.dump`, `android clipboard monitor`, `env`.

## 4. The script suite (what each proves)
- `frida_unpin.js` — traffic visibility (gate for Phase 5).
- `frida_rootbypass.js` — reach surface behind root/emulator/debugger checks.
- `frida_bridge_trace.js` — enumerate `@JavascriptInterface` methods at runtime + hook them;
  log every `loadUrl`/`shouldOverrideUrlLoading` decision with arguments. Confirms the
  flagship chain's reachability.
- `frida_intent_logger.js` — startActivity/sendBroadcast/PendingIntent flows with extras →
  spot data leaks and forwarding primitives for intent redirection.
- `frida_crypto_monitor.js` — Cipher init keys/IVs, Keystore ops, `Log.*` output, SQLite
  statements, Prefs writes → runtime secret leakage and weak-crypto proof.

## 5. Traffic capture
- Burp Suite (8080) or mitmproxy (`mitmproxy --listen-port 8080 -w loot/<appid>/flows.mitm`).
- Reproduce request signing: port the app's HMAC/signing interceptor (from jadx) into a small
  python signer → call any endpoint directly for Phase 5.
- Save interesting requests as curl-able text for `access_matrix.py`.

## 6. Crash & evidence handling
- Long captures → Kimi background tasks: `adb logcat > loot/<appid>/logcat/live.txt`.
- Crashes: `FATAL EXCEPTION` (Java) and tombstones (`/data/tombstones`, root) for native —
  save into `loot/<appid>/findings/<id>/evidence/`, dedupe by stack hash.
- Redact tokens in anything you keep; evidence is for the report, not the loot pile.
