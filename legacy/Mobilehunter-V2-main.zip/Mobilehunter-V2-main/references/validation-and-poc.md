# Validation & PoC — proof bar, exploit packaging, report format

Same standard as the web skills: **prove it on your own device/account, or label it
unconfirmed.** Never use a real user's data.

## The proof bar per class
- **Deep-link → WebView → JS-bridge**: fire the link as an external attacker
  (`deeplink_probe.sh` / browser page), serve a PoC page at your OOB calling the bridge,
  **capture your own account's token / a local file** at the OOB. Cite the unvalidated
  forward in decompiled code.
- **Exported component / intent redirection**: PoC app or `adb`/`content` CLI triggers it;
  you **observe the unauthorized action / leaked data** (your own account). Providers: SQLi
  dump / traversal read of your own seeded file.
- **Network/API (server-side)**: two of **your own** accounts + seeded objects; exact request
  (token redacted) + cross-account access + the control that denies.
- **Storage/secrets**: exact path + cleartext value from your own session, or live-secret
  proof via a benign authorized call.
- **Auth/OAuth/biometric**: become **your own second account** via the flaw, or reach
  biometric-gated data without valid auth on your own device.
- **Firebase/cloud**: request+response showing open access to structure/your own seeded
  record; delete any test writes.
- **Native/memory**: crash with tombstone at minimum; state exactly what's proven (crash /
  controlled regs / info leak).
- **Blind anything**: OOB callback to YOUR self-hosted server with a unique token
  attributable to the exact trigger.

Anything weaker = **"unconfirmed lead — needs X"**, never a finding.

## PoC packaging
`loot/<appid>/findings/<id>/`:
```
report.md          the finding (format below)
poc/               runnable proof: adb/frida script, PoC HTML, curl script, or malicious-app stub
evidence/          OOB log, screen recording, provider dump, access-matrix row, frida trace
                   (tokens redacted)
decompiled_refs.md class/method/line citations
```
A reviewer must be able to reproduce impact on an emulator in a few steps.

**Malicious-app stub** (when adb can't carry the proof — scheme interception, result
receiving): minimal single-Activity app; `AndroidManifest.xml` registers the colliding
scheme / starts the victim for result; one `TextView` dumps the captured intent. Build with
whatever's available (Android Studio/gradle on the operator's machine); note the build
requirement in the PoC README. Prefer adb/OOB proofs whenever they suffice — simpler is
stronger.

## Finding report format
```
# [CHAIN/CLASS] <title> — <app> (Android, v<ver>, <pkg>)
Impact (1 line, business terms): …
MASVS/MASWE: <e.g. MASVS-PLATFORM / MASWE-XXXX>   Severity: Critical|High|Medium (CVSS:3.1/vector)
Entry point: <deep link / exported comp / API endpoint>  (externally triggerable? how)
Preconditions: <Android ver, login state, user interaction — honest>
Root cause (decompiled): <class/method — the unvalidated forward / exposed bridge / missing authz>

PoC (your own account/seeded data — reproducible):
  1. <adb am start -d '…' | frida cmd | PoC-app step | curl API req>
  2. <attacker page / bridge call / second-account replay>
  Observed: <token at OOB | provider dump | cross-account 200 | gated data reached>
  Control: <the request/flow that correctly denies>

Proof artifact: <OOB log | recording | provider output | accessmatrix row | frida trace>
Remediation: <allowlist + shouldOverrideUrlLoading | remove/gate JS interface | exported=false |
              App Links + assetlinks + PKCE | Keystore-bound key | server-side object authz>
Novelty (internal note): low-dup because <chain/reachability/server-side/context/framework>
References: <MASTG test id, related public research>
```

## Run summary (per app)
```
App / version / pkg / sha256 / backend(s):
Authorization: <authorized app + in-scope API domains + ROE ack>
Recon: <exported comps, deep links/schemes, WebViews+bridge methods, providers, API map, secrets>
Model reconstructed: <routing table, trust boundaries>
Confirmed (low-dup first): <list w/ MASVS id + severity>
Chains realized: <list>
Unconfirmed leads: <what each needs>
Tested-clean (negatives): <engines/surfaces tried, no finding — be specific>
Limits/ROE: <packer needed dex-dump?, device constraints, out-of-scope handed back, PII avoided>
```

## Integrity (non-negotiable)
Authorized apps + in-scope backends + ROE · reverse before attacking · prove on your own
device/account/OOB · never real PII · non-destructive · MASVS-mapped · honest severity &
novelty · record negatives.
