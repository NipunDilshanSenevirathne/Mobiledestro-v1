# CASE 009 — React Native / Flutter bridge & storage stack (framework-layer chain)

**Pattern.** RN: `@ReactMethod` native modules exposed to any JS the app runs + tokens in
`AsyncStorage` (unencrypted SQLite) + Hermes bundle readable in assets. Flutter:
`MethodChannel` handlers registered in native code + `shared_preferences` plaintext tokens +
Java-layer unpinning not covering BoringSSL (so hunters wrongly conclude "traffic is safe").

**Why scanners miss it.** Most static tooling parses the Java/Dex layer and stops; the
business logic sits in the bundle/snapshot and the bridge glue is only visible by
cross-referencing both layers.

**Detection rule.**
1. `native.txt`/`sdks.txt` identifies the framework (`libhermes`/`index.android.bundle`,
   `libflutter.so`/`libapp.so`).
2. RN: grep bundle for module names; jadx for `@ReactMethod`; check
   `databases/RKStorage` at runtime. Flutter: `strings libapp.so` for channels/endpoints;
   jadx `setMethodCallHandler`.
3. Pinning: `frida_flutter_unpin.js` for Flutter; standard unpin for RN's Java OkHttp.
4. Dynamic: pull AsyncStorage/shared_prefs (own account), call the bridge from injected JS
   where a WebView/JSI entry exists.

**Report shape.** Same bars as first-party findings; novelty note: framework-layer surface
most tooling can't see.
