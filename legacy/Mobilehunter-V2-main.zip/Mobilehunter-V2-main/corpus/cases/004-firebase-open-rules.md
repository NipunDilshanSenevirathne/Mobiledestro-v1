# CASE 004 — Firebase/cloud misconfiguration from binary config (open RTDB / Storage)

**Pattern.** `google-services.json` values ship in the binary (by design). The finding is the
backend rules: RTDB `".read": true`, Storage bucket listable, Firestore collection open.
Pattern reports die as "rules are open" with no impact; winners prove *what data class* is
exposed (structure + one redacted record of your own seeded account).

**Why hunters fail at it.** They probe `/.json`, get 200, paste a data dump (often real user
PII — ROE violation) or nothing (no impact), and get closed as N/A. The skill's bar:
structure + your own seeded record + data-class statement.

**Detection rule.**
1. `secrets_hunter.py` → `firebase_config.txt` (db url, project, bucket, AIza key).
2. `firebase_audit.py --confirm` runs the read-only battery (RTDB shallow, Firestore
   collections, Storage list).
3. Impact proof: seed your own record via the app, read it back through the open endpoint;
   redact; state the exposed classes (PII? tokens? messages?).

**Report shape.** MASVS-NETWORK/STORAGE + CWE-200; severity follows the data class;
remediation = rules requiring auth + per-user paths, App Check, key restrictions.
