# CASE 007 — WebView debugging enabled in release → chrome://inspect full control

**Pattern.** `setWebContentsDebuggingEnabled(true)` shipped in a release build. Any
connected/devtools session (`chrome://inspect`) gets JS execution **inside the app's WebView**
— call the JS bridge, read DOM/session storage, drive the app. With a token bridge present
this is effectively remote-code-in-app-context.

**Why scanners miss it.** MobSF lists it as a low/info line. The chain (devtools → bridge →
token) is what makes it critical; the precondition (physical access / same-network devtools)
is what honest triage must state.

**Detection rule.**
1. `webview.txt` + semgrep `android-webview-debugging-enabled` — then **verify it reaches the
   shipped build** (check smali, since ProGuard/build-types may strip it).
2. Dynamic: own device, `chrome://inspect`, open the app's WebView, run
   `window.<bridge>.<method>()` → captured token (own account) = proof.

**Report shape.** MASVS-PLATFORM/RESILIENCE; severity scales with bridge exposure and the
access preconditions — state both plainly. Fix: strip the call / gate on `BuildConfig.DEBUG`.
