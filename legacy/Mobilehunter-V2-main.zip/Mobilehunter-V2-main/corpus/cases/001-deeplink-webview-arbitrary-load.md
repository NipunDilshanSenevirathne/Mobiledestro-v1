# CASE 001 — Insecure deep link → WebView → arbitrary URL load (Grab, H1 #401793)

**Pattern.** An exported/BROWSABLE deep link handler takes a URL parameter and loads it into
a WebView without a host/scheme allowlist. An attacker page (any origin) renders inside the
app's trusted WebView → phishing in trusted chrome, JS-bridge abuse if present, cookie theft.

**Why scanners miss it.** They note "WebView exists" and "deep link exists" as separate
checklist lines; the chain — entry → unvalidated forward → sink — requires reachability
reasoning over the routing code.

**Detection rule (would you catch it?).**
1. `manifest_analyze.py` lists the deep-link filter; `deeplink_matrix.py` generates
   `?url=https://YOUR-OOB` candidates for every `url|uri|link|redirect|next|target` param.
2. Model phase: trace `getQueryParameter("url")` → `loadUrl` — is there an allowlist? If yes,
   run the bypass corpus (endsWith/contains/@-trick/encoding/redirect-chain re-checks).
3. Dynamic: fire via `deeplink_probe.sh`; OOB hit + `frida_bridge_trace.js` `loadUrl` line =
   reachable. Bridge methods enumerated → escalate to ATO chain.

**Report shape.** MASVS-PLATFORM; one-click; severity scales with bridge exposure
(phishing-only = medium/high; token bridge = critical ATO).
