# CASE 006 — Client-side biometric gate (no Keystore binding) → local-auth bypass

**Pattern.** `BiometricPrompt.authenticate(promptInfo, executor, callback)` with NO
`CryptoObject`: `onAuthenticationSucceeded` just flips a boolean or navigates. The gate is
cosmetic — hook the callback (or fire the post-auth route via an exported component/deep
link) and the protected screen/data opens without any finger.

**Why scanners miss it.** "App uses biometrics" reads as a control. Only hooking proves the
auth result never unlocks anything cryptographic.

**Detection rule.**
1. Semgrep rule `android-biometric-no-cryptoobject` + grep jadx `BiometricPrompt` /
   `setUserAuthenticationRequired`.
2. Check whether the post-auth path is independently reachable (exported activity / deep link
   to the "home" route) — often yes, no Frida needed.
3. Dynamic: hook `BiometricPrompt$AuthenticationCallback.onAuthenticationSucceeded` (frida
   one-liner in `engine-auth-runtime.md`) → reach gated data on YOUR device.

**Report shape.** MASVS-AUTH; honest severity (local bypass of a gate; impact = what's behind
it — session restore? payments?). Fix: Keystore key with `setUserAuthenticationRequired(true)`
released via CryptoObject.
