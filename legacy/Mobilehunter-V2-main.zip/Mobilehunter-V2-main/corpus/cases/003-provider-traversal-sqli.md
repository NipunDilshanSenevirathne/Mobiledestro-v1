# CASE 003 — ContentProvider path traversal / SQLi → sandbox file read (token theft → ATO)

**Pattern.** An exported (or grantUri-reachable) provider implements `openFile()` by joining
the URI path to a base directory without canonicalization checks →
`content://auth/..%2f..%2fshared_prefs/prefs.xml` reads arbitrary app files. Sibling pattern:
`query()` selection/sortOrder reaching SQLite unparameterized → boolean-blind extraction of
the provider DB (tokens inside).

**Why scanners miss it.** Static tools flag "exported provider"; proving *which file* is
readable or *which column* exfiltrates requires firing payloads at a live app with seeded data.

**Detection rule.**
1. `manifest_analyze.py` lists exported providers + grantUri-only ones (redirection-reachable).
2. `provider_probe.sh` fires traversal + SQLi batteries; 200-with-content on a traversal =
   file read; SQL error / differential rows on injected selection/sort = SQLi.
3. Chain: read `shared_prefs/*.xml` or DB → session token → replay against the backend API
   (access_matrix.py) → ATO/BOLA. That chain, not the raw traversal, is the headline.

**Report shape.** MASVS-PLATFORM (+STORAGE/AUTH via the chain); show the exact `content`
command, the file bytes (your own seeded account), and the API replay.
