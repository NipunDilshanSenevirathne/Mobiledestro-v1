# CASE 008 — App Link hijack via subdomain takeover (verified links)

**Pattern.** An `autoVerify=true` intent filter lists several hosts (e.g. `app.example.com`,
`cdn.example.com`). Android verifies EVERY host's `assetlinks.json`. If one listed subdomain
is dangling (takable via cloud/SaaS), the attacker registers it, serves valid assetlinks for
THEIR signing cert... or more practically: serves the victim's path structure and wins
verified-link routing for that host — links the OS opens without asking → phishing/auth flows
under the app's own verified links.

**Why scanners miss it.** The manifest looks right; the bug lives in DNS/hosting state, which
requires enumerating the filter's hosts and checking each for takability.

**Detection rule.**
1. `manifest_analyze.py` warns on every autoVerify filter + wildcard host.
2. Enumerate every host in those filters; check DNS/CNAME chains for dangling providers
   (your own infrastructure checks only — passive).
3. Chain with `005` (auth callbacks) when the hijacked host carries login/share links.

**Report shape.** MASVS-PLATFORM (+AUTH); list the filter, the takable host (passive DNS
evidence), the assetlinks requirement, and the resulting routing behavior. Fix: drop dead
hosts from filters, keep assetlinks fresh, reclaim the subdomain.
