# CASE 002 — Access to protected components via intent redirection (Oversecured pattern)

**Pattern.** An exported component reads a nested Intent from an extra and forwards it
(`getParcelableExtra("intent")` → `startActivity`/`sendBroadcast`/`startService`). A
malicious app supplies an inner intent addressing the victim's NON-exported components →
executes protected functionality with the victim's identity. Variants forward
`FLAG_GRANT_READ_URI_PERMISSION` to hand a `content://` FileProvider URI to the internal
component → arbitrary sandbox file read.

**Why scanners miss it.** The manifest says the internal component is `exported="false"` —
"safe". Only data-flow reasoning shows the exported forwarder laundering trust.

**Detection rule.**
1. Grep jadx: `getParcelableExtra` / `getSerializableExtra` near `startActivity|startService|
   sendBroadcast|setIntent|setSelector`.
2. For each hit: is the component exported (manifest_analysis.json)? Is the inner intent
   attacker-controlled without component/package pinning? Does the call forward flags?
3. Dynamic: PoC app (or `am start` with nested intent via `intent://` selector form) reaching
   the internal component; `frida_intent_logger.js` shows the forward live.

**Report shape.** MASVS-PLATFORM; confused deputy; severity = what the protected component
does (token-bearing internal activity = high/critical).
