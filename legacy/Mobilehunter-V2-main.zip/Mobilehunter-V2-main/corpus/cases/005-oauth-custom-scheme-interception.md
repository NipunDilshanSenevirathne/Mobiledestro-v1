# CASE 005 — OAuth custom-scheme redirect interception (code theft → ATO)

**Pattern.** The app OAuth-flows with `redirect_uri=myapp://callback`. Any app registering
`myapp://` first wins the collision; the authorization code lands in the malicious app. With
no PKCE (or a weak/absent `code_verifier` check server-side), the code redeems → account
takeover. iOS parallels aside, on Android the fix is App Links + verified assetlinks (+ PKCE).

**Why scanners miss it.** Manifest shows a scheme; the bug lives in the *auth flow* — scheme
collision + missing PKCE + token endpoint accepting the code without verifier. Requires
reading the OAuth implementation and replaying the exchange.

**Detection rule.**
1. `manifest_analysis.json` custom schemes + `endpoints.txt` oauth/authorize/token hits →
   `chain_suggest.py` flags it.
2. Read the auth code: is `code_challenge` sent? `state`? Is the redirect validated?
3. Dynamic: `poc_app_template` with the same scheme + start the victim's login with YOUR
   test account → your PoC app receives the callback URI with the code → redeem it against
   the token endpoint (in-scope) → session for YOUR second account = proof.

**Report shape.** MASVS-AUTH + PLATFORM; ATO; cite the scheme registration, the missing
PKCE/state in code, and the captured code (redacted) with the successful exchange.
