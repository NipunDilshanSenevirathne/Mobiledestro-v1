# Regression Corpus — known public bug-pattern cards

Phase 8 self-measurement. Each card describes a *documented public bug pattern* (not a claim
about any current app) plus a **detection rule**: given a built `model.md` for your target,
would your process have caught this class? A card you can't answer = a coverage gap to close
before reporting.

Use:
1. Build `model.md` (Phase 2).
2. For each card in `cases/`, ask: does my model + ledger cover this entry class and sink?
3. Missing coverage → run that engine sweep now.

Cards are patterns from public research; links are in `references/research-grounding.md`.
Add a card whenever you finish a hunt whose pattern generalizes.
