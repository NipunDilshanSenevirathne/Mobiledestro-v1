#!/usr/bin/env python3
"""
manifest_analyze.py — full AndroidManifest analysis for androidhunter-ultimate.

Resolves the rules humans get wrong:
  * implicit export: component with an intent-filter and no explicit exported attr is
    exported iff targetSdkVersion < 31 (on 31+ explicit is mandatory; launcher activities
    are always exported)
  * deep-link routing table: per-component scheme/host/port/path combos, autoVerify
  * provider authorities / grantUriPermissions / path-permissions
  * custom permissions and their protectionLevel ("normal" = no protection)
  * risky flags: debuggable, allowBackup, cleartext, NSC, taskAffinity, sharedUserId...

Usage: manifest_analyze.py <AndroidManifest.xml> --out <loot-app-dir>
Writes: manifest_analysis.json, manifest_analysis.md, exported.txt, providers.txt
"""
import json, sys, os, argparse
import xml.etree.ElementTree as ET

A = "{http://schemas.android.com/apk/res/android}"

def attr(el, name, default=None):
    return el.get(A + name, default)

def truth(v):
    return str(v).lower() == "true"

def parse(manifest_path):
    tree = ET.parse(manifest_path)
    root = tree.getroot()
    out = {
        "package": root.get("package", "unknown"),
        "versionCode": attr(root, "versionCode"),
        "versionName": attr(root, "versionName"),
        "sharedUserId": attr(root, "sharedUserId"),
        "minSdk": None, "targetSdk": None,
        "permissions_custom": [], "uses_permissions": [],
        "application_flags": {}, "components": [], "providers": [],
        "deeplinks": [], "warnings": [],
    }
    uses_sdk = root.find("uses-sdk")
    if uses_sdk is not None:
        out["minSdk"] = attr(uses_sdk, "minSdkVersion")
        out["targetSdk"] = attr(uses_sdk, "targetSdkVersion")
    try:
        tsdk = int(out["targetSdk"] or 31)
    except ValueError:
        tsdk = 31
    out["_targetSdk_int"] = tsdk

    for p in root.findall("permission"):
        out["permissions_custom"].append({
            "name": attr(p, "name"), "protectionLevel": attr(p, "protectionLevel", "normal")})
        if (attr(p, "protectionLevel", "normal") or "normal") == "normal":
            out["warnings"].append(
                f"custom permission '{attr(p,'name')}' has protectionLevel=normal — any app can hold it = NO protection")
    for p in root.findall("uses-permission"):
        out["uses_permissions"].append(attr(p, "name"))

    app = root.find("application")
    if app is None:
        return out
    flags = {}
    for f in ("debuggable", "allowBackup", "usesCleartextTraffic", "extractNativeLibs",
              "allowTaskReparenting", "taskAffinity", "networkSecurityConfig", "process",
              "fullBackupContent", "dataExtractionRules", "requestLegacyExternalStorage"):
        v = attr(app, f)
        if v is not None:
            flags[f] = v
    out["application_flags"] = flags
    if truth(flags.get("debuggable")):
        out["warnings"].append("android:debuggable=true — run-as / JDWP exposure")
    if truth(flags.get("allowBackup")):
        out["warnings"].append("android:allowBackup=true — adb backup / cloud-backup extraction surface")
    if truth(flags.get("usesCleartextTraffic")):
        out["warnings"].append("usesCleartextTraffic=true — cleartext HTTP permitted")
    if flags.get("allowTaskReparenting") and truth(flags["allowTaskReparenting"]):
        out["warnings"].append("allowTaskReparenting=true — StrandHogg task-hijack surface")
    if out.get("sharedUserId"):
        out["warnings"].append(f"sharedUserId={out['sharedUserId']} — cross-app UID/data sharing with same-cert apps")

    def parse_filters(comp):
        filters = []
        for inf in comp.findall("intent-filter"):
            f = {"actions": [attr(a, "name") for a in inf.findall("action")],
                 "categories": [attr(c, "name") for c in inf.findall("category")],
                 "autoVerify": truth(attr(inf, "autoVerify", "false")),
                 "data": []}
            for d in inf.findall("data"):
                f["data"].append({k: attr(d, k) for k in
                    ("scheme", "host", "port", "path", "pathPrefix", "pathPattern", "mimeType")
                    if attr(d, k) is not None})
            filters.append(f)
        return filters

    def is_exported(tag, comp, filters):
        exp = attr(comp, "exported")
        if exp is not None:
            return truth(exp)
        if filters:
            if tsdk < 31:
                return True
            # 31+: implicit components must declare exported; presence without it is a
            # build error for installs — treat launcher/main as exported, flag the rest
            for f in filters:
                if "android.intent.category.LAUNCHER" in f["categories"]:
                    return True
            out["warnings"].append(
                f"{tag} {attr(comp,'name')}: intent-filter without exported attr on targetSdk>=31 (invalid/ambiguous)")
            return False
        return False

    for tag in ("activity", "activity-alias", "service", "receiver"):
        for comp in app.findall(tag):
            name = attr(comp, "name", "?")
            filters = parse_filters(comp)
            exported = is_exported(tag, comp, filters)
            rec = {"type": tag, "name": name, "exported": exported,
                   "permission": attr(comp, "permission"),
                   "taskAffinity": attr(comp, "taskAffinity"),
                   "launchMode": attr(comp, "launchMode"),
                   "intent_filters": filters}
            out["components"].append(rec)
            if exported and rec["permission"] is None and tag != "activity-alias":
                pass  # informational in MD
            # deeplink detection
            for f in filters:
                schemes = [d["scheme"] for d in f["data"] if "scheme" in d]
                if schemes and ("android.intent.action.VIEW" in f["actions"]):
                    hosts = sorted({d.get("host", "") for d in f["data"] if "scheme" in d})
                    entry = {"component": name, "schemes": sorted(set(schemes)),
                             "hosts": hosts,
                             "paths": [d.get("path") or d.get("pathPrefix") or d.get("pathPattern")
                                       for d in f["data"] if any(k in d for k in ("path", "pathPrefix", "pathPattern"))],
                             "autoVerify": f["autoVerify"],
                             "browsable": "android.intent.category.BROWSABLE" in f["categories"]}
                    out["deeplinks"].append(entry)
                    if any(h == "" or h == "*" for h in hosts) or not hosts:
                        out["warnings"].append(
                            f"{name}: intent-filter with scheme {schemes} but NO host — matches ALL hosts (link-hijack surface)")
                    if any(h.startswith("*.") for h in hosts):
                        out["warnings"].append(
                            f"{name}: wildcard host {hosts} — any subdomain routes in (subdomain-takeover → hijack)")
                    if f["autoVerify"]:
                        out["warnings"].append(
                            f"{name}: autoVerify App Link on {hosts} — EVERY host must serve valid assetlinks.json; a takable subdomain = verified hijack")

    for prov in app.findall("provider"):
        name = attr(prov, "name", "?")
        auth = attr(prov, "authorities", "")
        exp = attr(prov, "exported")
        exported = truth(exp) if exp is not None else (tsdk < 31 and auth != "")
        rec = {"name": name, "authorities": auth, "exported": exported,
               "grantUriPermissions": truth(attr(prov, "grantUriPermissions", "false")),
               "permission": attr(prov, "permission"),
               "readPermission": attr(prov, "readPermission"),
               "writePermission": attr(prov, "writePermission"),
               "path_permissions": [
                   {"path": attr(pp, "path"), "pathPrefix": attr(pp, "pathPrefix"),
                    "pathPattern": attr(pp, "pathPattern"),
                    "readPermission": attr(pp, "readPermission"),
                    "writePermission": attr(pp, "writePermission")}
                   for pp in prov.findall("path-permission")]}
        out["providers"].append(rec)
        if exported and not (rec["permission"] or rec["readPermission"]):
            out["warnings"].append(f"provider {name} ({auth}) exported with no permission — SQLi/traversal surface")
        if rec["grantUriPermissions"] and not exported:
            out["warnings"].append(
                f"provider {name} ({auth}) grantUriPermissions=true (exported=false) — still reachable via FLAG_GRANT forwarding (intent-redirection chain)")

    out.pop("_targetSdk_int", None)
    return out

def to_md(d):
    L = []
    L.append(f"# Manifest analysis — {d['package']} (v{d.get('versionName')}/{d.get('versionCode')})")
    L.append(f"minSdk={d.get('minSdk')} targetSdk={d.get('targetSdk')} sharedUserId={d.get('sharedUserId')}")
    L.append("\n## Warnings (hunter flags)")
    L += [f"- {w}" for w in d["warnings"]] or ["- none"]
    L.append("\n## Application flags")
    L += [f"- {k}={v}" for k, v in d["application_flags"].items()] or ["- none"]
    L.append("\n## Deep links / App Links (entry routing table)")
    if d["deeplinks"]:
        for dl in d["deeplinks"]:
            L.append(f"- `{dl['component']}` schemes={dl['schemes']} hosts={dl['hosts']} "
                     f"paths={dl['paths']} autoVerify={dl['autoVerify']} browsable={dl['browsable']}")
    else:
        L.append("- none declared in manifest (check code-registered links: navDeepLink, Branch, FDL)")
    L.append("\n## Components (exported marked *)")
    for c in d["components"]:
        mark = "*" if c["exported"] else " "
        perm = f" perm={c['permission']}" if c["permission"] else ""
        L.append(f"- [{mark}] {c['type']} `{c['name']}`{perm} filters={len(c['intent_filters'])}")
    L.append("\n## Providers")
    for p in d["providers"]:
        L.append(f"- `{p['authorities']}` ({p['name']}) exported={p['exported']} grantUri={p['grantUriPermissions']} "
                 f"perm={p['permission'] or p['readPermission'] or 'NONE'} pathPerms={len(p['path_permissions'])}")
    L.append("\n## Custom permissions")
    L += [f"- {p['name']} protectionLevel={p['protectionLevel']}" for p in d["permissions_custom"]] or ["- none"]
    return "\n".join(L) + "\n"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("manifest")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    d = parse(a.manifest)
    os.makedirs(a.out, exist_ok=True)
    with open(os.path.join(a.out, "manifest_analysis.json"), "w") as f:
        json.dump(d, f, indent=2)
    with open(os.path.join(a.out, "manifest_analysis.md"), "w") as f:
        f.write(to_md(d))
    with open(os.path.join(a.out, "exported.txt"), "w") as f:
        for c in d["components"]:
            if c["exported"]:
                f.write(f"{c['type']}\t{c['name']}\tperm={c['permission'] or '-'}\n")
        for p in d["providers"]:
            if p["exported"]:
                f.write(f"provider\t{p['name']}\t{p['authorities']}\n")
    with open(os.path.join(a.out, "providers.txt"), "w") as f:
        for p in d["providers"]:
            f.write(f"{p['authorities']}\texported={p['exported']}\tgrantUri={p['grantUriPermissions']}\t{p['name']}\n")
    print(f"[manifest_analyze] {d['package']}: {len(d['components'])} components, "
          f"{sum(1 for c in d['components'] if c['exported'])} exported, "
          f"{len(d['deeplinks'])} deeplink filters, {len(d['providers'])} providers, "
          f"{len(d['warnings'])} warnings")

if __name__ == "__main__":
    main()
