#!/usr/bin/env python3
"""
access_matrix.py — two-account replay for IDOR/BOLA on the app's backend.

The backend bridge: capture object-scoped API requests from YOUR OWN account A,
replay them under YOUR OWN account B — a 200 that looks like A's data = BOLA.

Requests file format (one block per request, '### name' starts a block):
  ### get order 1001
  GET https://api.example.com/orders/1001
  Authorization: Bearer {TOKEN}
  X-App: 1

  {"json": "body if any"}

Usage:
  access_matrix.py --requests reqs.txt --session-a 'Bearer AAA' --session-b 'Bearer BBB' \
      [--throttle 0.3] [--out loot/<pkg>/access_matrix.md]
Every host is scope-gated (scope_gate.sh api). Use only YOUR OWN two accounts.
"""
import argparse, difflib, os, re, subprocess, sys, time, urllib.request, urllib.error

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TIMEOUT = 15

def parse_blocks(path):
    blocks, cur = [], None
    for line in open(path, errors="replace"):
        if line.startswith("###"):
            if cur:
                blocks.append(cur)
            cur = {"name": line.strip("# \n"), "head": [], "body": []}
            continue
        if cur is None:
            continue
        if line.strip() == "" and cur["head"] and not cur["body"]:
            cur["body_started"] = True
            continue
        (cur["body"] if cur.get("body_started") else cur["head"]).append(line.rstrip("\n"))
    if cur:
        blocks.append(cur)
    out = []
    for b in blocks:
        if not b["head"]:
            continue
        m = re.match(r"(GET|POST|PUT|DELETE|PATCH|HEAD)\s+(\S+)", b["head"][0])
        if not m:
            continue
        headers = {}
        for h in b["head"][1:]:
            if ":" in h:
                k, v = h.split(":", 1)
                headers[k.strip()] = v.strip()
        out.append({"name": b["name"], "method": m.group(1), "url": m.group(2),
                    "headers": headers, "body": "\n".join(b["body"]) or None})
    return out

def gate(host):
    r = subprocess.run([os.path.join(HERE, "scripts", "scope_gate.sh"), "api", host],
                       capture_output=True, text=True)
    return r.returncode == 0

def fire(req, token):
    url = req["url"]
    headers = {k: (v.replace("{TOKEN}", token) if isinstance(v, str) else v)
               for k, v in req["headers"].items()}
    headers.setdefault("User-Agent", "androidhunter-access-matrix/1.0")
    data = None
    if req["body"]:
        data = req["body"].replace("{TOKEN}", token).encode()
        headers.setdefault("Content-Type", "application/json")
    r = urllib.request.Request(url, data=data, headers=headers, method=req["method"])
    try:
        with urllib.request.urlopen(r, timeout=TIMEOUT) as resp:
            return resp.status, resp.read(8192).decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        try:
            body = e.read(4096).decode("utf-8", "replace")
        except Exception:
            body = ""
        return e.code, body
    except Exception as e:
        return None, str(e)

def host_of(url):
    m = re.match(r"[a-z]+://([^/]+)", url)
    return m.group(1).split(":")[0] if m else url

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--requests", required=True)
    ap.add_argument("--session-a", required=True)
    ap.add_argument("--session-b", required=True)
    ap.add_argument("--throttle", type=float, default=0.3)
    ap.add_argument("--out")
    a = ap.parse_args()

    reqs = parse_blocks(a.requests)
    if not reqs:
        print("[!] no requests parsed. See the format doc in this script's header."); sys.exit(1)

    gated = []
    for r in reqs:
        h = host_of(r["url"])
        if gate(h):
            gated.append(r)
        else:
            print(f"  [skip] {h} out of scope")
    if not gated:
        print("[!] all hosts out of scope — add them to authorized_api_domains.txt or stop."); sys.exit(1)

    rows, flags = [], []
    for r in gated:
        sa, ba = fire(r, a.session_a); time.sleep(a.throttle)
        sb, bb = fire(r, a.session_b); time.sleep(a.throttle)
        sim = 0.0
        if ba and bb:
            sim = difflib.SequenceMatcher(None, ba[:4000], bb[:4000]).ratio()
        flag = ""
        if sb == 200 and sa == 200 and sim > 0.8:
            flag = "BOLA? B got 200 with ~same body as A"
        elif sb == 200 and sa in (401, 403):
            flag = "weird: B succeeds where A is denied (check accounts)"
        elif sb == 200:
            flag = "B 200 — inspect manually (sim=%.2f)" % sim
        rows.append((r["name"], r["method"], r["url"], sa, sb, round(sim, 2), flag))
        mark = " <<<" if flag.startswith("BOLA") else ""
        print(f"  {r['method']} {r['url']}  A={sa} B={sb} sim={sim:.2f}{mark}")
        if flag:
            flags.append((r, sa, sb, sim, flag, bb[:500]))

    report = ["# Access matrix (two OWN accounts)", ""]
    report.append("| request | A status | B status | body sim | flag |")
    report.append("|---|---|---|---|---|")
    for name, m, u, sa, sb, sim, flag in rows:
        report.append(f"| {name} `{m} {u}` | {sa} | {sb} | {sim} | {flag} |")
    for r, sa, sb, sim, flag, snippet in flags:
        report.append(f"\n## FLAG: {r['name']} — {flag}\n```\n{snippet}\n```")
    text = "\n".join(report) + "\n"
    if a.out:
        os.makedirs(os.path.dirname(a.out), exist_ok=True)
        open(a.out, "w").write(text)
        print(f"[done] -> {a.out}")
    else:
        print("\n" + text)

if __name__ == "__main__":
    main()
