#!/usr/bin/env bash
# dump_dex.sh — dump dex from a RUNNING packed/protected app on YOUR OWN device.
# For apps where apkid showed a packer (jadx only sees the stub loader).
#   dump_dex.sh <pkg>
# Uses frida-dexdump if available; otherwise prints the FRIDA-DEXDump alternative.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GATE="$HERE/scripts/scope_gate.sh"
LOOT_BASE="${LOOT_BASE:-$PWD/loot}"
PKG="${1:-}"; [ -z "$PKG" ] && { echo "usage: dump_dex.sh <pkg>"; exit 1; }
"$GATE" app "$PKG" >/dev/null 2>&1 || { echo "[ABORT] $PKG not authorized."; "$GATE" app "$PKG"; exit 1; }
command -v adb >/dev/null 2>&1 || { echo "[!] adb missing."; exit 1; }
adb devices | awk 'NR>1 && $2=="device"' | grep -q . || { echo "[!] no device attached."; exit 1; }

OUT="$LOOT_BASE/$PKG/dexdump"; mkdir -p "$OUT"
if command -v frida-dexdump >/dev/null 2>&1; then
  echo "[*] frida-dexdump -U -f $PKG -d $OUT  (requires frida-server running — setup_device.sh)"
  (cd "$OUT" && frida-dexdump -U -f "$PKG" -d . 2>&1 | tail -5)
  echo "[*] dumped dex files:"; ls -la "$OUT"/*.dex 2>/dev/null
  echo "[i] decompile: for d in $OUT/*.dex; do jadx -d ${d%.dex}_jadx \$d; done"
else
  cat <<EOF
[!] frida-dexdump not installed. Options (your own device, authorized app):
  pipx install frida-dexdump     # then re-run this script
  # or objection: objection -g $PKG explore -> android dexdump (older objection) /
  #    memory search for dex headers: memory search "64 65 78 0a" --dump
After dumping: jadx each dex, then re-run static_recon.sh on the dumped sources.
EOF
  exit 1
fi
