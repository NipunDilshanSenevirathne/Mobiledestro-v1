#!/usr/bin/env python3
"""
secrets_hunter.py — deep secrets & endpoints scanner (regex library + Shannon entropy).

Usage: secrets_hunter.py <dir1> [dir2 ...] --out <loot-app-dir>
Writes: secrets.txt (candidates with file:line, deduped, labeled),
        endpoints.txt (URLs/hosts, noise-filtered),
        firebase_config.txt (google-services values if present).

Every candidate is UNVALIDATED until proven live with a benign authorized probe.
Scans text files directly; extracts strings from .so/.dex binaries. Size-capped.
"""
import os, re, sys, math, argparse

MAX_BYTES = 40 * 1024 * 1024
TEXT_EXT = {".java", ".kt", ".xml", ".json", ".js", ".ts", ".properties", ".txt", ".md",
            ".smali", ".gradle", ".cfg", ".ini", ".yaml", ".yml", ".html", ".css", ".plist"}
BIN_EXT = {".so", ".dex", ".aar", ".jar", ".bin", ".dat"}

PATTERNS = [
    ("AWS access key",        r"\b(AKIA|ASIA)[0-9A-Z]{16}\b"),
    ("GCP/Firebase API key",  r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    ("Google OAuth client",   r"\b[0-9]+-[0-9A-Za-z_]{32}\.apps\.googleusercontent\.com\b"),
    ("service-account blob",  r"\"private_key\"\s*:\s*\"-----BEGIN"),
    ("PEM private key",       r"-----BEGIN (RSA |EC |OPENSSH |)?PRIVATE KEY-----"),
    ("Stripe live secret",    r"\b[sr]k_live_[0-9A-Za-z]{16,}\b"),
    ("Stripe live restricted",r"\brk_live_[0-9A-Za-z]{16,}\b"),
    ("Slack token",           r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b"),
    ("GitHub token",          r"\bgh[pousr]_[0-9A-Za-z]{20,}\b"),
    ("GitLab token",          r"\bglpat-[0-9A-Za-z_\-]{20,}\b"),
    ("Twilio account sid",    r"\bAC[0-9a-f]{32}\b"),
    ("Twilio auth token",     r"\bSK[0-9a-f]{32}\b"),
    ("SendGrid key",          r"\bSG\.[0-9A-Za-z_\-]{16,}\.[0-9A-Za-z_\-]{16,}\b"),
    ("Mailgun key",           r"\bkey-[0-9a-f]{32}\b"),
    ("Square token",          r"\bsq0[a-z]{3}-[0-9A-Za-z_\-]{22,}\b"),
    ("FCM legacy server key", r"\bAAAA[0-9A-Za-z_\-]{100,}\b"),
    ("JWT-looking blob",      r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{5,}\b"),
    ("generic key assignment",r"(?i)(api[_-]?key|apikey|client[_-]?secret|secret[_-]?key|auth[_-]?token|"
                              r"access[_-]?token|app[_-]?secret|encryption[_-]?key|hmac[_-]?key|password|passwd)"
                              r"[\"']?\s*[:=]\s*[\"']([A-Za-z0-9._/+=\-]{12,})[\"']"),
    ("bearer literal",        r"(?i)bearer\s+[A-Za-z0-9._\-]{20,}"),
]
URL_RE   = re.compile(r"https?://[a-zA-Z0-9._~:/?#@!$&()*+,;=%\-]{6,}")
WSS_RE   = re.compile(r"wss?://[a-zA-Z0-9._~:/?#@!$&()*+,;=%\-]{6,}")
HOST_RE  = re.compile(r"\b[a-z0-9.\-]+\.(firebaseio\.com|firebasedatabase\.app|amazonaws\.com|"
                      r"appspot\.com|storage\.googleapis\.com|blob\.core\.windows\.net|"
                      r"page\.link|cloudfunctions\.net)\b")
NOISE_URL = re.compile(r"(schemas\.android|w3\.org|apache\.org|unicode\.org|github\.com/|"
                       r"google\.com/apis|gstatic|googleapis\.com/auth|openjdk|kotlinlang|"
                       r"example\.(com|org)|localhost|127\.0\.0\.1|play\.google\.com|"
                       r"support\.google|developer\.android|material\.io)")
GENERIC_SKIP = re.compile(r"(?i)(android|example|your[_-]?key|placeholder|xxxx|null|true|false|"
                          r"changeme|test|dummy|sample)$")
FIREBASE_KEYS = ("google_app_id", "firebase_database_url", "project_id", "google_storage_bucket",
                 "google_api_key", "gcm_defaultSenderId", "default_web_client_id")
B64ISH = re.compile(r"[A-Za-z0-9+/=_\-]{20,}")

def entropy(s):
    if not s:
        return 0.0
    from collections import Counter
    c = Counter(s)
    n = len(s)
    return -sum((v / n) * math.log2(v / n) for v in c.values())

def strings_of(data, minlen=6):
    out, cur = [], []
    for b in data:
        if 32 <= b < 127:
            cur.append(chr(b))
        else:
            if len(cur) >= minlen:
                out.append("".join(cur))
            cur = []
    if len(cur) >= minlen:
        out.append("".join(cur))
    return out

def iter_lines(path):
    """Yield (lineno, text) for text files; (0, string) for binaries."""
    try:
        size = os.path.getsize(path)
        if size > MAX_BYTES:
            return
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return
    ext = os.path.splitext(path)[1].lower()
    if ext in BIN_EXT or b"\x00" in data[:4096]:
        for s in strings_of(data):
            yield 0, s
    else:
        try:
            text = data.decode("utf-8", errors="replace")
        except Exception:
            return
        for i, line in enumerate(text.splitlines(), 1):
            yield i, line

def scan(dirs, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    secrets, urls, fb = {}, {}, {}
    seen_entropy = 0
    for root_dir in dirs:
        for dirpath, dirnames, filenames in os.walk(root_dir):
            dirnames[:] = [x for x in dirnames if x not in (".git", "node_modules", "__pycache__")]
            for fn in filenames:
                path = os.path.join(dirpath, fn)
                rel = os.path.relpath(path, out_dir)
                for lineno, line in iter_lines(path):
                    for label, pat in PATTERNS:
                        for m in re.finditer(pat, line):
                            val = m.group(0)[:120]
                            if GENERIC_SKIP.search(val):
                                continue
                            key = (label, val)
                            secrets.setdefault(key, f"{rel}:{lineno}")
                    for m in URL_RE.finditer(line):
                        u = m.group(0).rstrip("').,;\"")
                        if not NOISE_URL.search(u):
                            urls.setdefault(u, f"{rel}:{lineno}")
                    for m in WSS_RE.finditer(line):
                        urls.setdefault(m.group(0), f"{rel}:{lineno}")
                    for m in HOST_RE.finditer(line):
                        urls.setdefault("host: " + m.group(0), f"{rel}:{lineno}")
                    # firebase config values
                    for k in FIREBASE_KEYS:
                        if f'"{k}"' in line or f"{k}=" in line:
                            fb.setdefault(line.strip()[:200], f"{rel}:{lineno}")
                    # entropy candidates (capped — these are weakest signal)
                    if seen_entropy < 150:
                        for m in B64ISH.finditer(line):
                            tok = m.group(0)
                            if len(tok) >= 24 and entropy(tok) > 4.4 and not re.fullmatch(r"[a-f0-9]+", tok) \
                               and not tok.startswith(("Lcom", "Landroid", "Ljava")):
                                key = ("high-entropy token", tok[:80])
                                if key not in secrets:
                                    secrets[key] = f"{rel}:{lineno}"
                                    seen_entropy += 1

    with open(os.path.join(out_dir, "secrets.txt"), "w") as f:
        f.write("# secret candidates — UNVALIDATED until proven live (benign authorized probe)\n")
        for (label, val), loc in sorted(secrets.items()):
            f.write(f"[{label}] {val}    # {loc}\n")
    with open(os.path.join(out_dir, "endpoints.txt"), "w") as f:
        for u, loc in sorted(urls.items()):
            f.write(f"{u}    # {loc}\n")
    with open(os.path.join(out_dir, "firebase_config.txt"), "w") as f:
        for line, loc in sorted(fb.items()):
            f.write(f"{line}    # {loc}\n")
    print(f"[secrets_hunter] {len(secrets)} secret candidates, {len(urls)} endpoints, "
          f"{len(fb)} firebase config lines")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dirs", nargs="+")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    scan([d for d in a.dirs if os.path.isdir(d)], a.out)

if __name__ == "__main__":
    main()
