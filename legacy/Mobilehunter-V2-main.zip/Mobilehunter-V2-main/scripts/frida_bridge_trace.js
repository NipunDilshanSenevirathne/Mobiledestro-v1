/*
 * frida_bridge_trace.js — WebView + JS-bridge reconnaissance and confirmation.
 * Enumerates every addJavascriptInterface object at runtime, auto-hooks its
 * @JavascriptInterface methods, and logs all navigation decisions.
 *
 *   frida -U -f <pkg> -l frida_bridge_trace.js --no-pause
 *
 * Confirms the flagship chain: which URLs load, which bridge methods exist and
 * what they return — with YOUR OWN account on YOUR OWN device.
 */
'use strict';

function log(m){ console.log('[bridge] ' + m); }

Java.perform(function () {
  // ---- WebView URL flows ----
  try {
    var WV = Java.use('android.webkit.WebView');
    WV.loadUrl.overload('java.lang.String').implementation = function (u) {
      log('loadUrl: ' + u);
      this.loadUrl(u);
    };
    WV.loadUrl.overload('java.lang.String', 'java.util.Map').implementation = function (u, h) {
      log('loadUrl(+headers): ' + u + ' headers=' + h);
      this.loadUrl(u, h);
    };
    WV.postUrl.implementation = function (u, d) {
      log('postUrl: ' + u);
      this.postUrl(u, d);
    };
    WV.evaluateJavascript.implementation = function (js, cb) {
      log('evaluateJavascript: ' + js.substring(0, 300));
      this.evaluateJavascript(js, cb);
    };
    WV.addJavascriptInterface.implementation = function (obj, name) {
      var cls = obj.getClass().getName();
      log('addJavascriptInterface name="' + name + '" class=' + cls);
      try {
        var ms = obj.getClass().getDeclaredMethods();
        for (var i = 0; i < ms.length; i++) {
          var anns = ms[i].getDeclaredAnnotations();
          for (var j = 0; j < anns.length; j++) {
            if (anns[j].toString().indexOf('JavascriptInterface') !== -1) {
              log('  @JavascriptInterface method: ' + cls + '.' + ms[i].getName());
            }
          }
        }
      } catch (e) { log('  method enum failed: ' + e); }
      this.addJavascriptInterface(obj, name);
    };
  } catch (e) { log('WebView hooks skipped: ' + e); }

  // ---- WebSettings ----
  try {
    var WS = Java.use('android.webkit.WebSettings');
    WS.setJavaScriptEnabled.implementation = function (v) { log('setJavaScriptEnabled(' + v + ')'); this.setJavaScriptEnabled(v); };
    WS.setAllowFileAccess.implementation = function (v) { log('setAllowFileAccess(' + v + ')'); this.setAllowFileAccess(v); };
    WS.setAllowUniversalAccessFromFileURLs.implementation = function (v) { log('setAllowUniversalAccessFromFileURLs(' + v + ')'); this.setAllowUniversalAccessFromFileURLs(v); };
  } catch (e) {}
  try {
    Java.use('android.webkit.WebView').setWebContentsDebuggingEnabled.implementation = function (v) {
      log('setWebContentsDebuggingEnabled(' + v + ')' + (v ? '  <-- chrome://inspect = full WebView control' : ''));
      this.setWebContentsDebuggingEnabled(v);
    };
  } catch (e) {}

  // ---- navigation decisions ----
  try {
    var WVC = Java.use('android.webkit.WebViewClient');
    WVC.shouldOverrideUrlLoading.overload('android.webkit.WebView', 'android.webkit.WebResourceRequest').implementation = function (v, r) {
      var dec = this.shouldOverrideUrlLoading(v, r);
      log('shouldOverrideUrlLoading url=' + r.getUrl() + ' -> ' + dec);
      return dec;
    };
  } catch (e) { log('WVC(new) skipped: ' + e); }
  try {
    var WVC2 = Java.use('android.webkit.WebViewClient');
    WVC2.shouldInterceptRequest.overload('android.webkit.WebView', 'android.webkit.WebResourceRequest').implementation = function (v, r) {
      var res = this.shouldInterceptRequest(v, r);
      log('shouldInterceptRequest url=' + r.getUrl());
      return res;
    };
  } catch (e) {}

  // ---- generic: hook every loaded class exposing @JavascriptInterface methods ----
  try {
    Java.enumerateLoadedClasses({
      onMatch: function (name) {
        try {
          if (/^(android|java|javax|kotlin|kotlinx|com\.google|androidx)\./.test(name)) return;
          var cls = Java.use(name);
          var ms = cls.class.getDeclaredMethods();
          for (var i = 0; i < ms.length; i++) {
            var anns = ms[i].getDeclaredAnnotations();
            for (var j = 0; j < anns.length; j++) {
              if (anns[j].toString().indexOf('JavascriptInterface') === -1) continue;
              var mn = ms[i].getName();
              try {
                cls[mn].overloads.forEach(function (o) {
                  o.implementation = function () {
                    var args = Array.prototype.slice.call(arguments);
                    var ret = o.apply(this, arguments);
                    log('BRIDGE CALL ' + name + '.' + mn + ' args=' + JSON.stringify(args) + ' ret=' + ret);
                    return ret;
                  };
                });
              } catch (e) {}
            }
          }
        } catch (e) {}
      },
      onComplete: function () { log('bridge auto-enumeration complete — any bridge call now logs'); }
    });
  } catch (e) { log('auto-enumeration skipped: ' + e); }

  // ---- cookies ----
  try {
    var CM = Java.use('android.webkit.CookieManager');
    CM.setCookie.overload('java.lang.String', 'java.lang.String').implementation = function (u, c) {
      log('setCookie url=' + u + ' cookie=' + (c ? c.substring(0, 120) : c));
      this.setCookie(u, c);
    };
  } catch (e) {}

  log('WebView/bridge tracing installed.');
});
