#!/usr/bin/env bash
# deeplink_probe.sh — fire a deep link at the app as an EXTERNAL attacker would,
# on YOUR OWN device/emulator (authorized app, your test account).
#   deeplink_probe.sh <pkg> '<uri>'            implicit VIEW (browser/other-app style)
#   deeplink_probe.sh <pkg> '<uri>' explicit   component-targeted
# Tip: point url-ish params at your OOB host to catch WebView fetches/exfil.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GATE="$HERE/scripts/scope_gate.sh"
PKG="${1:-}"; URI="${2:-}"; MODE="${3:-implicit}"
[ -z "$PKG" ] || [ -z "$URI" ] && { echo "usage: deeplink_probe.sh <pkg> '<uri>' [implicit|explicit]"; exit 1; }
"$GATE" app "$PKG" >/dev/null 2>&1 || { echo "[ABORT] $PKG not authorized."; "$GATE" app "$PKG"; exit 1; }
command -v adb >/dev/null 2>&1 || { echo "[!] adb not installed."; exit 1; }
adb devices | awk 'NR>1 && $2=="device"' | grep -q . || { echo "[!] no device attached."; exit 1; }

echo "[*] log marker — follow with: adb logcat | grep -iE 'webview|loadurl|ActivityManager|$PKG'"
adb shell "log -p i -t HUNT 'PROBE $URI'" 2>/dev/null || true
if [ "$MODE" = "explicit" ]; then
  echo "[*] explicit: am start -d '$URI' $PKG"
  adb shell am start -a android.intent.action.VIEW -d "$URI" "$PKG" 2>&1
else
  echo "[*] implicit (as a browser/other app would): am start -a VIEW -d '$URI'"
  adb shell am start -a android.intent.action.VIEW -d "$URI" 2>&1 || true
fi
echo "[i] watch: logcat for routing/WebView lines + your OOB for fetches."
echo "[i] browser-reachability proof: host <a href=\"$URI\"> or an intent:// URL and tap from Chrome."
