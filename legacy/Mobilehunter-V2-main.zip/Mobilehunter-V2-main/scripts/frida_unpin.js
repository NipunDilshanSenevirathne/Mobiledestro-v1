/*
 * frida_unpin.js — universal SSL-pinning bypass to OBSERVE YOUR OWN authorized
 * traffic (RESILIENCE gate, not the finding). Your own device, your own account.
 *
 *   frida -U -f <pkg> -l frida_unpin.js --no-pause
 *   # or: objection -g <pkg> explore  ->  android sslpinning disable
 *
 * Covers: SSLContext/TrustManager swap, GENERIC enumeration of every loaded class
 * implementing X509TrustManager (beats per-app custom pins), OkHttp3 CertificatePinner,
 * Conscrypt TrustManagerImpl (verifyChain + checkTrustedRecursive), HostnameVerifier,
 * WebViewClient.onReceivedSslError, TrustKit. Flutter apps need the BoringSSL path
 * (see references/engine-cross-platform.md) — Java-layer hooks do NOT cover Flutter.
 */
'use strict';

function log(m){ console.log('[unpin] ' + m); }

Java.perform(function () {
  // 1) SSLContext.init -> permissive TrustManager
  try {
    var X509TrustManager = Java.use('javax.net.ssl.X509TrustManager');
    var SSLContext = Java.use('javax.net.ssl.SSLContext');
    var TM = Java.registerClass({
      name: 'com.hunt.TrustAll',
      implements: [X509TrustManager],
      methods: {
        checkClientTrusted: function () {},
        checkServerTrusted: function () {},
        getAcceptedIssuers: function () { return []; }
      }
    });
    var init = SSLContext.init.overload(
      '[Ljavax.net.ssl.KeyManager;', '[Ljavax.net.ssl.TrustManager;', 'java.security.SecureRandom');
    init.implementation = function (km, tm, sr) {
      log('SSLContext.init -> TrustAll');
      init.call(this, km, [TM.$new()], sr);
    };
  } catch (e) { log('SSLContext hook skipped: ' + e); }

  // 2) GENERIC: hook every loaded class implementing X509TrustManager
  try {
    Java.enumerateLoadedClasses({
      onMatch: function (name) {
        if (name.indexOf('javax.net.ssl') === 0) return;
        try {
          var cls = Java.use(name);
          var ifaces = cls.class.getInterfaces().map(function (i) { return i.getName(); });
          if (ifaces.indexOf('javax.net.ssl.X509TrustManager') === -1) return;
          var overloads = cls.checkServerTrusted.overloads;
          overloads.forEach(function (o) {
            o.implementation = function () { log('custom TrustManager bypassed: ' + name); };
          });
        } catch (e) { /* not hookable */ }
      },
      onComplete: function () { log('custom TrustManager enumeration done'); }
    });
  } catch (e) { log('enumeration skipped: ' + e); }

  // 3) OkHttp3 CertificatePinner
  try {
    var CP = Java.use('okhttp3.CertificatePinner');
    CP.check.overload('java.lang.String', 'java.util.List').implementation = function () {
      log('OkHttp CertificatePinner.check bypassed');
    };
    try {
      CP.check.overload('java.lang.String', '[Ljava.security.cert.Certificate;').implementation = function () {
        log('OkHttp check[] bypassed');
      };
    } catch (e) {}
    try {
      CP['check$okhttp'].implementation = function () { log('OkHttp check$okhttp bypassed'); };
    } catch (e) {}
  } catch (e) { log('OkHttp hook skipped: ' + e); }

  // 4) Conscrypt TrustManagerImpl
  try {
    var TMI = Java.use('com.android.org.conscrypt.TrustManagerImpl');
    TMI.verifyChain.implementation = function (untrusted, th, host) {
      log('Conscrypt verifyChain bypassed for ' + host);
      return untrusted;
    };
  } catch (e) { log('Conscrypt verifyChain skipped: ' + e); }
  try {
    var TMI2 = Java.use('com.android.org.conscrypt.TrustManagerImpl');
    TMI2.checkTrustedRecursive.overload(
      '[Ljava.security.cert.X509Certificate;', '[B', '[B', 'java.lang.String', 'boolean',
      'java.util.ArrayList', 'java.util.ArrayList', 'java.util.Set'
    ).implementation = function () {
      log('Conscrypt checkTrustedRecursive bypassed');
      return Java.use('java.util.ArrayList').$new();
    };
  } catch (e) { log('checkTrustedRecursive skipped: ' + e); }

  // 5) HostnameVerifier (Apache-style)
  ['org.apache.http.conn.ssl.AbstractVerifier', 'okhttp3.internal.tls.OkHostnameVerifier'].forEach(function (c) {
    try {
      var V = Java.use(c);
      V.verify.overload('java.lang.String', 'javax.net.ssl.SSLSession').implementation = function () {
        log(c + '.verify bypassed'); return true;
      };
    } catch (e) {}
  });

  // 6) WebViewClient SSL errors -> proceed (visibility only; also a FINDING when in prod code)
  try {
    var WVC = Java.use('android.webkit.WebViewClient');
    WVC.onReceivedSslError.implementation = function (view, handler, error) {
      log('WebView onReceivedSslError -> handler.proceed() (observation)');
      handler.proceed();
    };
  } catch (e) { log('WebView SSL hook skipped: ' + e); }

  // 7) TrustKit
  try {
    var TK = Java.use('com.datatheorem.android.trustkit.pinning.OkHostnameVerifier');
    TK.verify.overload('java.lang.String', 'javax.net.ssl.SSLSession').implementation = function () {
      log('TrustKit verify bypassed'); return true;
    };
  } catch (e) {}

  log('pinning bypass installed (authorized observation only). Flutter? use the BoringSSL path.');
});
