#!/usr/bin/env bash
# setup_device.sh — prep YOUR OWN emulator/device: frida-server, Burp CA, proxy.
#   setup_device.sh [--burp-cert /path/cacert.der] [--proxy host:port] [--skip-frida] [--skip-ca] [--skip-proxy]
# Idempotent; each step reports what it did or why it skipped.
set -uo pipefail
BURPCERT=""; PROXY=""; DO_FRIDA=1; DO_CA=1; DO_PROXY=1
while [ $# -gt 0 ]; do case "$1" in
  --burp-cert) BURPCERT="$2"; shift 2;; --proxy) PROXY="$2"; shift 2;;
  --skip-frida) DO_FRIDA=0; shift;; --skip-ca) DO_CA=0; shift;; --skip-proxy) DO_PROXY=0; shift;;
  *) echo "unknown arg $1"; exit 1;; esac; done
command -v adb >/dev/null 2>&1 || { echo "[!] adb missing."; exit 1; }
adb devices | awk 'NR>1 && $2=="device"' | grep -q . || { echo "[!] no device attached."; exit 1; }

ABI="$(adb shell getprop ro.product.cpu.abi | tr -d '\r')"
echo "[*] abi=$ABI"
case "$ABI" in
  arm64-v8a) FARCH=arm64;; armeabi-v7a|armeabi) FARCH=arm;;
  x86_64) FARCH=x86_64;; x86) FARCH=x86;; *) echo "[!] unmapped abi $ABI"; FARCH="";; esac

ROOT="no"
adb root >/dev/null 2>&1 && sleep 1 && adb shell id 2>/dev/null | grep -q uid=0 && ROOT="adb-root"
if [ "$ROOT" = "no" ] && adb shell su -c id 2>/dev/null | grep -q uid=0; then ROOT="su"; fi
echo "[*] root mode: $ROOT"

# ---- frida-server ----
if [ "$DO_FRIDA" = 1 ]; then
  command -v frida >/dev/null 2>&1 || { echo "[!] frida host tools missing (pipx install frida-tools)."; }
  FV="$(frida --version 2>/dev/null)"; [ -n "$FV" ] && [ -n "$FARCH" ] && {
    FS_LOCAL="/tmp/frida-server-$FV-android-$FARCH"
    if [ ! -x "$FS_LOCAL" ]; then
      echo "[*] downloading frida-server $FV ($FARCH)…"
      curl -sL "https://github.com/frida/frida/releases/download/$FV/frida-server-$FV-android-$FARCH.xz" -o "$FS_LOCAL.xz" \
        && xz -df "$FS_LOCAL.xz" && chmod +x "$FS_LOCAL" || echo "[!] download failed — get frida-server manually."
    fi
    if [ -x "$FS_LOCAL" ]; then
      RUN=""; [ "$ROOT" = "adb-root" ] && RUN=""; [ "$ROOT" = "su" ] && RUN="su -c"
      if [ "$ROOT" = "no" ]; then
        echo "[!] no root — frida-server can't run. Options: rooted emulator, Magisk, or 'objection patchapk' (Frida Gadget)."
      else
        adb push "$FS_LOCAL" /data/local/tmp/hluda >/dev/null 2>&1
        # 'hluda' name dodges trivial frida-server name scans
        adb shell "$RUN chmod 755 /data/local/tmp/hluda" 2>/dev/null
        adb shell "$RUN pkill hluda" >/dev/null 2>&1
        adb shell "nohup $RUN /data/local/tmp/hluda >/dev/null 2>&1 &" >/dev/null 2>&1
        sleep 1
        frida-ps -U >/dev/null 2>&1 && echo "  [ok] frida-server running (as 'hluda') — frida-ps -U works" \
          || echo "  [!] frida-ps -U failed — check server manually: adb shell $RUN /data/local/tmp/hluda"
      fi
    fi
  }
fi

# ---- Burp/mitmproxy CA ----
if [ "$DO_CA" = 1 ]; then
  [ -z "$BURPCERT" ] && for c in "$HOME/cacert.der" "$HOME/.mitmproxy/mitmproxy-ca-cert.cer" "./cacert.der"; do
    [ -f "$c" ] && BURPCERT="$c" && break; done
  if [ -z "$BURPCERT" ] || [ ! -f "$BURPCERT" ]; then
    echo "[i] no CA found — export Burp's cacert.der or run mitmproxy once (creates ~/.mitmproxy/). Re-run with --burp-cert."
  else
    PEM="/tmp/hunt_ca.pem"; openssl x509 -inform DER -in "$BURPCERT" -out "$PEM" 2>/dev/null || cp "$BURPCERT" "$PEM"
    HASH="$(openssl x509 -inform PEM -subject_hash_old -in "$PEM" | head -1)"
    adb push "$PEM" "/data/local/tmp/$HASH.0" >/dev/null 2>&1
    ok=0
    if [ "$ROOT" = "adb-root" ]; then
      adb remount >/dev/null 2>&1 || adb shell "mount -o rw,remount /system" >/dev/null 2>&1
      adb shell "cp /data/local/tmp/$HASH.0 /system/etc/security/cacerts/$HASH.0 && chmod 644 /system/etc/security/cacerts/$HASH.0" >/dev/null 2>&1 && ok=1
    elif [ "$ROOT" = "su" ]; then
      adb shell "su -c 'mount -o rw,remount /system 2>/dev/null; cp /data/local/tmp/$HASH.0 /system/etc/security/cacerts/$HASH.0 && chmod 644 /system/etc/security/cacerts/$HASH.0'" >/dev/null 2>&1 && ok=1
    fi
    if [ "$ok" = 1 ]; then echo "  [ok] CA in system store ($HASH.0)"
    else
      adb shell "cp /data/local/tmp/$HASH.0 /sdcard/Download/$HASH.0" 2>/dev/null
      adb shell "am start -a android.settings.SECURITY_SETTINGS" >/dev/null 2>&1
      echo "  [i] no writable system store — install the CA as a USER cert (Settings > Security > Install from storage; file staged in Download/)."
      echo "      User CAs only work if the app's networkSecurityConfig trusts them (check flags.txt)."
    fi
  fi
fi

# ---- proxy ----
if [ "$DO_PROXY" = 1 ]; then
  if [ -z "$PROXY" ]; then
    HOSTIP="$(ip route get 1.1.1.1 2>/dev/null | awk '{print $7; exit}')"
    [ -z "$HOSTIP" ] && HOSTIP="10.0.2.2"
    # emulators reach the host at 10.0.2.2; physical devices need the LAN ip
    if adb shell getprop ro.kernel.qemu 2>/dev/null | grep -q 1; then PROXY="10.0.2.2:8080"; else PROXY="$HOSTIP:8080"; fi
  fi
  adb shell settings put global http_proxy "$PROXY"
  echo "  [ok] global http_proxy=$PROXY (revert: adb shell settings put global http_proxy :0)"
  echo "       start Burp/mitmproxy listening on 0.0.0.0:8080"
fi
echo "[done] device setup. Frida scripts live in $(dirname "$0")/frida_*.js"
