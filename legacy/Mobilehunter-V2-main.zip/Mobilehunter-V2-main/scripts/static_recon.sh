#!/usr/bin/env bash
# static_recon.sh — orchestrate the full static surface extraction for an unpacked app.
#   static_recon.sh <unpacked-dir>        (loot/<pkg>/unpacked from app_intake.sh)
# Outputs into loot/<pkg>/: manifest_analysis.{json,md} deeplinks.txt exported.txt
# providers.txt flags.txt webview.txt api_surface.txt sdks.txt native.txt
# endpoints.txt secrets.txt firebase_config.txt + generated deeplink_fuzz.sh
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIR="${1:-}"; { [ -z "$DIR" ] || [ ! -d "$DIR" ]; } && { echo "usage: static_recon.sh <unpacked-dir>"; exit 1; }
OUT="$(cd "$DIR/.." && pwd)"
has(){ command -v "$1" >/dev/null 2>&1; }
echo "[*] static recon: $DIR -> $OUT"

MANIFEST="$DIR/AndroidManifest.xml"
JADX="$OUT/jadx"; [ -d "$JADX" ] || JADX=""
# all source roots (base + splits)
SRCS="$DIR"; for d in "$OUT"/jadx*; do [ -d "$d" ] && SRCS="$SRCS $d"; done

# ---- 1. manifest deep parse ----
if [ -f "$MANIFEST" ]; then
  python3 "$HERE/scripts/manifest_analyze.py" "$MANIFEST" --out "$OUT" \
    && echo "  [ok] manifest_analysis.json/.md (routing table + exported map)"
  python3 "$HERE/scripts/deeplink_matrix.py" --analysis "$OUT/manifest_analysis.json" --out "$OUT" \
    && echo "  [ok] deeplinks.txt + deeplink_fuzz.sh (attack URI matrix)"
else
  echo "  [!] no decoded AndroidManifest.xml in $DIR (apktool decode first)"
fi

# ---- 2. secrets & endpoints (regex + entropy, file:line evidence) ----
python3 "$HERE/scripts/secrets_hunter.py" $SRCS --out "$OUT" \
  && echo "  [ok] secrets.txt / endpoints.txt / firebase_config.txt"
if has trufflehog; then trufflehog filesystem "$DIR" --no-update --json 2>/dev/null | head -c 300000 > "$OUT/trufflehog.json" || true; fi
if has apkleaks && ls "$OUT"/*.apk >/dev/null 2>&1; then apkleaks -f "$(ls "$OUT"/*.apk | head -1)" -o "$OUT/apkleaks.txt" >/dev/null 2>&1 || true; fi

# ---- 3. WebView / JS-bridge sinks ----
grep -rEon 'addJavascriptInterface|@JavascriptInterface|setJavaScriptEnabled|setAllowFileAccess(FromFileURLs)?|setAllowUniversalAccessFromFileURLs|setWebContentsDebuggingEnabled|shouldOverrideUrlLoading|shouldInterceptRequest|onReceivedSslError|loadUrl|evaluateJavascript|getQueryParameter|getIntent\(\)\.getData' $SRCS 2>/dev/null \
  > "$OUT/webview.txt" || true
echo "  [ok] webview.txt ($(wc -l < "$OUT/webview.txt" 2>/dev/null || echo 0) hits)"

# ---- 4. semgrep custom Android ruleset (AST-aware second opinion) ----
if has semgrep && [ -f "$HERE/semgrep/android-rules.yml" ]; then
  semgrep --config "$HERE/semgrep/android-rules.yml" $SRCS --no-git-ignore -q \
    > "$OUT/semgrep.txt" 2>/dev/null || true
  echo "  [ok] semgrep.txt ($(grep -c '❯❱\|❱' "$OUT/semgrep.txt" 2>/dev/null || echo 0) rule hits)"
fi

# ---- 5. API surface (Retrofit/OkHttp/GraphQL/ws) ----
{ grep -rEoh '@(GET|POST|PUT|DELETE|PATCH|HEAD)\("[^"]+"\)' $SRCS 2>/dev/null | sort -u;
  grep -rEon 'Interceptor|addInterceptor|Authenticator|CertificatePinner|\.add\("Authorization"|signRequest|HmacSHA|GraphQL|graphql|wss?://' $SRCS 2>/dev/null | head -200;
} > "$OUT/api_surface.txt" || true
echo "  [ok] api_surface.txt"

# ---- 5. SDK inventory ----
{ [ -n "$JADX" ] && ls "$JADX/sources" 2>/dev/null;
  [ -n "$JADX" ] && find "$JADX/sources" -maxdepth 3 -type d 2>/dev/null | sed "s|$JADX/sources/||" | grep -E '^[a-z]' | awk -F/ 'NF<=3' | sort -u | head -120;
} > "$OUT/sdks.txt" || true
echo "  [ok] sdks.txt (package-prefix inventory)"

# ---- 6. native inventory ----
{ find "$OUT" -maxdepth 3 -name '*.so' 2>/dev/null | sed "s|$OUT/||";
  grep -rEon 'System\.loadLibrary|System\.load\(|native [a-zA-Z]+ [a-zA-Z]+\(|JNI_OnLoad|RegisterNatives' $SRCS 2>/dev/null | head -80;
  find "$OUT" -maxdepth 3 -name '*.so' -exec sh -c 'command -v rabin2 >/dev/null && rabin2 -I "$1" 2>/dev/null | grep -E "^(file|canary|nx|pie|relro|fortify)" | sed "s|^|HARDEN $1: |"' _ {} \; 2>/dev/null | head -60;
} > "$OUT/native.txt" || true
echo "  [ok] native.txt"

# ---- 7. risky flags quick file ----
if [ -f "$MANIFEST" ]; then
  { grep -nEi 'android:(debuggable|allowBackup|usesCleartextTraffic)="true"' "$MANIFEST";
    grep -nEi 'networkSecurityConfig|taskAffinity|allowTaskReparenting|sharedUserId|grantUriPermissions|extractNativeLibs' "$MANIFEST"; } 2>/dev/null > "$OUT/flags.txt" || true
  ls "$DIR"/res/xml/*.xml 2>/dev/null | while read -r x; do
    grep -qiE 'pin-set|cleartext|trust-anchors|debug-overrides' "$x" && { echo "## $x"; grep -nEi 'pin-set|expiration|cleartextTrafficPermitted|certificates src|debug-overrides|domain ' "$x"; }
  done >> "$OUT/flags.txt" || true
  echo "  [ok] flags.txt"
fi

echo
echo "[done] static recon complete. Surface files in $OUT/:"
for f in manifest_analysis.md deeplinks.txt exported.txt providers.txt flags.txt webview.txt api_surface.txt sdks.txt native.txt endpoints.txt secrets.txt firebase_config.txt; do
  [ -f "$OUT/$f" ] && printf "  %-24s %s lines\n" "$f" "$(wc -l < "$OUT/$f" 2>/dev/null || echo 0)"
done
echo "  NEXT: Kimi reads these + jadx -> model.md -> AgentSwarm engine sweep (deeplink/webview first)."
