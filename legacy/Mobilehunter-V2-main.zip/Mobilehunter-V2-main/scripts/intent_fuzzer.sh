#!/usr/bin/env bash
# intent_fuzzer.sh — exported-component extras fuzzer on YOUR OWN device (authorized app).
#   intent_fuzzer.sh <pkg> [rounds_per_component]
# Components come from loot/<pkg>/manifest_analysis.json (exported ones).
# Fires: no extras / wrong types / oversized / rapid repeats. Captures crashes from logcat.
# DoS findings only where ROE allows — crashes are leads, not findings, until triaged.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GATE="$HERE/scripts/scope_gate.sh"
LOOT_BASE="${LOOT_BASE:-$PWD/loot}"
PKG="${1:-}"; ROUNDS="${2:-1}"
[ -z "$PKG" ] && { echo "usage: intent_fuzzer.sh <pkg> [rounds]"; exit 1; }
"$GATE" app "$PKG" >/dev/null 2>&1 || { echo "[ABORT] $PKG not authorized."; "$GATE" app "$PKG"; exit 1; }
command -v adb >/dev/null 2>&1 || { echo "[!] adb missing."; exit 1; }
adb devices | awk 'NR>1 && $2=="device"' | grep -q . || { echo "[!] no device attached."; exit 1; }
AJ="$LOOT_BASE/$PKG/manifest_analysis.json"
[ -f "$AJ" ] || { echo "[!] run static_recon.sh first (need manifest_analysis.json)."; exit 1; }

OUTD="$LOOT_BASE/$PKG/fuzz"; mkdir -p "$OUTD"; LOG="$OUTD/intent_fuzzer.log"; : > "$LOG"
mapfile -t COMPS < <(python3 - "$AJ" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
for c in d.get("components",[]):
    if c.get("exported"): print(c["name"])
PY
)
[ ${#COMPS[@]} -eq 0 ] && { echo "[i] no exported components."; exit 0; }
echo "[*] fuzzing ${#COMPS[@]} exported components of $PKG (rounds=$ROUNDS)" | tee -a "$LOG"

BIG="$(head -c 200000 /dev/zero | tr '\0' 'A')"   # 200k oversized string
fire(){ # fire <component> <label> [extra am args...]
  local comp="$1" label="$2"; shift 2
  adb shell log -p i -t HUNT "FUZZ $comp $label" 2>/dev/null
  timeout 8 adb shell am start -n "$PKG/$comp" "$@" >/dev/null 2>&1
  sleep 0.3
}
crashcheck(){
  timeout 4 adb logcat -d -b crash 2>/dev/null | grep -A25 -E "FATAL EXCEPTION|SIGSEGV|SIGABRT" > "$OUTD/crashes_raw.txt" || true
}
: > "$OUTD/crashes_raw.txt"
adb logcat -c 2>/dev/null
for comp in "${COMPS[@]}"; do
  echo "--- $comp" | tee -a "$LOG"
  for r in $(seq 1 "$ROUNDS"); do
    fire "$comp" "noextras"
    fire "$comp" "wrongtype-int-as-string" --es "id" "not_an_int" --es "url" "12345"
    fire "$comp" "nullish" --esn "data" --es "url" ""
    fire "$comp" "oversized" --es "data" "$BIG"
    fire "$comp" "fmtstr" --es "msg" "%s%s%n%x"
    fire "$comp" "uri-grant" --es "uri" "content://$PKG.provider/root/" -f 0x00000001
    for i in 1 2 3 4 5; do fire "$comp" "rapid$i" --es "id" "$i"; done
  done
done
echo "[*] collecting crashes…" | tee -a "$LOG"
timeout 6 adb logcat -d 2>/dev/null | grep -B2 -A25 -E "FATAL EXCEPTION|SIGSEGV|SIGABRT|tombstone" > "$OUTD/crashes.txt" || true
n="$(grep -cE 'FATAL EXCEPTION|SIGSEGV|SIGABRT' "$OUTD/crashes.txt" 2>/dev/null || echo 0)"
echo "[done] $n crash signature(s) -> $OUTD/crashes.txt (dedupe by stack, triage per ROE)" | tee -a "$LOG"
