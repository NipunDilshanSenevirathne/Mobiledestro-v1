#!/usr/bin/env python3
"""
mobsf_ingest.py — turn a MobSF baseline scan into fuel for the chaining engine.

MobSF (and most scanners) emit findings as a flat checklist and never connect
them. This ingests a MobSF JSON report, normalizes the surface (deep links,
exported components, WebView/JS-bridge signals, secrets, endpoints, storage,
network), maps each to the skill's engines, and — the point — emits
**chain candidates** by cross-referencing them (e.g. a browsable deep link +
a WebView with addJavascriptInterface => the flagship deeplink->webview->bridge
ATO chain to hunt).

Get the input: MobSF -> scan the app -> export/download the JSON report
(REST: POST /api/v1/report_json with the scan hash, or the UI "Report (JSON)").

Usage:
  python3 scripts/mobsf_ingest.py --report mobsf.json [--appid com.x] [--out loot/<appid>]

Output (in --out):
  mobsf_surface.json     normalized surface (per engine)
  chain_candidates.md    prioritized chain hypotheses for Claude to drive
Authorized apps only; this only reads a local file (no active testing).
"""
import argparse, json, os, sys

def g(d, *keys, default=None):
    for k in keys:
        if isinstance(d, dict) and k in d and d[k] not in (None, "", [], {}):
            return d[k]
    return default

def as_list(x):
    if x is None: return []
    if isinstance(x, list): return x
    if isinstance(x, dict): return [x]
    return [x]

def flatten_text(obj, limit=4000):
    try:
        return json.dumps(obj)[:limit].lower()
    except Exception:
        return str(obj)[:limit].lower()

# ---- code-analysis / manifest finding extraction (robust to MobSF versions) ----
def iter_code_findings(report):
    ca = g(report, "code_analysis", default={})
    # recent MobSF: {"findings": {title: {metadata:{severity,description,masvs,owasp-mstg,cvss}, files:{}}}}
    findings = g(ca, "findings", default=ca if isinstance(ca, dict) else {})
    out = []
    if isinstance(findings, dict):
        for title, body in findings.items():
            md = g(body, "metadata", default=body if isinstance(body, dict) else {})
            out.append({
                "title": title,
                "severity": str(g(md, "severity", default="info")).lower(),
                "description": g(md, "description", default=""),
                "masvs": g(md, "masvs", "owasp-mstg", "owasp-masvs", default=""),
                "files": list(g(body, "files", default={}).keys()) if isinstance(g(body, "files", default={}), dict) else [],
            })
    return out

def iter_manifest_findings(report):
    ma = g(report, "manifest_analysis", default={})
    lst = g(ma, "manifest_anaysis", "manifest_analysis", "manifest_findings", default=ma if isinstance(ma, list) else [])
    out = []
    for f in as_list(lst):
        if not isinstance(f, dict): continue
        out.append({
            "rule": g(f, "rule", "name", default=""),
            "title": g(f, "title", "name", default=""),
            "severity": str(g(f, "severity", "stat", default="info")).lower(),
            "description": g(f, "description", "desc", default=""),
            "component": g(f, "component", "name", default=""),
        })
    return out

WEBVIEW_KW = ["addjavascriptinterface", "javascript interface", "setjavascriptenabled",
              "javascript enabled", "webview", "setallowfileaccess", "allowfileaccess",
              "allowuniversalaccess", "loadurl", "remote webview debugging", "file access"]
STORAGE_KW = ["world readable", "world writable", "sharedpreferences", "sqlite", "logging",
              "logs sensitive", "external storage", "backup", "allowbackup", "clipboard",
              "keystore", "keychain", "cleartext"]
CRYPTO_KW  = ["ecb", "weak", "hardcoded", "insecure random", "md5", "sha1", "des ", "rc4", "iv "]
NET_KW     = ["cleartext", "ssl", "tls", "certificate", "pinning", "trustmanager", "hostnameverifier", "ats"]
AUTH_KW    = ["webview", "oauth", "token", "biometr", "fingerprint", "authentication"]

def kw_hit(text, kws):
    t = (text or "").lower(); return any(k in t for k in kws)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", required=True)
    ap.add_argument("--appid", default=None)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()
    try:
        report = json.load(open(a.report))
    except Exception as e:
        print(f"failed to read MobSF JSON: {e}", file=sys.stderr); sys.exit(1)

    appid = a.appid or g(report, "package_name", "bundle_id", "packagename", default="unknown_app")
    platform = "ios" if g(report, "bundle_id") or g(report, "macho_analysis") or g(report, "ats_analysis") else "android"
    out = a.out or os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "loot", appid)
    os.makedirs(out, exist_ok=True)

    surface = {"appid": appid, "platform": platform,
               "version": g(report, "version_name", "bundle_version", default=""),
               "deeplinks": [], "exported": [], "webview_signals": [], "secrets": [],
               "endpoints": [], "firebase": [], "storage": [], "crypto": [],
               "network": [], "providers": [], "permissions_dangerous": []}

    # --- deep links (Android browsable_activities / iOS URL schemes) ---
    bro = g(report, "browsable_activities", default={})
    if isinstance(bro, dict):
        for act, info in bro.items():
            surface["deeplinks"].append({
                "component": act,
                "schemes": g(info, "schemes", default=[]),
                "hosts": g(info, "hosts", default=[]),
                "paths": g(info, "paths", default=[]),
                "mimes": g(info, "mime_types", default=[]),
            })
    for ut in as_list(g(report, "bundle_url_types", default=[])):  # iOS
        surface["deeplinks"].append({"component": "iOS-URL-type",
                                     "schemes": g(ut, "CFBundleURLSchemes", default=[])})

    # --- manifest findings: exported, providers, network, storage ---
    for f in iter_manifest_findings(report):
        blob = f"{f['rule']} {f['title']} {f['description']} {f['component']}"
        low = blob.lower()
        if "exported" in low or "implicitly exported" in low or "is shared with other apps" in low:
            surface["exported"].append({"component": f["component"] or f["title"],
                                        "severity": f["severity"], "note": f["title"], "rule": f["rule"]})
        if "content provider" in low or "provider" in low:
            surface["providers"].append({"component": f["component"] or f["title"], "note": f["title"]})
        if kw_hit(blob, NET_KW):
            surface["network"].append({"note": f["title"], "severity": f["severity"]})
        if kw_hit(blob, STORAGE_KW):
            surface["storage"].append({"note": f["title"], "severity": f["severity"]})

    # --- code analysis: webview/js-bridge, storage, crypto, network, auth ---
    for f in iter_code_findings(report):
        blob = f"{f['title']} {f['description']}"
        rec = {"title": f["title"], "severity": f["severity"], "masvs": f["masvs"], "files": f["files"][:5]}
        if kw_hit(blob, WEBVIEW_KW): surface["webview_signals"].append(rec)
        if kw_hit(blob, STORAGE_KW): surface["storage"].append(rec)
        if kw_hit(blob, CRYPTO_KW):  surface["crypto"].append(rec)
        if kw_hit(blob, NET_KW):     surface["network"].append(rec)

    # --- secrets / endpoints / firebase ---
    for s in as_list(g(report, "secrets", "possible_secrets", default=[])):
        surface["secrets"].append(s if isinstance(s, str) else json.dumps(s))
    for u in as_list(g(report, "urls", default=[])):
        for url in (g(u, "urls", default=[]) if isinstance(u, dict) else [u]):
            surface["endpoints"].append(url)
    surface["firebase"] = as_list(g(report, "firebase_urls", default=[]))
    # dangerous permissions
    perms = g(report, "permissions", default={})
    if isinstance(perms, dict):
        for p, info in perms.items():
            if str(g(info, "status", default="")).lower() in ("dangerous", "signatureorsystem"):
                surface["permissions_dangerous"].append(p)
    # de-dup
    for k in ("secrets", "endpoints", "firebase", "permissions_dangerous"):
        surface[k] = sorted(set(map(str, surface[k])))

    json.dump(surface, open(os.path.join(out, "mobsf_surface.json"), "w"), indent=2)

    # ---------- CHAIN CANDIDATES (the differentiator) ----------
    cands = []
    has_deeplink = bool(surface["deeplinks"])
    has_webview  = bool(surface["webview_signals"])
    bridge = any("javascriptinterface" in (w["title"]+ " ".join(w.get("files",[]))).lower()
                 or "javascript interface" in w["title"].lower() for w in surface["webview_signals"])
    has_exported = bool(surface["exported"])
    has_provider = bool(surface["providers"])
    has_secret   = bool(surface["secrets"]) or bool(surface["firebase"])
    has_endpoint = bool(surface["endpoints"]) or bool(surface["firebase"])

    if has_deeplink and has_webview:
        cands.append(("CRITICAL", "FLAGSHIP: deep link -> WebView -> JS bridge -> ATO",
            f"{len(surface['deeplinks'])} browsable deep link(s)/scheme(s) + WebView signals"
            + (" incl. addJavascriptInterface (bridge exposed)" if bridge else "")
            + ". Trace the deep-link url-param into loadUrl; if unvalidated, load an OOB page and call the bridge to steal the token. engine-deeplink-webview.md"))
    elif has_deeplink:
        cands.append(("HIGH", "deep link param injection / open-redirect / token leak",
            "Browsable deep link(s) present; check for unvalidated forward, ?token=/?next=, scheme interception. engine-deeplink-webview.md + engine-auth-runtime.md"))
    if has_webview and not has_deeplink:
        cands.append(("MEDIUM", "WebView reachability hunt",
            "WebView/JS-bridge signals present; find any external path that controls the loaded URL (exported activity, intent extra). engine-deeplink-webview.md"))
    if has_exported:
        cands.append(("HIGH", "exported component -> confused deputy / sink reach",
            f"{len(surface['exported'])} exported component(s). Check intent redirection and whether any renders a WebView (-> flagship) or performs a sensitive action. engine-ipc-components.md"))
    if has_provider:
        cands.append(("HIGH", "ContentProvider data theft (SQLi / path traversal)",
            f"{len(surface['providers'])} provider finding(s). Query content:// for SQLi in selection and openFile() traversal. engine-ipc-components.md"))
    if has_secret:
        cands.append(("HIGH", "hardcoded secret / firebase -> backend access",
            f"{len(surface['secrets'])} secret(s), {len(surface['firebase'])} firebase url(s). Validate live against YOUR backend/project; chain to data/privilege. engine-storage-crypto.md"))
    if has_endpoint:
        cands.append(("HIGH", "pinning bypass -> API -> server-side IDOR/BOLA/logic",
            f"{len(surface['endpoints'])} endpoint(s) mapped. Bypass pinning (frida_unpin.js/objection), capture YOUR tokens, run claudebughunterv1/scripts/accessmatrix.py for IDOR/BOLA. engine-network-api.md"))
    if surface["storage"]:
        cands.append(("MEDIUM", "insecure storage -> token theft -> ATO",
            "Storage/logging findings; pull your own session data, find a token at rest, chain to account access. engine-storage-crypto.md"))

    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2}
    cands.sort(key=lambda c: sev_rank.get(c[0], 3))

    md = [f"# Chain candidates from MobSF — {appid} ({platform})  v{surface['version']}",
          "",
          "_Baseline scan normalized into chain hypotheses. Claude drives these via the engines;",
          "validate on your own device/account. Lead with the lowest-dup (chained) ones._", ""]
    if not cands:
        md.append("_No chain candidates auto-derived. Review mobsf_surface.json manually._")
    for sev, title, detail in cands:
        md.append(f"## [{sev}] {title}\n{detail}\n")
    open(os.path.join(out, "chain_candidates.md"), "w").write("\n".join(md))

    # ---- console summary ----
    print(f"\n=== MobSF ingest: {appid} ({platform}) v{surface['version']} ===")
    for k in ("deeplinks","exported","providers","webview_signals","secrets","firebase","endpoints","storage","crypto","network","permissions_dangerous"):
        print(f"  {k:22} {len(surface[k])}")
    print("\n=== CHAIN CANDIDATES (prioritized) ===")
    for sev, title, _ in cands:
        print(f"  [{sev}] {title}")
    print(f"\nwrote {out}/mobsf_surface.json and {out}/chain_candidates.md")
    print("Next: Claude reads chain_candidates.md + the decompiled code -> model.md -> drives engines -> device PoC.")

if __name__ == "__main__":
    main()
