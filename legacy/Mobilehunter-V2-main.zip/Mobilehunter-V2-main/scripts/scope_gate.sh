#!/usr/bin/env bash
# scope_gate.sh — authorization enforcement for androidhunter-ultimate.
#   scope_gate.sh app  <package-id>     # intake gate
#   scope_gate.sh api  <host|url>       # active-API gate
# Exit 0 = authorized/in-scope. Exit 1 = refused (FAIL CLOSED).
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
APPS="${APPS_FILE:-$HERE/scope/authorized_apps.txt}"
DOMS="${DOMAINS_FILE:-$HERE/scope/authorized_api_domains.txt}"
kind="${1:-}"; target="${2:-}"
[ -z "$kind" ] || [ -z "$target" ] && { echo "usage: scope_gate.sh app|api <target>"; exit 1; }

norm(){ echo "$1" | tr 'A-Z' 'a-z' | tr -d '[:space:]'; }

if [ "$kind" = "app" ]; then
  id="$(norm "$target")"
  [ -s "$APPS" ] || { echo "scope_gate: $APPS empty — add authorized app ids. REFUSING '$id'."; exit 1; }
  while IFS= read -r raw; do
    e="$(norm "${raw%%#*}")"; [ -z "$e" ] && continue
    if [ "$id" = "$e" ]; then echo "AUTHORIZED-APP: $id"; exit 0; fi
  done < "$APPS"
  echo "UNAUTHORIZED-APP: $id — not in $APPS. REFUSED."; exit 1
fi

if [ "$kind" = "api" ]; then
  host="$target"; host="${host#*://}"; host="${host%%/*}"; host="${host##*@}"; host="${host%%:*}"
  host="$(norm "$host")"
  [ -s "$DOMS" ] || { echo "scope_gate: $DOMS empty — add authorized backend domains. REFUSING '$host'."; exit 1; }
  while IFS= read -r raw; do
    e="$(norm "${raw%%#*}")"; [ -z "$e" ] && continue
    if [ "$host" = "$e" ] || [[ "$host" == *".$e" ]]; then echo "IN-SCOPE-API ($e): $host"; exit 0; fi
  done < "$DOMS"
  echo "OUT-OF-SCOPE-API: $host — not under any domain in $DOMS. REFUSED."; exit 1
fi
echo "scope_gate: unknown kind '$kind' (use app|api)"; exit 1
