/*
 * frida_intent_logger.js — watch IPC flows: startActivity/broadcasts/services,
 * PendingIntent creation, getIntent extras, content-URI grants.
 * Finds data leaks and forwarding primitives for intent-redirection chains.
 *
 *   frida -U -f <pkg> -l frida_intent_logger.js --no-pause
 */
'use strict';

function log(m){ console.log('[intent] ' + m); }

function dumpIntent(it) {
  try {
    var s = it.toString();
    var data = it.getDataString ? it.getDataString() : null;
    var extras = '';
    var b = it.getExtras ? it.getExtras() : null;
    if (b) {
      var keys = b.keySet().toArray();
      extras = ' extras={' + keys.join(',') + '}';
    }
    var flags = it.getFlags ? (' flags=0x' + it.getFlags().toString(16)) : '';
    return (s.length > 200 ? s.substring(0, 200) : s) + (data ? ' data=' + data : '') + extras + flags;
  } catch (e) { return '(dump failed: ' + e + ')'; }
}

Java.perform(function () {
  try {
    var ACT = Java.use('android.app.Activity');
    ACT.startActivityForResult.overload('android.content.Intent', 'int').implementation = function (i, rc) {
      log('startActivityForResult: ' + dumpIntent(i));
      this.startActivityForResult(i, rc);
    };
    ACT.getIntent.implementation = function () {
      var it = this.getIntent();
      log('getIntent: ' + dumpIntent(it));
      return it;
    };
  } catch (e) { log('Activity hooks skipped: ' + e); }

  try {
    var CTX = Java.use('android.app.ContextImpl');
    CTX.startService.implementation = function (i) {
      log('startService: ' + dumpIntent(i));
      return this.startService(i);
    };
    CTX.bindService.overload('android.content.Intent', 'android.content.ServiceConnection', 'int').implementation = function (i, c, f) {
      log('bindService: ' + dumpIntent(i));
      return this.bindService(i, c, f);
    };
    CTX.sendBroadcast.overload('android.content.Intent').implementation = function (i) {
      log('sendBroadcast: ' + dumpIntent(i));
      this.sendBroadcast(i);
    };
    CTX.sendBroadcast.overload('android.content.Intent', 'java.lang.String').implementation = function (i, p) {
      log('sendBroadcast(perm=' + p + '): ' + dumpIntent(i));
      this.sendBroadcast(i, p);
    };
    CTX.grantUriPermission.implementation = function (pkg, uri, mode) {
      log('grantUriPermission pkg=' + pkg + ' uri=' + uri + ' mode=0x' + mode.toString(16));
      this.grantUriPermission(pkg, uri, mode);
    };
  } catch (e) { log('Context hooks skipped: ' + e); }

  try {
    var PI = Java.use('android.app.PendingIntent');
    ['getActivity', 'getBroadcast', 'getService'].forEach(function (m) {
      try {
        PI[m].overloads.forEach(function (o) {
          o.implementation = function () {
            var args = Array.prototype.slice.call(arguments);
            var intent = args[1];
            var flags = args[args.length - 1];
            var mutable = (flags & 0x04000000) !== 0 ? 'MUTABLE' : ((flags & 0x02000000) !== 0 ? 'IMMUTABLE' : 'UNSPECIFIED');
            log('PendingIntent.' + m + ' [' + mutable + '] ' + dumpIntent(intent));
            return o.apply(this, arguments);
          };
        });
      } catch (e) {}
    });
  } catch (e) { log('PendingIntent hooks skipped: ' + e); }

  // setResult (data flowing BACK to the caller — exfil surface)
  try {
    var ACT2 = Java.use('android.app.Activity');
    ACT2.setResult.overload('int', 'android.content.Intent').implementation = function (rc, i) {
      log('setResult rc=' + rc + ': ' + dumpIntent(i));
      this.setResult(rc, i);
    };
  } catch (e) {}

  log('intent logging installed.');
});
