#!/usr/bin/env bash
# report_build.sh — assemble loot/<pkg>/findings/*/report.md into a final deliverable.
#   report_build.sh <loot-pkg-dir>        e.g. report_build.sh loot/com.dd.example
# Produces loot/<pkg>/final_report.md: run-summary header + all findings, dedup-sorted.
set -uo pipefail
D="${1:-}"; { [ -z "$D" ] || [ ! -d "$D" ]; } && { echo "usage: report_build.sh <loot-pkg-dir>"; exit 1; }
PKG="$(basename "$D")"
OUT="$D/final_report.md"
n=0

{
  echo "# Security assessment — $PKG"
  echo
  echo "App/version/sha256: see intake.md   |   Authorization: see scope.md (gate-enforced)"
  echo "Generated: $(date -Is)"
  echo
  echo "## Run summary"
  echo
  if [ -f "$D/ledger.md" ]; then
    echo "### Ledger"; echo; cat "$D/ledger.md"; echo
  fi
  echo "### Confirmed findings"
  echo
  for f in "$D"/findings/*/report.md; do
    [ -f "$f" ] || continue
    echo "---"; echo
    cat "$f"; echo
    n=$((n+1))
  done
  if [ "$n" -eq 0 ]; then echo "_No confirmed findings packaged yet (loot/$PKG/findings/*/report.md)._"; echo; fi
  echo "---"; echo
  echo "## Tested-clean / negatives"
  echo
  echo "_(fill in: engines and surfaces exercised with no finding — be specific; negatives prove thoroughness)_"
  echo
  echo "## Limits & ROE notes"
  echo
  echo "_(device constraints, out-of-scope handed back, PII avoided, throttling honored)_"
} > "$OUT"

echo "[done] $OUT ($n finding(s) assembled)"
