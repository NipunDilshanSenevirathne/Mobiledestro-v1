#!/usr/bin/env bash
# app_intake.sh — Play URL / APK / XAPK -> acquire -> unpack -> fingerprint -> seed workspace.
#   app_intake.sh "https://play.google.com/store/apps/details?id=com.x"
#   app_intake.sh /path/to/app.apk        app_intake.sh /path/to/app.xapk
# Authorization-gated (fails closed). Output: $LOOT_BASE/<pkg>/ (default ./loot).
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
GATE="$HERE/scripts/scope_gate.sh"
LOOT_BASE="${LOOT_BASE:-$PWD/loot}"
IN="${1:-}"; [ -z "$IN" ] && { echo "usage: app_intake.sh <play-url | .apk | .xapk/.apks/.apkm>"; exit 1; }
has(){ command -v "$1" >/dev/null 2>&1; }

PKG=""; LOCALFILE=""
case "$IN" in
  *play.google.com/store/apps/details*)
    PKG="$(printf '%s' "$IN" | sed -n 's/.*[?&]id=\([a-zA-Z0-9._]*\).*/\1/p')" ;;
  *.apk|*.xapk|*.apks|*.apkm) LOCALFILE="$IN" ;;
  *) echo "[!] unrecognized input. Provide a Play Store URL or a local .apk/.xapk."; exit 1 ;;
esac

# for local files, derive the REAL package id from the binary, not the filename
derive_pkg(){
  local f="$1" p=""
  if has aapt2; then p="$(aapt2 dump badging "$f" 2>/dev/null | sed -n "s/^package: name='\([^']*\)'.*/\1/p")"; fi
  [ -z "$p" ] && p="$(basename "$f" | sed 's/\.\(apk\|xapk\|apks\|apkm\)$//')"
  echo "$p"
}
[ -n "$LOCALFILE" ] && [ ! -f "$LOCALFILE" ] && { echo "[!] file not found: $LOCALFILE"; exit 1; }
[ -n "$LOCALFILE" ] && [[ "$LOCALFILE" == *.apk ]] && PKG="$(derive_pkg "$LOCALFILE")"
[ -n "$LOCALFILE" ] && [[ "$LOCALFILE" != *.apk ]] && PKG="$(basename "$LOCALFILE" | sed 's/\.\(xapk\|apks\|apkm\)$//')"
[ -z "$PKG" ] && { echo "[!] could not determine package id."; exit 1; }
echo "[*] package=$PKG"

# ---- authorization gate ----
if ! "$GATE" app "$PKG" >/dev/null 2>&1; then
  echo "[ABORT] '$PKG' not in scope/authorized_apps.txt — refusing intake."; "$GATE" app "$PKG"; exit 1
fi
echo "[ok] authorized."

OUT="$LOOT_BASE/$PKG"; mkdir -p "$OUT"
BIN=""

# ---- acquire ----
if [ -n "$LOCALFILE" ]; then
  cp "$LOCALFILE" "$OUT/" && BIN="$OUT/$(basename "$LOCALFILE")"
else
  if has apkeep; then
    echo "[*] downloading via apkeep…"; apkeep -a "$PKG" "$OUT/" 2>&1 | tail -2 || true
    BIN="$(ls "$OUT"/*.apk "$OUT"/*.xapk 2>/dev/null | head -1)"
  fi
  [ -z "$BIN" ] && { echo "[!] no APK acquired. Install apkeep (cargo install apkeep) or drop the file in $OUT/ and re-run with its path."; exit 1; }
fi
echo "[*] binary: $BIN"

# ---- splits ----
ANALYZE_APK="$BIN"
case "$BIN" in
  *.xapk|*.apks|*.apkm)
    echo "[*] split archive — extracting splits"
    mkdir -p "$OUT/splits"; unzip -o -q "$BIN" -d "$OUT/splits"
    ls "$OUT/splits"/*.apk 2>/dev/null | sed 's/^/    split: /'
    ANALYZE_APK="$(ls "$OUT/splits"/base.apk "$OUT/splits"/*.apk 2>/dev/null | head -1)"
    # re-derive real package id from base split
    RP="$(derive_pkg "$ANALYZE_APK")"
    if [ -n "$RP" ] && [ "$RP" != "$PKG" ]; then
      echo "[i] real package id: $RP (re-gating)"
      "$GATE" app "$RP" >/dev/null 2>&1 || { echo "[ABORT] '$RP' not authorized."; exit 1; }
      mv "$OUT" "$LOOT_BASE/$RP" 2>/dev/null || true; PKG="$RP"; OUT="$LOOT_BASE/$PKG"; BIN="$OUT/$(basename "$BIN")"
      ANALYZE_APK="$(ls "$OUT/splits"/base.apk "$OUT/splits"/*.apk 2>/dev/null | head -1)"
    fi
    echo "[i] install later with: adb install-multiple $OUT/splits/*.apk"
    ;;
esac
[ -z "$ANALYZE_APK" ] && { echo "[!] no analyzable APK found."; exit 1; }

# ---- unpack ----
mkdir -p "$OUT/unpacked"
if has apktool; then apktool d -f "$ANALYZE_APK" -o "$OUT/unpacked" >/dev/null 2>&1 && echo "    apktool -> unpacked/"; fi
if has jadx; then (jadx -d "$OUT/jadx" "$ANALYZE_APK" >/dev/null 2>&1 || jadx --no-imports -d "$OUT/jadx" "$ANALYZE_APK" >/dev/null 2>&1) && echo "    jadx -> jadx/"; fi
mkdir -p "$OUT/raw" && unzip -o -q "$ANALYZE_APK" -d "$OUT/raw" 2>/dev/null && echo "    unzip -> raw/ (assets/libs/META-INF)"
# unpack extra splits' code too (feature splits may carry dex)
if [ -d "$OUT/splits" ]; then
  for s in "$OUT/splits"/*.apk; do
    [ "$s" = "$ANALYZE_APK" ] && continue
    n="$(basename "$s" .apk)"
    [ -d "$OUT/jadx_$n" ] || { has jadx && (jadx -d "$OUT/jadx_$n" "$s" >/dev/null 2>&1) && echo "    jadx(split) -> jadx_$n/"; }
    unzip -o -q "$s" -d "$OUT/raw_$n" 2>/dev/null && echo "    unzip(split) -> raw_$n/"
  done
fi
[ ! -s "$OUT/unpacked/AndroidManifest.xml" ] && echo "    [!] manifest not decoded — apktool missing? analysis will be degraded."

# ---- fingerprint & integrity ----
{
  echo "# intake — $PKG"
  echo "input: $IN"; echo "date: $(date -Is)"
  echo "binary: $(basename "$ANALYZE_APK")"
  echo "sha256: $(sha256sum "$ANALYZE_APK" | awk '{print $1}')"
  if has aapt2; then
    echo; aapt2 dump badging "$ANALYZE_APK" 2>/dev/null | grep -E "^(package|application-label:|uses-permission|sdkVersion|targetSdkVersion)" | head -40
  fi
  if has apksigner; then
    echo; echo "## signing certs"
    apksigner verify --print-certs "$ANALYZE_APK" 2>/dev/null | grep -E "Signer|SHA-256|DN:" | head -12
    apksigner verify --print-certs "$ANALYZE_APK" 2>/dev/null | grep -qi "Android Debug" \
      && echo "!! DEBUG CERTIFICATE in shipped build — anyone can sign 'updates' / sharedUserId peers"
  fi
  if has apkid; then
    echo; echo "## packer/protector (apkid)"
    apkid "$ANALYZE_APK" 2>/dev/null | tail -5
    echo "(if packed: dump dex at runtime on YOUR device, e.g. frida-dexdump, then analyze the dump)"
  fi
} > "$OUT/intake.md"
grep -q "DEBUG CERT" "$OUT/intake.md" && echo "  [!!] debug signing cert detected (see intake.md)"
echo "    fingerprint -> intake.md"

# ---- seed workspace ----
cat > "$OUT/model.md" <<EOF
# App Model — $PKG   (fill in Phase 2; cite class/method for everything)
Binary/sha256: see intake.md
Backend API base(s) + auth scheme (how the token is built/sent):
Deep links / App Links (scheme, host, path, autoVerify)  -> entry points:
Exported components (type, name, permission?, behavior):
WebView/JS-bridge (which, JS enabled?, bridge methods + exposure, file access?, nav allowlist?):
ContentProviders (authority, exported, grantUri, path-permissions):
Storage (sensitive data locations):
Secrets found (redacted) -> backend reachability:
Framework layer (Flutter/RN/Unity/Capacitor? bridge channels?):
Native libs (.so inventory, JNI entries, hardening):
Trust boundaries (other apps <-> this app <-> backend):
Intended rules / who-should-reach-what -> abuse hypotheses:
EOF
cat > "$OUT/ledger.md" <<EOF
# Hunt Ledger — $PKG
| id | engine | hypothesis (entry → sink → impact) | evidence (class:line) | dynamic test | status | novelty |
|----|--------|------------------------------------|-----------------------|--------------|--------|---------|
EOF

echo
echo "[done] intake -> $OUT"
echo "  NEXT: $HERE/scripts/static_recon.sh $OUT/unpacked"
echo "  then: Kimi builds model.md and fans out the AgentSwarm engine sweep."
