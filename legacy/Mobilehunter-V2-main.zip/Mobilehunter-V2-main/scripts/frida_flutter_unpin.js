/*
 * frida_flutter_unpin.js — pinning bypass for FLUTTER apps. Java-layer hooks do NOT
 * cover Flutter: it verifies TLS in its own BoringSSL inside libflutter.so.
 * YOUR OWN device, YOUR OWN account, authorized app only.
 *
 *   frida -U -f <pkg> -l frida_flutter_unpin.js --no-pause
 *
 * How it works:
 *   1. If libflutter.so exports usable symbols (rare in release), hook them.
 *   2. Otherwise Memory.scan for a byte pattern of ssl_crypto_x509_session_verify_cert_chain
 *      and force its result to ssl_verify_ok (1).
 * Patterns CHANGE per Flutter engine version. If none of the shipped patterns match,
 * the script tells you exactly how to get the right one (reFlutter) — no silent failure.
 */
'use strict';

function log(m){ console.log('[flutter-unpin] ' + m); }

// ---- user-editable: add the pattern for YOUR libflutter.so version here ----
// Get it via reFlutter (https://github.com/Impact-I/reFlutter) for the matching engine,
// or by locating ssl_crypto_x509_session_verify_cert_chain in r2/Ghidra.
// Format: spaced hex bytes, '??' wildcards allowed (frida Memory.scan syntax).
var PATTERNS = [
  // commonly circulated arm64 prologue patterns for the verify function (varies!):
  'FF 83 02 D1 FC 6F 03 A9 FA 67 04 A9 F8 5F 05 A9 F6 57 06 A9 F4 4F 07 A9 FD 7B 08 A9 FD 03 02 91',
  'FF 43 02 D1 FE 67 03 A9 F8 5F 04 A9 F6 57 05 A9 F4 4F 06 A9 FD 7B 07 A9 FD 03 02 91'
];

function hookAddress(addr) {
  Interceptor.attach(addr, {
    onLeave: function (retval) {
      // BoringSSL verify callback: 1 = ssl_verify_ok, 0 = fail
      retval.replace(ptr(1));
    }
  });
  log('hooked verify function @ ' + addr + ' — result forced to ssl_verify_ok');
}

setTimeout(function () {
  var done = false;

  // 1) exported symbols first (unstripped builds)
  try {
    var m = Process.findModuleByName('libflutter.so');
    if (m) {
      var syms = m.enumerateSymbols().filter(function (s) {
        return /x509_session_verify_cert_chain|ssl_crypto_x509/i.test(s.name);
      });
      if (syms.length > 0) {
        hookAddress(syms[0].address);
        done = true;
      } else {
        log('libflutter.so @ ' + m.base + ' size=' + m.size + ' — no exported verify symbols (stripped; normal)');
      }
    } else {
      log('libflutter.so not loaded yet — if this is not a Flutter app, use frida_unpin.js instead');
    }
  } catch (e) { log('symbol path failed: ' + e); }

  // 2) pattern scan
  if (!done) {
    try {
      var mod = Process.findModuleByName('libflutter.so');
      if (mod) {
        for (var i = 0; i < PATTERNS.length && !done; i++) {
          var hits = Memory.scanSync(mod.base, mod.size, PATTERNS[i]);
          if (hits.length === 1) {
            log('pattern ' + i + ' unique hit @ ' + hits[0].address);
            hookAddress(hits[0].address);
            done = true;
          } else if (hits.length > 1) {
            log('pattern ' + i + ' ambiguous (' + hits.length + ' hits) — refine it');
          }
        }
      }
    } catch (e) { log('pattern scan failed: ' + e); }
  }

  if (!done) {
    log('NOT bypassed: no pattern matched this libflutter.so build.');
    log('-> identify the engine: strings lib/arm64-v8a/libflutter.so | grep -i "snapshot_version"');
    log('-> get the matching pattern via reFlutter and add it to PATTERNS at the top of this script,');
    log('   or reFlutter-patch the APK (repatches libflutter.so + repackage with your key).');
  }
}, 0);
