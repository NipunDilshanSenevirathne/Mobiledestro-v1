#!/usr/bin/env bash
# preflight.sh — verify androidhunter-ultimate toolchain, device, authorization scope.
set -uo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
miss=0
chk(){ command -v "$1" >/dev/null 2>&1 && printf "  [ok]   %-14s %s\n" "$1" "$(command -v "$1")" || { printf "  [MISS] %-14s %s\n" "$1" "${2:-}"; miss=$((miss+1)); }; }

echo "=== androidhunter-ultimate preflight ==="
echo; echo "-- acquisition & static (core) --"
chk apkeep  "cargo install apkeep (or supply APKs manually)"
chk apktool "https://apktool.org"
chk jadx    "https://github.com/skylot/jadx"
chk aapt2   "android sdk build-tools"
chk apksigner "android sdk build-tools"
chk unzip
chk curl
chk jq
echo "-- fingerprint & secrets --"
chk apkid   "pipx install apkid (packer detection)"
chk apkleaks "pipx install apkleaks"
chk trufflehog "https://github.com/trufflesecurity/trufflehog"
chk semgrep "pipx install semgrep"
echo "-- native analysis --"
chk rabin2  "radare2 suite"
chk r2      "radare2 suite"
chk ghidra  "optional: GUI decompiler"
echo "-- dynamic --"
chk adb     "platform-tools"
chk frida   "pipx install frida-tools"
chk objection "pipx install objection"
chk mitmproxy "pipx install mitmproxy (or use Burp)"
chk openssl
chk xz
echo "-- optional --"
chk bundletool "AAB support only"
chk drozer  "optional: provider_probe.sh covers the same ground via adb"

echo; echo "-- device --"
if command -v adb >/dev/null 2>&1; then
  devs="$(adb devices 2>/dev/null | awk 'NR>1 && $2=="device" {print $1}')"
  if [ -n "$devs" ]; then
    echo "$devs" | sed 's/^/  [ok] device: /'
    first="$(echo "$devs" | head -1)"
    echo "       abi: $(adb -s "$first" shell getprop ro.product.cpu.abi 2>/dev/null | tr -d '\r')  sdk: $(adb -s "$first" shell getprop ro.build.version.sdk 2>/dev/null | tr -d '\r')"
    adb -s "$first" shell su -c id 2>/dev/null | grep -q uid=0 && echo "  [ok] root: su works" || echo "  [i] root: no su (emulator 'adb root' may still work)"
  else
    echo "  [!] no adb device attached — dynamic phases degrade to static-only until you connect an emulator/device."
  fi
else
  echo "  [!] adb missing."
fi
if command -v frida >/dev/null 2>&1; then
  echo "  [i] host frida version: $(frida --version 2>/dev/null) — frida-server on device must match."
fi

echo; echo "-- authorization --"
if [ -s "$HERE/scope/authorized_apps.txt" ] && grep -qvE '^\s*(#|$)' "$HERE/scope/authorized_apps.txt"; then
  echo "  authorized apps:"; grep -vE '^\s*(#|$)' "$HERE/scope/authorized_apps.txt" | sed 's/^/    /'
else echo "  [!] scope/authorized_apps.txt EMPTY — add the package ids you may test (gate fails closed)."; fi
if [ -s "$HERE/scope/authorized_api_domains.txt" ] && grep -qvE '^\s*(#|$)' "$HERE/scope/authorized_api_domains.txt"; then
  echo "  in-scope backend domains:"; grep -vE '^\s*(#|$)' "$HERE/scope/authorized_api_domains.txt" | sed 's/^/    /'
else echo "  [!] scope/authorized_api_domains.txt EMPTY — needed before any active API testing."; fi
[ -s "$HERE/scope/rules.md" ] && echo "  [ok] rules.md present — READ before dynamic testing." || echo "  [!] scope/rules.md missing."

echo; echo "-- discipline --"
echo "  Authorized apps + in-scope backends + ROE. Dynamic testing on YOUR OWN device/emulator"
echo "  with YOUR OWN test accounts. Never real-user PII. scope_gate.sh fails closed."
echo "=== preflight done ($miss optional/missing tools) ==="
