/*
 * frida_crypto_monitor.js — runtime secret-leak & weak-crypto hunting:
 * Cipher keys/IVs, Keystore ops, Log.* output, SQLite statements, Prefs writes,
 * file writes under the sandbox, Base64 blobs. YOUR OWN account/device.
 *
 *   frida -U -f <pkg> -l frida_crypto_monitor.js --no-pause
 * (noisy by design; pipe to a file:  ... | tee loot/<pkg>/frida/crypto.txt)
 */
'use strict';

function log(m){ console.log('[crypto] ' + m); }
function hex(b) {
  if (!b) return '(null)';
  try {
    var s = '';
    for (var i = 0; i < Math.min(b.length, 64); i++) s += ('0' + (b[i] & 0xff).toString(16)).slice(-2);
    return s + (b.length > 64 ? '…' : '');
  } catch (e) { return '(hex failed)'; }
}
function str(b) {
  if (!b) return '';
  try { return Java.use('java.lang.String').$new(b).substring(0, 120); } catch (e) { return ''; }
}

Java.perform(function () {
  // ---- Cipher ----
  try {
    var C = Java.use('javax.crypto.Cipher');
    C.getInstance.overload('java.lang.String').implementation = function (t) {
      if (!/GCM|CBC\/PKCS5|AES\/CTR/i.test(t)) log('Cipher.getInstance("' + t + '")  <-- check mode/padding');
      return this.getInstance(t);
    };
    C.init.overload('int', 'java.security.Key').implementation = function (op, key) {
      log('Cipher.init op=' + op + ' alg=' + key.getAlgorithm() + ' key=' + hex(key.getEncoded()));
      this.init(op, key);
    };
    C.init.overload('int', 'java.security.Key', 'java.security.spec.AlgorithmParameterSpec').implementation = function (op, key, spec) {
      var iv = '';
      try { iv = ' iv=' + hex(Java.cast(spec, Java.use('javax.crypto.spec.IvParameterSpec')).getIV()); } catch (e) {}
      log('Cipher.init op=' + op + ' alg=' + key.getAlgorithm() + ' key=' + hex(key.getEncoded()) + iv);
      this.init(op, key, spec);
    };
  } catch (e) { log('Cipher hooks skipped: ' + e); }

  try {
    var SK = Java.use('javax.crypto.spec.SecretKeySpec');
    SK.$init.overload('[B', 'java.lang.String').implementation = function (b, alg) {
      log('SecretKeySpec alg=' + alg + ' key(hex)=' + hex(b) + ' key(str)="' + str(b) + '"  <-- hardcoded?');
      this.$init(b, alg);
    };
  } catch (e) {}

  // ---- Keystore ----
  try {
    var KS = Java.use('java.security.KeyStore');
    KS.getKey.implementation = function (alias, pw) {
      var k = this.getKey(alias, pw);
      log('KeyStore.getKey("' + alias + '") -> ' + (k ? k.getAlgorithm() : 'null'));
      return k;
    };
  } catch (e) {}

  // ---- MessageDigest ----
  try {
    var MD = Java.use('java.security.MessageDigest');
    MD.getInstance.overload('java.lang.String').implementation = function (a) {
      if (/MD5|SHA-?1/i.test(a)) log('MessageDigest("' + a + '")  <-- weak hash, context?');
      return this.getInstance(a);
    };
  } catch (e) {}

  // ---- Log.* — the runtime token-leak goldmine ----
  try {
    var L = Java.use('android.util.Log');
    ['d', 'v', 'i', 'w', 'e'].forEach(function (m) {
      try {
        L[m].overload('java.lang.String', 'java.lang.String').implementation = function (tag, msg) {
          if (/token|secret|passw|auth|session|bearer|cookie|key|otp|code/i.test(msg))
            log('Log.' + m + ' [' + tag + '] ' + msg.substring(0, 200) + '  <-- SENSITIVE IN LOGS?');
          return this[m](tag, msg);
        };
      } catch (e) {}
    });
  } catch (e) {}

  // ---- SharedPreferences writes ----
  try {
    var ED = Java.use('android.content.SharedPreferences$Editor') ||
             Java.use('android.app.SharedPreferencesImpl$EditorImpl');
  } catch (e) {}
  try {
    var SPE = Java.use('android.app.SharedPreferencesImpl$EditorImpl');
    SPE.putString.implementation = function (k, v) {
      if (/token|secret|passw|auth|session|refresh|bearer|key/i.test(k))
        log('Prefs.putString "' + k + '" = "' + (v ? v.substring(0, 80) : v) + '"  <-- at-rest cleartext?');
      return this.putString(k, v);
    };
  } catch (e) { /* some apps use a different editor impl */ }

  // ---- SQLite ----
  try {
    var DB = Java.use('android.database.sqlite.SQLiteDatabase');
    DB.execSQL.overload('java.lang.String').implementation = function (sql) {
      log('execSQL: ' + sql.substring(0, 200));
      this.execSQL(sql);
    };
  } catch (e) {}

  // ---- File writes in sandbox ----
  try {
    var FOS = Java.use('java.io.FileOutputStream');
    FOS.$init.overload('java.io.File', 'boolean').implementation = function (f, ap) {
      var p = f.getAbsolutePath();
      if (p.indexOf('/data/data/') === 0 && /token|secret|session|auth|cookie/i.test(p))
        log('FileOutputStream -> ' + p + '  <-- sensitive filename');
      this.$init(f, ap);
    };
  } catch (e) {}

  // ---- Base64 (blob spotter) ----
  try {
    var B = Java.use('android.util.Base64');
    B.encodeToString.overload('[B', 'int').implementation = function (b, f) {
      var s = str(b);
      if (/token|secret|passw|bearer/i.test(s)) log('Base64.encode of sensitive-looking: "' + s + '"');
      return this.encodeToString(b, f);
    };
  } catch (e) {}

  log('crypto/secret monitoring installed (noisy — pipe to file).');
});
