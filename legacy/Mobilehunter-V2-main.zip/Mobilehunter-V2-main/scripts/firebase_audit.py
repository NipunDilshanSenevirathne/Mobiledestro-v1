#!/usr/bin/env python3
"""
firebase_audit.py — read-only Firebase/cloud misconfiguration battery for an
AUTHORIZED app whose firebase config was found in its binary.

Usage:
  firebase_audit.py --pkg com.x --loot loot/com.x [--confirm]
  (config auto-read from loot/<pkg>/firebase_config.txt + unpacked strings.xml;
   or pass --db / --project / --bucket / --apikey explicitly)

Probes (read-only, non-destructive):
  1. RTDB:        GET https://<db>/.json?shallow=true        (open read?)
  2. Firestore:   GET .../documents/<guessed-collection>     (open read?)
  3. Storage:     GET .../v0/b/<bucket>/o?maxResults=1       (open list?)
Writes loot/<pkg>/firebase_audit.md. NO writes are ever performed; proving write
access (if needed) = create+delete YOUR OWN test node, manually, per ROE.
"""
import argparse, json, os, re, subprocess, sys, urllib.request, urllib.error

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TIMEOUT = 12

def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {"User-Agent": "androidhunter-audit/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
            body = r.read(4096).decode("utf-8", "replace")
            return r.status, body
    except urllib.error.HTTPError as e:
        try:
            body = e.read(2048).decode("utf-8", "replace")
        except Exception:
            body = ""
        return e.code, body
    except Exception as e:
        return None, str(e)

def gate_app(pkg):
    r = subprocess.run([os.path.join(HERE, "scripts", "scope_gate.sh"), "app", pkg],
                       capture_output=True, text=True)
    return r.returncode == 0

def harvest(loot):
    vals = {}
    files = []
    fc = os.path.join(loot, "firebase_config.txt")
    if os.path.isfile(fc):
        files.append(fc)
    sx = os.path.join(loot, "unpacked", "res", "values", "strings.xml")
    if os.path.isfile(sx):
        files.append(sx)
    pats = {
        "db":      re.compile(r"https://[a-z0-9.\-]+\.(firebaseio\.com|firebasedatabase\.app)"),
        "project": re.compile(r'"project_id"[^>]*>([^<]+)<|project_id["\s:=]+"?([a-z0-9\-]+)"?'),
        "bucket":  re.compile(r"\b[a-z0-9.\-]+\.appspot\.com\b"),
        "apikey":  re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    }
    for f in files:
        try:
            text = open(f, errors="replace").read()
        except OSError:
            continue
        for k, p in pats.items():
            if k in vals:
                continue
            m = p.search(text)
            if m:
                vals[k] = next((g for g in m.groups() if g), m.group(0))
    return vals

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pkg", required=True)
    ap.add_argument("--loot", required=True)
    ap.add_argument("--db"); ap.add_argument("--project"); ap.add_argument("--bucket"); ap.add_argument("--apikey")
    ap.add_argument("--confirm", action="store_true", help="acknowledge ROE: read-only probes of first-party infra")
    a = ap.parse_args()

    if not gate_app(a.pkg):
        print(f"[ABORT] {a.pkg} not authorized (scope_gate)."); sys.exit(1)
    if not a.confirm:
        print("[i] read-only battery, but still: re-run with --confirm to acknowledge the ROE."); sys.exit(1)

    vals = harvest(a.loot)
    db = a.db or vals.get("db")
    project = a.project or vals.get("project")
    bucket = a.bucket or vals.get("bucket")
    apikey = a.apikey or vals.get("apikey")
    out = [f"# Firebase/cloud audit — {a.pkg}",
           f"db={db} project={project} bucket={bucket} apikey={'found' if apikey else 'none'}", ""]
    print(out[0]); print(out[1])

    if db:
        st, body = http_get(f"{db.rstrip('/')}/.json?shallow=true")
        verdict = "OPEN READ (likely finding!)" if st == 200 else ("closed (401/403)" if st in (401, 403) else f"inconclusive ({st})")
        out.append(f"## RTDB shallow read: {st} -> {verdict}\n```\n{body[:600]}\n```")
        print(f"  RTDB: {st} {verdict}")
    if project:
        for coll in ("users", "user", "accounts", "orders", "tokens", "messages"):
            st, body = http_get(
                f"https://firestore.googleapis.com/v1/projects/{project}/databases/(default)/documents/{coll}?pageSize=1"
                + (f"&key={apikey}" if apikey else ""))
            if st == 200:
                out.append(f"## Firestore collection '{coll}': 200 OPEN READ\n```\n{body[:600]}\n```")
                print(f"  Firestore '{coll}': 200 OPEN READ")
            else:
                print(f"  Firestore '{coll}': {st}")
    if bucket:
        b = bucket.strip()
        st, body = http_get(f"https://firebasestorage.googleapis.com/v0/b/{b}/o?maxResults=1")
        verdict = "OPEN LIST (finding)" if st == 200 else ("closed" if st in (401, 403, 404) else f"inconclusive ({st})")
        out.append(f"## Storage list: {st} -> {verdict}\n```\n{body[:600]}\n```")
        print(f"  Storage: {st} {verdict}")
    if not any([db, project, bucket]):
        print("  [i] no firebase config found — nothing to probe.")
        out.append("No firebase config harvested from the binary.")

    out.append("\n_Notes: all probes read-only. 200s above = confirm with a screenshot of ONE "
               "record (your own seeded data if possible), redact, and map the data class "
               "exposed. Write-access proof, if required: create+delete YOUR OWN test node "
               "only, per ROE._")
    os.makedirs(a.loot, exist_ok=True)
    with open(os.path.join(a.loot, "firebase_audit.md"), "w") as f:
        f.write("\n\n".join(out) + "\n")
    print(f"[done] -> {a.loot}/firebase_audit.md")

if __name__ == "__main__":
    main()
