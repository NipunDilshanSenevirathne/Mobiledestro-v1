#!/usr/bin/env python3
"""
chain_suggest.py — cross-reference the skill's own recon output into prioritized
chain candidates. This is what turns "surface files" into a hunt plan — the same
cross-referencing mobsf_ingest does for MobSF, but native to our recon.

Usage: chain_suggest.py --loot loot/<pkg>
Reads: manifest_analysis.json, deeplinks.txt, webview.txt, exported.txt,
       providers.txt, flags.txt, secrets.txt, endpoints.txt, firebase_config.txt,
       api_surface.txt, native.txt
Writes: loot/<pkg>/chain_candidates.md
"""
import argparse, json, os, re

def read(p):
    try:
        return open(p, errors="replace").read()
    except OSError:
        return ""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--loot", required=True)
    a = ap.parse_args()
    L = a.loot
    ma = {}
    maj = os.path.join(L, "manifest_analysis.json")
    if os.path.isfile(maj):
        ma = json.load(open(maj))
    webview = read(os.path.join(L, "webview.txt"))
    flags = read(os.path.join(L, "flags.txt"))
    secrets = read(os.path.join(L, "secrets.txt"))
    endpoints = read(os.path.join(L, "endpoints.txt"))
    fb = read(os.path.join(L, "firebase_config.txt"))
    native = read(os.path.join(L, "native.txt"))

    deeplinks = ma.get("deeplinks", [])
    browsable = [d for d in deeplinks if d.get("browsable")]
    exported = [c for c in ma.get("components", []) if c.get("exported")]
    providers = ma.get("providers", [])
    warnings = ma.get("warnings", [])

    has_bridge = "addJavascriptInterface" in webview or "@JavascriptInterface" in webview
    has_file_access = "setAllowFileAccess" in webview or "setAllowUniversalAccessFromFileURLs" in webview
    has_webdebug = "setWebContentsDebuggingEnabled" in webview
    has_loadurl = "loadUrl" in webview
    has_secrets = len([l for l in secrets.splitlines() if l.strip() and not l.startswith("#")]) > 0
    has_fb = bool(fb.strip())
    has_native = ".so" in native
    has_intent_redirect = bool(re.search(r"getParcelableExtra|getSerializableExtra", webview))

    cands = []
    def add(prio, name, chain, evidence, first_test):
        cands.append((prio, name, chain, evidence, first_test))

    if deeplinks and has_bridge:
        add("P1-CRITICAL", "Deep link → WebView → JS bridge → ATO (flagship)",
            "browsable deeplink entry → loadUrl(param) → window.<bridge>.<method>() → token exfil",
            f"{len(browsable) or len(deeplinks)} deeplink filter(s); addJavascriptInterface hits in webview.txt",
            "fire deeplink_fuzz.sh with OOB + frida_bridge_trace.js; serve oob_server.py /poc.html")
    if deeplinks and has_loadurl and not has_bridge:
        add("P1-HIGH", "Deep link → arbitrary WebView load",
            "browsable deeplink → loadUrl(attacker URL) → phishing-in-chrome / file read",
            "deeplink filters + loadUrl without visible bridge",
            "deeplink_probe.sh to OOB; then run allowlist-bypass corpus")
    if deeplinks and has_file_access:
        add("P1-HIGH", "Deep link → WebView file read",
            "deeplink → file:// load / universal-access-from-file → read sandbox files",
            "deeplink filters + setAllowFileAccess family hits",
            "file:///data/data/<pkg>/shared_prefs/ payloads from deeplink_fuzz.sh")
    if has_webdebug:
        add("P1-HIGH", "WebView debugging enabled → chrome://inspect control",
            "setWebContentsDebuggingEnabled(true) → devtools JS exec in app WebView → bridge/session",
            "setWebContentsDebuggingEnabled hit in webview.txt",
            "verify in the SHIPPED build (smali), then chrome://inspect on own device")
    if has_intent_redirect:
        add("P1-HIGH", "Intent redirection → protected components",
            "exported forwarder → nested Intent extra → non-exported component / URI-grant read",
            "getParcelableExtra/getSerializableExtra near component routing",
            "frida_intent_logger.js to watch forwards; PoC nested intent")
    for p in providers:
        if p.get("exported") and not (p.get("permission") or p.get("readPermission")):
            add("P1-HIGH", f"Exported provider {p.get('authorities')} → SQLi/traversal",
                "content:// authority → openFile traversal / query SQLi → token DB → API",
                "provider exported with no permission (manifest_analysis.json)",
                "provider_probe.sh battery on own seeded data")
        if p.get("grantUriPermissions") and not p.get("exported"):
            add("P2-MED", f"grantUri provider {p.get('authorities')} via forwarding",
                "exported component forwards FLAG_GRANT + content:// URI → file read",
                "grantUriPermissions=true with exported=false",
                "chain with intent-redirection probe")
    oauth_hint = re.search(r"oauth|authorize|/token|sso|login", endpoints, re.I)
    custom_schemes = {s for d in deeplinks for s in d.get("schemes", [])
                      if s not in ("http", "https")}
    if custom_schemes and oauth_hint:
        add("P1-HIGH", "OAuth custom-scheme redirect interception",
            "custom scheme + oauth endpoints → malicious app same-scheme → code/token theft",
            f"schemes={sorted(custom_schemes)}; oauth-ish endpoints present",
            "check PKCE/state in token exchange; scheme-collision PoC app")
    if has_fb:
        add("P1-HIGH", "Firebase misconfig → direct data access",
            "google-services values in binary → open RTDB/Firestore/Storage → PII",
            "firebase_config.txt populated",
            "firebase_audit.py --confirm (read-only battery)")
    if has_secrets:
        add("P2-MED", "Hardcoded secret → live backend",
            "key/secret in binary → validate live (benign authorized probe) → chain to API/cloud",
            "secrets.txt candidates",
            "validate each; live = finding, dead = note")
    if "debuggable" in flags:
        add("P2-MED", "Debuggable build → run-as data read",
            "android:debuggable=true → run-as pulls sandbox → tokens",
            "flags.txt",
            "run-as <pkg> on own device/emulator")
    if custom_schemes:
        add("P2-MED", "Custom-scheme surface sweep",
            f"schemes {sorted(custom_schemes)} → param injection / scheme collision",
            "deeplinks.txt",
            "deeplink_fuzz.sh matrix; watch logcat + OOB")
    if has_native:
        add("P3-DEEP", "Native .so surface",
            "JNI entries ← untrusted input → unsafe sinks; hardcoded native secrets",
            "native.txt inventory",
            "strings/r2 on libs; secrets_hunter already scanned; fuzz reachable parsers")
    if any("no host" in w for w in warnings):
        add("P2-MED", "Scheme-without-host filter → link hijack",
            "intent-filter matches ALL hosts → disambiguation/hijack surface",
            "manifest warnings",
            "install-time behavior + browser delivery test")

    out = ["# Chain candidates (auto-suggested — validate before hunting)", ""]
    if not cands:
        out.append("No chain preconditions detected from recon files. Re-run static_recon.sh "
                   "or hunt the ledger hypotheses manually.")
    for prio, name, chain, ev, test in sorted(cands):
        out.append(f"## [{prio}] {name}\n- chain: {chain}\n- evidence: {ev}\n- first test: {test}\n")
    path = os.path.join(L, "chain_candidates.md")
    open(path, "w").write("\n".join(out) + "\n")
    print(f"[chain_suggest] {len(cands)} chain candidates -> {path}")
    for prio, name, *_ in sorted(cands):
        print(f"  [{prio}] {name}")

if __name__ == "__main__":
    main()
