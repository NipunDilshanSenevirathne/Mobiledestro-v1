/*
 * frida_rootbypass.js — bypass common root / emulator / debugger / tamper checks
 * to REACH the real attack surface on YOUR OWN device (RESILIENCE, not a finding).
 *
 *   frida -U -f <pkg> -l frida_rootbypass.js --no-pause
 *
 * Honest limit: hardware-backed Play Integrity / key attestation is NOT reliably
 * spoofable — if the app enforces it server-side, say so and test what's reachable.
 */
'use strict';

function log(m){ console.log('[rootbypass] ' + m); }

Java.perform(function () {
  var ROOT_PATHS = ['/system/app/Superuser.apk', '/sbin/su', '/system/bin/su', '/system/xbin/su',
    '/data/local/xbin/su', '/data/local/bin/su', '/system/sd/xbin/su', '/system/bin/failsafe/su',
    '/data/local/su', '/su/bin/su', '/su/bin', '/magisk', '/data/adb/magisk'];

  // 1) java.io.File.exists / canRead / isFile for known root paths
  try {
    var F = Java.use('java.io.File');
    F.exists.implementation = function () {
      var p = this.getAbsolutePath();
      if (ROOT_PATHS.indexOf(p) !== -1 || p.indexOf('magisk') !== -1 || p.indexOf('/su') !== -1) {
        log('File.exists(' + p + ') -> false'); return false;
      }
      return this.exists();
    };
  } catch (e) { log('File hook skipped: ' + e); }

  // 2) Runtime.exec / ProcessBuilder for 'su', 'which su', 'magisk'
  try {
    var RT = Java.use('java.lang.Runtime');
    RT.exec.overload('java.lang.String').implementation = function (cmd) {
      if (/(\bsu\b|which|magisk|busybox)/.test(cmd)) {
        log('Runtime.exec("' + cmd + '") -> fake IOException');
        throw Java.use('java.io.IOException').$new('Permission denied');
      }
      return this.exec(cmd);
    };
  } catch (e) { log('Runtime.exec skipped: ' + e); }

  // 3) RootBeer-style checks (scottyab + generic detectors)
  ['com.scottyab.rootbeer.RootBeer', 'com.noshufou.android.su', 'io.michaelrocks.paranoid.Detector'].forEach(function (c) {
    try {
      var RB = Java.use(c);
      var methods = RB.class.getDeclaredMethods();
      methods.forEach(function (m) {
        var n = m.getName();
        if (/root|su|busybox|magisk|dangerous|detect/i.test(n)) {
          try { RB[n].overloads.forEach(function (o) {
            o.implementation = function () { log(c + '.' + n + ' -> false'); return false; };
          }); } catch (e) {}
        }
      });
    } catch (e) {}
  });

  // 4) Build fields (emulator/test-keys detection)
  try {
    var B = Java.use('android.os.Build');
    B.TAGS.value = 'release-keys';
    B.FINGERPRINT.value = 'google/redfin/redfin:13/TQ3A.230901.001/10750268:user/release-keys';
    B.MODEL.value = 'Pixel 5';
    B.MANUFACTURER.value = 'Google';
    B.PRODUCT.value = 'redfin';
    B.HARDWARE.value = 'redfin';
    log('Build fields spoofed (release-keys / Pixel 5)');
  } catch (e) { log('Build spoof skipped: ' + e); }

  // 5) SystemProperties ro.debuggable / ro.secure
  try {
    var SP = Java.use('android.os.SystemProperties');
    SP.get.overload('java.lang.String').implementation = function (k) {
      var v = this.get(k);
      if (k === 'ro.debuggable') { log('ro.debuggable -> 0'); return '0'; }
      if (k === 'ro.secure') { log('ro.secure -> 1'); return '1'; }
      if (k === 'ro.build.type') { return 'user'; }
      return v;
    };
  } catch (e) { log('SystemProperties skipped: ' + e); }

  // 6) Debug.isDebuggerConnected
  try {
    var D = Java.use('android.os.Debug');
    D.isDebuggerConnected.implementation = function () { log('isDebuggerConnected -> false'); return false; };
  } catch (e) {}

  // 7) PackageManager checks for root/magisk/frida packages
  try {
    var PM = Java.use('android.app.ApplicationPackageManager');
    PM.getPackageInfo.overload('java.lang.String', 'int').implementation = function (pkg, flags) {
      if (/magisk|supersu|superuser|frida|xposed|substrate/.test(pkg)) {
        log('getPackageInfo(' + pkg + ') -> NameNotFound');
        throw Java.use('android.content.pm.PackageManager$NameNotFoundException').$new(pkg);
      }
      return this.getPackageInfo(pkg, flags);
    };
  } catch (e) { log('PackageManager skipped: ' + e); }

  // 8) Telephony/sensor emulator heuristics — light touch
  try {
    var TM = Java.use('android.telephony.TelephonyManager');
    TM.getNetworkOperatorName.implementation = function () { return 'T-Mobile'; };
  } catch (e) {}

  log('root/emulator/debugger bypass installed (reach-the-surface only).');
});
