# androidhunter-ultimate

**The deepest authorized Android application security hunting workflow for [Kimi Code CLI](https://github.com/MoonshotAI/kimi-code).**

A Kimi skill that turns the CLI into an autonomous Android bug-hunting operator: store URL or APK in → full reverse-engineering → attack-surface model → **parallel engine sweep across subagents** → device/emulator confirmation with Frida → backend IDOR/BOLA bridge → chain synthesis → adversarial triage → MASVS-mapped PoC reports.

> **Core principle: a finding is not a finding until it is reproduced on your own device/emulator with your own accounts.**

Successor to [`claudemobilehunterv1`](../claudemobilehunterv1) — rebuilt Android-only for depth, native to Kimi Code CLI where the tools actually execute.

---

## Why not a scanner?

Scanners emit checklist lines ("WebView JS enabled", "exported activity exists"). The bugs that pay — and that aren't already duplicated a hundred times — live in **chains** that require reconstructing the app's logic:

```
deep link (?url=) → WebView (no allowlist) → JS bridge .getToken() → exfil → one-click ATO
exported activity → intent redirection → non-exported component → confused deputy
ContentProvider traversal → shared_prefs token → backend API → IDOR → cross-tenant PII
hardcoded key → open Firebase → user data, no app interaction needed
pinning bypass → API map → mass assignment / business-logic (the real money)
```

Tools decompile. **The LLM reasons about reachability and trust.** This skill wires that reasoning to real execution: apktool/jadx/adb/Frida/objection actually run, fuzzers actually fire, PoCs actually capture tokens at your OOB.

---

## v1 → v2

| | claudemobilehunterv1 | androidhunter-ultimate |
|---|---|---|
| Platform | iOS + Android | **Android-only, deepest** |
| Runtime | Claude (advisory) | **Kimi Code CLI (real tool execution)** |
| Orchestration | single-thread | **AgentSwarm parallel engine subagents + background tasks** |
| Engines | 5 | **8** (+ native code, cross-platform, Firebase/cloud) |
| Manifest analysis | grep | **full parser (implicit-export rules, routing table)** |
| Secrets | grep | **regex library + Shannon entropy, file:line evidence** |
| Dynamic | 1 Frida script | **5 Frida scripts + device setup automation** |
| Fuzzing | manual | **deep-link matrix generator, intent fuzzer, provider battery** |
| Backend bridge | external dependency | **built-in access-matrix replay tool** |
| Triage | — | **prosecutor–defender–judge adversarial subagents** |
| Self-check | — | **regression corpus of bug-pattern cards** |
| AuthZ gate | fail-closed | fail-closed (unchanged, non-negotiable) |

---

## The 8 engines

1. **Deep link / App Link → WebView → JS bridge** *(flagship)* — unvalidated forwards, allowlist-bypass corpus, `@JavascriptInterface` enumeration, `intent://` redirection, App-Link hijack via subdomain takeover, token-leaking links, one-click ATO.
2. **IPC / exported components / intent redirection / ContentProviders** — confused deputies, PendingIntent hijack, provider SQLi (incl. `sortOrder` blind), path traversal, grantUri forwarding, StrandHogg, tapjacking, parcel corner cases.
3. **Network → backend API** — pinning bypass (gate, not the bug), Retrofit/OkHttp/HMAC mapping, then **IDOR/BOLA, mass assignment, business logic, OTP races** with your own two accounts.
4. **Storage, secrets & crypto** — at-rest leaks, hardcoded keys (validated live before reporting), Keystore misuse, `Log.*` token leaks, WebView debugging left on.
5. **Auth / OAuth / biometric** — custom-scheme code interception, missing PKCE/state, account linking, JWT confusion, client-side biometric gates (Frida callback hooks).
6. **Native code (.so / JNI)** — hardcoded native secrets, `RegisterNatives` mapping, reachable memory-unsafe sinks, zip traversal, hardening checks (r2/rabin2).
7. **Cross-platform frameworks** — Flutter (BoringSSL pinning via reFlutter-style hooks, MethodChannels), React Native (Hermes bundle, `@ReactMethod`, AsyncStorage, OTA integrity), Unity (il2cpp), Capacitor/Cordova (remote `server.url`).
8. **Firebase & cloud** — open RTDB / Firestore / Storage rules, FCM legacy keys, S3/GCS/Azure buckets, service-account blobs in assets — read-only battery, own-seeded-data proof bar.

---

## Pipeline

```
PHASE 0  authorization gate (scope files + scope_gate.sh — FAILS CLOSED)
PHASE 1  preflight + intake (store URL/APK/XAPK → acquire → unpack → fingerprint)
PHASE 2  static recon → model.md (routing table, bridges, API map, trust boundaries)
PHASE 3  AgentSwarm: 8 engine subagents sweep jadx in parallel → ledger.md
PHASE 4  dynamic confirmation: Frida suite, deeplink_fuzz, intent fuzzer,
         provider battery (background tasks) — device PoC or "unconfirmed lead"
PHASE 5  backend bridge: access_matrix.py two-account IDOR/BOLA replay
PHASE 6  chain synthesis + prosecutor–defender–judge adversarial triage
PHASE 7  MASVS/MASWE-mapped report + runnable PoC packaging
PHASE 8  regression-corpus coverage check
```

State lives on disk (`loot/<pkg>/model.md`, `ledger.md`), so hunts survive context compaction and can be resumed anytime.

---

## Install (as a Kimi Code skill)

```bash
# Kimi Code CLI installed → then:
git clone https://github.com/<you>/androidhunter-ultimate.git
cp -r androidhunter-ultimate ~/.kimi-code/skills/

# verify
~/.kimi-code/skills/androidhunter-ultimate/scripts/preflight.sh
```

Restart the Kimi session (or `/reload`) — the skill auto-loads when you ask for Android security work ("hunt this apk", "test this play store app", "deep link exploit"…).

## Quickstart

```bash
SKILL=~/.kimi-code/skills/androidhunter-ultimate

# 1. authorize (the gate refuses everything not listed — this is the point)
echo "com.dd.example"  >> $SKILL/scope/authorized_apps.txt
echo "api.example.com" >> $SKILL/scope/authorized_api_domains.txt
$EDITOR $SKILL/scope/rules.md        # paste the program ROE

# 2. intake + recon
$SKILL/scripts/app_intake.sh "https://play.google.com/store/apps/details?id=com.dd.example"
$SKILL/scripts/static_recon.sh loot/com.dd.example/unpacked

# 3. hand the wheel to Kimi: model → AgentSwarm engines → device PoC → report
```

Output per engagement: `loot/<pkg>/` — model, ledger, surface files, fuzz logs, findings with PoC + evidence.

---

## Automation suite

| script | what it does |
|---|---|
| `preflight.sh` | verifies toolchain, adb device, frida version match, scope files |
| `scope_gate.sh` | authorization enforcement (app id / API host) — fails closed |
| `app_intake.sh` | Play URL / APK / XAPK → gate → apkeep → split handling → apktool+jadx → apkid/apksigner fingerprint |
| `static_recon.sh` | orchestrates the whole static extraction into `loot/<pkg>/` |
| `manifest_analyze.py` | full manifest parse: implicit-export resolution by targetSdk, deep-link routing table, providers, permissions, flags → JSON+MD |
| `deeplink_matrix.py` | routing table → attack URI matrix + executable `deeplink_fuzz.sh` |
| `secrets_hunter.py` | 20-class regex library + Shannon entropy over jadx/resources/assets/`.so` → file:line evidence |
| `deeplink_probe.sh` | fire one deep link as an external attacker (implicit/explicit) |
| `provider_probe.sh` | ContentProvider SQLi (`selection`/`sortOrder`) + path-traversal battery |
| `intent_fuzzer.sh` | exported-component fuzzing: null/wrong-type/oversized extras, rapid-fire, crash capture |
| `setup_device.sh` | frida-server download/push/run (renamed), Burp CA install, proxy config |
| `firebase_audit.py` | read-only Firebase RTDB/Firestore/Storage misconfig battery |
| `chain_suggest.py` | cross-references recon output → prioritized chain candidates |
| `oob_server.py` | self-hosted OOB listener + ready `/poc.html` bridge-caller page |
| `access_matrix.py` | two-account replay → IDOR/BOLA flags on the backend API |
| `dump_dex.sh` | runtime dex dump for packed/protected apps |
| `report_build.sh` | assembles ledger + findings into `final_report.md` |
| `mobsf_ingest.py` | MobSF JSON → normalized surface + prioritized chain candidates |
| `semgrep/android-rules.yml` | 19 custom AST rules (WebView, intent redirection, trust-all, ECB/static-IV, sensitive logs…) |
| `poc_app_template/` | malicious-app source for proofs adb can't carry (scheme interception, setResult capture, nested intents) |

### Frida suite (authorized observation, your own device)

| script | proves |
|---|---|
| `frida_unpin.js` | traffic visibility — generic `X509TrustManager` enumeration + OkHttp/Conscrypt/WebView/TrustKit |
| `frida_flutter_unpin.js` | Flutter BoringSSL pinning bypass (pattern-hook — Java-layer hooks don't cover Flutter) |
| `frida_rootbypass.js` | reach surface behind root/emulator/debugger checks |
| `frida_bridge_trace.js` | runtime `@JavascriptInterface` auto-enumeration, every `loadUrl`/navigation decision logged |
| `frida_intent_logger.js` | IPC flows, extras, PendingIntent mutability, URI grants |
| `frida_crypto_monitor.js` | Cipher keys/IVs, Keystore ops, `Log.*` leaks, Prefs/SQLite writes |

---

## Repo layout

```
SKILL.md              the pipeline Kimi executes (start here)
README.md             this file
LICENSE               MIT
references/           18 deep guides — one per phase & engine
scripts/              24 tools (bash / python / frida-js), all scope-gated
semgrep/              custom Android ruleset (19 AST rules)
poc_app_template/     malicious-app source for scheme/setResult/redirection proofs
scope/                authorized_apps.txt · authorized_api_domains.txt · rules.md
corpus/               9 regression cards of documented public bug patterns
loot/<pkg>/           per-engagement output (created in your working directory)
```

## Requirements

Core (Kali-ish): `apktool jadx apkeep adb frida objection aapt2 apksigner unzip curl jq openssl xz python3 java`
Breadth: `apkid apkleaks trufflehog semgrep r2 mitmproxy` — `preflight.sh` reports exactly what's missing and degrades gracefully.
Device: rooted emulator (recommended) or rooted physical; non-root fallback via Frida Gadget repackaging (`objection patchapk`).

---

## Safety & authorization

This is an offensive-security tool. It is built to be impossible to use "by accident":

- **Scope gate fails closed** — empty scope files = everything refused; every traffic/intent-firing script re-checks.
- Dynamic testing only on **your own device/emulator with your own test accounts**; OOB only to infrastructure you control; evidence redacted.
- Real-user data is never a proof target. Two-account tests use two accounts **you** created.
- Standing ROE in `scope/rules.md` cannot be overridden mid-hunt by anyone.

You are responsible for authorization for every app id and domain you place in `scope/`. If it's not yours and not in a program's scope — don't.

## Contributing

Add a `corpus/cases/` card when you finish a hunt whose pattern generalizes; extend engines via new `references/engine-*.md` + a ledger-aware subagent prompt in `references/ai-orchestration.md`. Keep the proof bar absolute: no reproduced PoC, no finding.

## Credits

- v1: `claudemobilehunterv1` — the thesis and the original five engines.
- Grounding: [OWASP MASVS/MASTG/MASWE](https://mas.owasp.org/), Oversecured, public bug-bounty writeups (see `references/research-grounding.md`).

## License

MIT — see [LICENSE](LICENSE). No warranty. Authorized testing only.
