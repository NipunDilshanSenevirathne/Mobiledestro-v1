---
name: androidhunter-ultimate
version: 2.1
author: "Sadun Kumara Adarmashena (v1 claudemobilehunterv1) → v2.1: Kimi Code native, Android-only, deepest hunting"
description: >
  androidhunter ultimate — the deepest Android application security hunting workflow in this
  skill line, rebuilt to run natively in Kimi Code CLI where the tools actually execute.
  Full pipeline: authorization gate → toolchain preflight → store-URL/APK intake & acquisition →
  static recon & attack-surface model reconstruction → PARALLEL engine sweep across Kimi
  subagents (AgentSwarm: deeplink/WebView/JS-bridge, IPC/exported-components/intent-redirection,
  network→backend-API, storage/secrets/crypto, auth/OAuth/biometric, native .so/JNI,
  cross-platform Flutter/RN/Unity, Firebase/cloud misconfig) → dynamic instrumentation &
  device/emulator confirmation (Frida/objection/adb, background fuzzing tasks) → backend
  IDOR/BOLA/logic bridge → chain synthesis → prosecutor–defender–judge adversarial triage →
  MASVS/MASWE-mapped PoC reporting — then self-measurement against a regression corpus.

  USE THIS SKILL FOR: Android APK security audit, Android bug bounty, Play Store app testing,
  deep link / App Links exploitation, WebView & JavaScript-interface abuse, exported component /
  intent redirection / ContentProvider attacks, SSL pinning bypass, Frida/objection runtime
  instrumentation, OAuth/PKCE/biometric bypass, hardcoded secret hunting, Firebase/S3/cloud
  misconfiguration, native library (.so/JNI) review, Flutter/React-Native/Unity app reversing,
  MobSF report chaining, MASVS/MASTG/MASWE mapping, Android PoC exploit development for
  AUTHORIZED targets.

  TRIGGER PHRASES: "hunt this apk", "android bug bounty", "test this play store app", "deep
  link exploit", "webview js bridge", "frida this app", "ssl pinning bypass", "exported
  activity", "content provider sql injection", "reverse this apk", "mobSF report", "android
  pentest", "find bugs in this app". Use it whenever the task is reviewing an Android app for
  vulnerabilities, even if the user doesn't say "audit".

  Runs fully in Kimi Code CLI (real tool execution + AgentSwarm subagents + background tasks).
  If tool execution is ever unavailable, degrade to analysis-only and label every finding
  Hypothesis. Authorized apps and in-scope backends ONLY — the scope gate refuses everything else.
---

# androidhunter ultimate (v2 — Kimi Code edition)

**Core principle, unchanged and non-negotiable: a finding is not a finding until it is
reproduced on your own device/emulator with your own accounts.** Everything here — more
engines, more automation, more orchestration — exists to feed that pipeline. Confidence comes
from verification, never from adjectives.

**Thesis:** the easy Android bugs (`allowBackup=true`, a missing-pinning note, a dead test key)
are saturated and duplicate. The non-dup critical/high lives in **chains** that require
reconstructing the app's logic: a deep link → WebView → exposed JS bridge → token theft → ATO;
an exported component acting as confused deputy; a pinning bypass that opens the backend API
where the real IDOR/BOLA/business-logic money bugs are. Tools decompile; **the LLM reasons
about reachability and trust** — that is the edge, and Kimi Code runs it for real.

v2 vs v1 (claudemobilehunterv1): Android-only depth instead of iOS+Android breadth; Kimi-native
orchestration (**AgentSwarm parallel engine subagents**, **background tasks** for fuzzing and
instrumentation, hunt ledger); three NEW engines (**native code**, **cross-platform frameworks**,
**Firebase/cloud**); a real Python manifest analyzer, deep secrets hunter with entropy scoring,
deep-link matrix generator, provider/intent fuzzers, device setup automation, six Frida
scripts (incl. Flutter BoringSSL), a custom Semgrep ruleset, a chain-candidate generator, a
self-hosted OOB listener, an access-matrix replay tool for the backend bridge, a PoC
malicious-app template, dex-dump helper for packed apps, adversarial prosecutor–defender–
judge triage, a report assembler, and a nine-card regression corpus.

---

## PHASE 0 — AUTHORIZATION & SCOPE GATE (always first, hard-fail)

Test only apps you own or are explicitly authorized to test (your company's apps, or a
bug-bounty program listing the app/backend in scope).

1. **Authorized apps**: `scope/authorized_apps.txt` in the skill dir = allowed package ids.
   Intake refuses anything not listed (`scripts/scope_gate.sh app <pkg>`).
2. **In-scope backends**: active API testing hits the app's backend — those domains must be in
   `scope/authorized_api_domains.txt` (`scripts/scope_gate.sh api <host>`).
3. **ROE**: `scope/rules.md`. Static reverse of an authorized binary is fine; **dynamic** runs
   on **your own device/emulator** with **your own test accounts**; never touch real users'
   data; throttle API testing; redact secrets; no third-party pivot. Unauthorized →
   static/design-only, or decline.

Full gate rules: `references/authorization-and-scope.md`. Every script that fires traffic or
intents re-checks the gate. Never bypass it.

Then run **Scope Intake** (app id/store URL, bounty program URL, in-scope backend domains,
test-account availability, device/emulator available, ROE constraints) and echo a summary for
confirmation. Record in `loot/<appid>/scope.md`.

---

## PHASE 1 — PREFLIGHT & INTAKE (Kimi Code, real execution)

Skill dir below is `${KIMI_SKILL_DIR}` = `~/.kimi-code/skills/androidhunter-ultimate`.
All engagement output goes to `loot/<appid>/` under the **current working directory**.

**1A. Preflight.** Run `${KIMI_SKILL_DIR}/scripts/preflight.sh` — verifies the toolchain
(apktool/jadx/apkeep/adb/frida/objection/aapt2/apkid/trufflehog/semgrep/r2/mitmproxy/openssl),
adb device state, frida-server/device version match, and that scope files are populated.
This machine already carries the core stack. If something is missing, tell the user exactly
what to install — never degrade silently.

**1B. Intake.** `${KIMI_SKILL_DIR}/scripts/app_intake.sh <play-store-url | path.apk | path.xapk>`
→ parses platform/id → **authorization-gates** it → acquires the binary (apkeep, or supplied
file) → merges split APKs → unpacks (apktool + jadx + raw unzip) → detects packers/protectors
(apkid) → inspects signing cert (apksigner) → seeds `loot/<appid>/model.md`.
Details and edge cases (XAPK/APKM splits, AAB, third-party mirrors, cert pinning of the APK
itself): `references/intake-and-recon.md`. **Packed app** (apkid says so, jadx shows only a
stub loader)? Dump at runtime on your own device: `scripts/dump_dex.sh <pkg>`, then re-run
static recon on the dumped dex.

**Optional baseline boost:** if a MobSF JSON report exists,
`python3 ${KIMI_SKILL_DIR}/scripts/mobsf_ingest.py --report <mobsf.json> --out loot/<appid>`
normalizes MobSF's flat findings into prioritized chain candidates. Use MobSF for breadth,
this skill to connect and prove the chains.

---

## PHASE 2 — STATIC RECON & MODEL RECONSTRUCTION

Run `${KIMI_SKILL_DIR}/scripts/static_recon.sh loot/<appid>/unpacked` — orchestrates:

- `manifest_analyze.py` — full manifest parse: exported components (resolving implicit-export
  rules by targetSdk), per-component intent filters (scheme/host/path/port), providers +
  authorities + grantUri + path-permissions, custom permissions + protectionLevel, deep-link
  routing table, risky flags → `manifest_analysis.json/md`.
- `deeplink_matrix.py` — turns the routing table into attack URIs (traversal, scheme-swap,
  host-confusion, `intent://`, param injection) + a ready `deeplink_fuzz.sh`.
- `secrets_hunter.py` — regex library + Shannon-entropy scan over jadx/resources/assets/libs:
  cloud keys, tokens, PEM blocks, Firebase config, endpoints, WebSockets, internal hosts →
  `secrets.txt`, `endpoints.txt` (with file:line evidence).
- grep engines: WebView/JS-bridge sinks, Retrofit/OkHttp endpoints, JNI/native inventory,
  third-party SDK inventory, network-security-config parse → `webview.txt`, `api_surface.txt`,
  `native.txt`, `sdks.txt`, `flags.txt`.
- **Semgrep custom ruleset** (`semgrep/android-rules.yml`) — AST-aware second opinion for
  WebView/bridge, intent redirection, trust-all managers, ECB/static-IV/hardcoded-key,
  sensitive logs → `semgrep.txt`.
- `chain_suggest.py` — cross-references every recon file into **prioritized chain candidates**
  (`chain_candidates.md`): browsable deeplink + bridge ⇒ flagship; exported provider + no
  perm ⇒ SQLi/traversal chain; custom scheme + oauth endpoints ⇒ interception chain; etc.

Then **you read the decompiled code** (jadx) and write `loot/<appid>/model.md`: routing table,
exported components + what they trust, WebView configs + every `@JavascriptInterface` method and
what it exposes, providers, storage map, **backend API + auth scheme**, secrets → backend
reachability, trust boundaries, abuse hypotheses. You cannot find the deep chains without the
model. Deep guide: `references/static-deep-dive.md`.

---

## PHASE 3 — PARALLEL ENGINE SWEEP (AgentSwarm — the Kimi edge)

Fan the engines out as parallel subagents over the unpacked app — each reads `model.md` + its
engine reference + the jadx tree, and appends hypotheses/tests to `loot/<appid>/ledger.md`.
Orchestration patterns and exact subagent prompts: `references/ai-orchestration.md`.

Engines (run all whose preconditions the model satisfies — order = expected value):

1. **Deep link → WebView → JS bridge** (flagship) — `references/engine-deeplink-webview.md`
2. **IPC / exported components / intent redirection / providers** — `references/engine-ipc-components.md`
3. **Network → backend API** (pinning bypass → IDOR/BOLA/logic) — `references/engine-network-api.md`
4. **Storage, secrets & crypto** — `references/engine-storage-crypto.md`
5. **Auth / OAuth / biometric / local-auth** — `references/engine-auth-runtime.md`
6. **Native code (.so / JNI / memory-corruption surface)** — `references/engine-native-code.md`
7. **Cross-platform frameworks (Flutter / React Native / Unity / Capacitor)** — `references/engine-cross-platform.md`
8. **Firebase & cloud misconfiguration** — `references/engine-firebase-cloud.md`

Each subagent returns: hypotheses ranked by (impact × reachability × novelty), exact code
citations (class/method/line), and the dynamic test needed to confirm. Merge into the ledger.

---

## PHASE 4 — DYNAMIC CONFIRMATION (device/emulator, background tasks)

Setup: `${KIMI_SKILL_DIR}/scripts/setup_device.sh` — detects device/arch, pushes matching
frida-server, installs Burp CA (system store on emulator/user store fallback), sets proxy.
Then confirm hypotheses — long-running probes go to **Kimi background tasks** while you keep
reasoning. Full guide: `references/dynamic-instrumentation.md`,
`references/fuzzing-and-probing.md`.

- **Frida suite** (authorized observation only):
  `frida_unpin.js` (generic TrustManager enumeration + OkHttp/Conscrypt/WebView/TrustKit),
  `frida_flutter_unpin.js` (BoringSSL pattern-hook for Flutter — Java-layer hooks don't cover
  it), `frida_rootbypass.js` (root/emulator/debugger detection), `frida_bridge_trace.js`
  (WebView loadUrl/settings/`@JavascriptInterface` auto-enumeration + hooking),
  `frida_intent_logger.js` (IPC flows + extras dumps), `frida_crypto_monitor.js`
  (Cipher/Keystore/Log/SQLite/Prefs — runtime secret-leak hunting).
- **OOB capture**: `scripts/oob_server.py --port 8000 --log loot/<pkg>/oob.log` — your own
  listener (token exfil/WebView-fetch proof) with a ready `/poc.html` bridge-caller page.
- **Deep-link firing**: `scripts/deeplink_probe.sh android <pkg> '<uri>'` as an *external*
  attacker; `deeplink_fuzz.sh` (generated Phase 2) sweeps the whole matrix; watch logcat + OOB.
- **Exported-component fuzzing**: `scripts/intent_fuzzer.sh <pkg>` — null/wrong-type/oversized
  extras, rapid-fire races, crash capture + tombstones.
- **Provider probing**: `scripts/provider_probe.sh <pkg>` — SQLi selections/sortOrder,
  path-traversal sequences in `openFile`, grantUri forwarding — against your own seeded data.
- **Traffic**: route through Burp/mitmproxy; bypass pinning; map the live API against the
  static `api_surface.txt`.

Proof bar per class: `references/validation-and-poc.md`. Anything weaker = "unconfirmed lead".

---

## PHASE 5 — BACKEND BRIDGE (the money phase)

The app is a thin client; most mobile criticals are **server-side**. With traffic visible and
the API mapped (Retrofit interfaces, interceptors, HMAC signing replicated from the binary):
- Scope-gate every host: `scripts/scope_gate.sh api <host>`.
- **IDOR/BOLA**: `scripts/access_matrix.py --requests <captured> --session-a <tok> --session-b
  <tok>` replays object-scoped calls under two of **your own** accounts and flags cross-tenant
  breaks.
- **Mass assignment** with hidden fields from the binary (`role`, `isAdmin`, `tenantId`,
  `price`, `status`). **Business logic**: IAP/receipt validation, wallet/rewards races
  (single-packet), OTP attempt-counter races. Engine: `references/engine-network-api.md`.

---

## PHASE 6 — CHAIN SYNTHESIS + ADVERSARIAL TRIAGE

The dup-killer. Combine primitives (deep link→WebView→bridge→token→ATO; exported→intent
redirection→internal component; provider traversal→token DB→API IDOR; hardcoded key→Firebase
admin→PII). Full chain catalog + novelty scoring: `references/chaining-and-novelty.md`.

Then **prosecutor–defender–judge** triage each candidate (subagents):
prosecutor argues exploitability end-to-end; defender argues mitigations, preconditions,
reachability gaps, dup-likelihood; judge assigns honest severity + confidence and decides
report/deepen/drop. Protocol: `references/adversarial-triage.md`. If high-dup, deepen into a
chain or note-and-move-on. **Submit low-dup fast** — chains decay as the app updates.

---

## PHASE 7 — PoC PACKAGING & REPORT (MASVS/MASWE-mapped)

Per finding: one-line business impact, MASVS/MASWE id, severity (CVSS + real-world), exact
reproducible PoC (`adb`/`frida` commands, malicious-app stub, PoC HTML, curl with your seeded
accounts), decompiled root-cause citation, proof artifact (OOB capture, provider dump,
access-matrix flag row, Frida trace), remediation, novelty note. Format and artifact layout
(`loot/<appid>/findings/<id>/`): `references/validation-and-poc.md`. When `adb` can't carry
the proof (scheme interception, setResult capture, nested intents), build the bundled
`poc_app_template/` malicious app. Finish with `scripts/report_build.sh loot/<appid>` →
`final_report.md` (run summary + ledger + all findings).

---

## PHASE 8 — SELF-MEASUREMENT (regression corpus)

`corpus/cases/` holds documented public bug-pattern cards. After building `model.md` for a
target, check each card's detection rule against it — a card the model would have missed marks
a coverage gap to close before reporting. `corpus/README.md`.

---

## NON-NEGOTIABLE DISCIPLINE

- **Authorized apps + in-scope backends + ROE-honored.** The gate hard-fails closed.
- **Reverse & reconstruct before attacking** — reachability is the whole game.
- **Bypass the client, then test the server** — that's where criticals hide.
- **Prove on your own device/emulator with your own accounts/OOB**; never real PII.
- **Chains & variants beat singletons** — and they don't duplicate.
- **Map to MASVS/MASWE; honest severity; record negatives; non-destructive.**

## QUICKSTART
```bash
SKILL=~/.kimi-code/skills/androidhunter-ultimate
echo "com.dd.example"    >> $SKILL/scope/authorized_apps.txt        # authorized app id(s)
echo "api.example.com"   >> $SKILL/scope/authorized_api_domains.txt # authorized backend(s)
$EDITOR $SKILL/scope/rules.md                                       # ROE
$SKILL/scripts/preflight.sh
$SKILL/scripts/app_intake.sh "https://play.google.com/store/apps/details?id=com.dd.example"
$SKILL/scripts/static_recon.sh loot/com.dd.example/unpacked
# Kimi then builds model.md, fans out the AgentSwarm engine sweep (Phase 3),
# confirms on device/emulator (Phase 4), bridges to the backend (Phase 5),
# chains + triages (Phase 6), and writes the MASVS-mapped PoC reports (Phase 7).
```
